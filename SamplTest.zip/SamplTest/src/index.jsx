import React, {Component} from 'react';
import ReactDOM from 'react-dom';

import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';

export default class Products extends React.Component {

    constructor(props) {
        super(props)

        this.state = {

            all: [
                {
                    "transactionId": "86199350",
                    "firmCode": "FSTP",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157041",
                    "blockId": "120417115704",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "Trade Capture",
                    "criticality": "CRITICAL",
                    "AGING": "NumberLong(-9)",
                    "category": "Missing Manadatory Filed "
                }, {
                    "transactionId": "86199351",
                    "firmCode": "FSTP",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157051",
                    "blockId": "120417115751",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "Trade Capture",
                    "criticality": "HIGH",
                    "AGING": "NumberLong(-9)",
                    "category": "Missing Manadatory Filed "
                }, {
                    "transactionId": "86199352",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157052",
                    "blockId": "1204171157052",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "Trade Capture",
                    "criticality": "MEDIUM",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Manadatory Filed"
                }, {
                    "transactionId": "86199352",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157052",
                    "blockId": "1204171157052",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "Trade Capture",
                    "criticality": "MEDIUM",
                    "AGING": "NumberLong(-100)",
                    "category": "BUSINESS_VALIDATION",
                    "description": "Failure Resolving Net Amount. (Principal=1500000) +/- (Fees=190) + (Accrued Inte" +
                            "rest=)"
                }, {

                    "transactionId": "86199353",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157053",
                    "blockId": "1204171157053",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "Trade Capture",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "Recipient Preferred Security Id Missing"
                }, {

                    "transactionId": "86199354",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157054",
                    "blockId": "1204171157054",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "CONFIRMATION",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "SWIFT Nak Received"
                }, {

                    "transactionId": "86199355",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157055",
                    "blockId": "1204171157055",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "CONFIRMATION",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "SWIFT Nak Received"
                }, {

                    "transactionId": "86199356",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157056",
                    "blockId": "1204171157056",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "CONFIRMATION",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "SWIFT Nak Received"
                }, {

                    "transactionId": "86199357",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157057",
                    "blockId": "1204171157057",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "CONFIRMATION",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "SWIFT Nak Received"
                }, {

                    "transactionId": "86199358",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157058",
                    "blockId": "1204171157058",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "CONFIRMATION",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "SWIFT Nak Received"
                }
            ],
            Critical: [
                {
                    "transactionId": "86199350",
                    "firmCode": "FSTP",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157041",
                    "blockId": "120417115704",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "Trade Capture",
                    "criticality": "CRITICAL",
                    "AGING": "NumberLong(-9)",
                    "category": "Missing Manadatory Filed "
                }
            ],
            High: [
                {
                    "transactionId": "86199351",
                    "firmCode": "FSTP",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157051",
                    "blockId": "120417115751",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "Trade Capture",
                    "criticality": "HIGH",
                    "AGING": "NumberLong(-9)",
                    "category": "Missing Manadatory Filed "
                }
            ],
            Medium: [
                {
                    "transactionId": "86199352",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157052",
                    "blockId": "1204171157052",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "Trade Capture",
                    "criticality": "MEDIUM",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Manadatory Filed"
                }, {
                    "transactionId": "86199352",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157052",
                    "blockId": "1204171157052",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "Trade Capture",
                    "criticality": "MEDIUM",
                    "AGING": "NumberLong(-100)",
                    "category": "BUSINESS_VALIDATION",
                    "description": "Failure Resolving Net Amount. (Principal=1500000) +/- (Fees=190) + (Accrued Inte" +
                            "rest=)"
                }
            ],
            Low: [
                {

                    "transactionId": "86199353",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157053",
                    "blockId": "1204171157053",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "Trade Capture",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "Recipient Preferred Security Id Missing"
                }, {
                    "transactionId": "86199354",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157054",
                    "blockId": "1204171157054",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "CONFIRMATION",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "SWIFT Nak Received"
                }, {
                    "transactionId": "86199355",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157055",
                    "blockId": "1204171157055",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "CONFIRMATION",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "SWIFT Nak Received"
                }, {
                    "transactionId": "86199356",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157056",
                    "blockId": "1204171157056",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "CONFIRMATION",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "SWIFT Nak Received"
                }, {
                    "transactionId": "86199357",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157057",
                    "blockId": "1204171157057",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "CONFIRMATION",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "SWIFT Nak Received"
                }, {

                    "transactionId": "86199358",
                    "firmCode": "OMGI",
                    "type": "exceptionCreated",
                    "tradeId": "1204171157058",
                    "blockId": "1204171157058",
                    "assetClass": "TIMEDEPOSIT",
                    "custodian": "API_OMGI03",
                    "status": "Open",
                    "source": "MOM",
                    "stage": "CONFIRMATION",
                    "criticality": "LOW",
                    "AGING": "NumberLong(-100)",
                    "category": "Missing Mandatory Fields",
                    "description": "SWIFT Nak Received"
                }
            ],
            tempArray: []
        }
    }
    componentWillMount(){
        this.setState({tempArray: this.state.all});
    }
    async clickAction(text, e) {
       
        if (text.Text === "Critical") {
          await  this.setState({tempArray: [...this.state.Critical]});
        }else if (text.Text === "High") {
            await  this.setState({tempArray: [...this.state.High]});
        }else if (text.Text === "Medium") {
            await  this.setState({tempArray: [...this.state.Medium]});
        }else if (text.Text === "Low") {
            await  this.setState({tempArray: [...this.state.Low]});
        }else if (text.Text === "All") {
            await this.setState({tempArray: [...this.state.all]});
        }
        console.log("clickAction===>", this.state.tempArray);
    }

    render() {
        return (
            <div className="container"><br/>
            
                <button
                    type="button"
                    className="btn btn-danger"
                    onClick={this
                    .clickAction
                    .bind(this, {"Text": 'Critical'})}>Critical</button><br/>
                <button
                    type="button"
                    className="btn btn-warning"
                    onClick={this
                    .clickAction
                    .bind(this, {"Text": 'High'})}>High</button><br/>
                <button
                    type="button"
                    className="btn btn-primary"
                    onClick={this
                    .clickAction
                    .bind(this, {"Text": 'Medium'})}>Medium</button><br/>
                <button
                    type="button"
                    className="btn btn-info"
                    onClick={this
                    .clickAction
                    .bind(this, {"Text": 'Low'})}>Low</button><br/>
                <button
                    type="button"
                    className="btn btn-default"
                    onClick={this
                    .clickAction
                    .bind(this, {"Text": 'All'})}>All</button><br/><br/>
                <BootstrapTable data={this.state.tempArray}>
                    <TableHeaderColumn dataField='firmCode' isKey>Firm Code</TableHeaderColumn>
                    <TableHeaderColumn dataField='source'>Source</TableHeaderColumn>
                    <TableHeaderColumn
                        dataField='AGING'
                        tdStyle={{
                        whiteSpace: 'normal'
                    }}>Aging</TableHeaderColumn>
                    <TableHeaderColumn
                        dataField='blockId'
                        tdStyle={{
                        whiteSpace: 'normal'
                    }}>Block Id</TableHeaderColumn>
                    <TableHeaderColumn dataField='assetClass'>Asset Class</TableHeaderColumn>
                    <TableHeaderColumn dataField='stage'>Stage</TableHeaderColumn>
                    <TableHeaderColumn dataField='custodian'>Exception</TableHeaderColumn>
                    <TableHeaderColumn
                        dataField='category'
                        tdStyle={{
                        whiteSpace: 'normal'
                    }}>Description</TableHeaderColumn>
                    <TableHeaderColumn dataField='status'>Status</TableHeaderColumn>
                </BootstrapTable>
            </div>

        )
    }
}
ReactDOM.render(
    <Products/>, document.getElementById('container'));
