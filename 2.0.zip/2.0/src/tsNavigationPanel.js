import React, { Component } from 'react';
import { hashHistory } from 'react-router';
import EwDashboard from './component/EwDashboard/EwDashboard.js';
import activeExceptionCategoryListStore from './store/actveExceptionCategoryStore'
import exceptionTableAborNavDataStore from './store/exceptionTableAborNavDataStore'
import exceptionSummaryAborNavDataStore from './store/exceptionSummaryAborNavDataStore'
import graphAborNavDataStore from './store/graphAborNavDataStore'
import dynamicDashboardTabDataStore from './store/dynamicDashboardTabDataStore'
import fileDownloadStore from './store/fileDownloadStore'
import fileDownload from 'react-file-download'
import XLSX from 'xlsx'
import userDetailDataStore from './store/userDetailDataStore';
import * as Action from './action/Actions';
import DynamicTabAddPopup from './component/NavigationUtility/DynamicTabAddPopup';
import ChatPopup from './component/NavigationUtility/ChatPopup';
import HelpCenter from './component/HelpCenter/HelpCenter';
import Feedback from './component/Feedback/Feedback';
import Setting from './component/Setting/Setting';
import NavigationOption from './component/EwDashboard/Header/NavigationOption';
import DashboardChange from './component/NavigationUtility/DashboardChange';

export default class TSNavigationPanel extends Component {

    constructor() {
        super();
        this.state = {
            cssProps: {
                display: 'none'
            },
            dynamicTabData: [],
            dynamicTabPopupDisplay: false,
            chatPopupDisplay: false,
            chatPopup: null,
            helpCenterPopup: false,
            feedbackPopup: false,
            settingCssProps: {
                display: 'none'
            },
            showNavOption: false,
            dashboardChanged: false

        };
        this.popup = { yposition: 0 };
        this.settingPopup = {
            xposition: 0,
            yposition: 0
        };
        this.navOptionPopup = {
            yposition: 0,
            xposition: 0
        };
        if (!Array.prototype.indexOf) {
            Array.prototype.indexOf = function (obj, fromIndex) {
                if (fromIndex == null) {
                    fromIndex = 0;
                } else if (fromIndex < 0) {
                    fromIndex = Math.max(0, this.length + fromIndex);
                }
                for (var i = fromIndex, j = this.length; i < j; i++) {
                    if (this[i] === obj)
                        return i;
                }
                return -1;
            };
        }
        if (!Array.prototype.find) {
            Object.defineProperty(Array.prototype, 'find', {
                value: function (predicate) {
                    if (this == null) {
                        throw new TypeError('"this" is null or not defined');
                    }
                    var o = Object(this);
                    var len = o.length >>> 0;
                    if (typeof predicate !== 'function') {
                        throw new TypeError('predicate must be a function');
                    }
                    var thisArg = arguments[1];
                    var k = 0;
                    while (k < len) {
                        var kValue = o[k];
                        if (predicate.call(thisArg, kValue, k, o)) {
                            return kValue;
                        }
                        k++;
                    }
                    return undefined;
                }
            });
        }
        if (typeof String.prototype.contains === 'undefined') {
            String.prototype.toCapitalise = function () {
                return this.charAt(0).toUpperCase() + this.slice(1);
            }
        }
        if (typeof String.prototype.contains === 'undefined') {
            String.prototype.contains = function (it) {
                return this.indexOf(it) != -1;
            };
        }

    }

    getTabClassName(type) {
        if (this.props.children.props.route.path != undefined && this.props.children.props.route.path.indexOf(':') < 0) {
            if (this.props.children.type.name === type) {
                return 'navigationpanel-tab-active';
            }
            return 'navigationpanel-tab-notactive';
        }
        else {
            if (this.props.children.props.route.component.name === type) {
                return 'navigationpanel-tab-active';
            }
            if (this.props.children.props.routeParams.page === type) {
                return 'navigationpanel-tab-active';
            }
            return 'navigationpanel-tab-notactive';
        }
    }

    handleCsvDownloadClick() {
        let header = '';
        exceptionTableDataStore.getTableHeaderList().forEach((headerEach) => {
            if (headerEach.displayName != "checkBox") {
                header = header + headerEach.displayName + ',';
            }
        });
        header = header.slice(0, -1);
        let toLoadData = header + '\n';
        let dataToDownload = fileDownloadStore.getDownloadedData().length > 0 ? fileDownloadStore.getDownloadedData() : exceptionTableDataStore.getTableData();
        dataToDownload.map((item) => {
            let row = '';
            exceptionTableDataStore.getTableHeaderList().forEach((headerEach) => {
                if (headerEach.fieldName != "checkBox") {
                    row = row + item[headerEach.fieldName] + ',';
                }
            });
            let find = 'undefined';
            let regEx = new RegExp(find, 'g');
            toLoadData = toLoadData + row.replace(regEx, '') + '\n';
        });
        fileDownload(toLoadData, 'EW_' + activeExceptionCategoryListStore.getActiveCategory() + '_' + exceptionSummaryDataStore.getActiveCriticality() + '.csv');
    }

    handleXlsDownloadClick() {
        function datenum(v, date1904) {
            if (date1904) v += 1462;
            var epoch = Date.parse(v);
            return (epoch - new Date(Date.UTC(1899, 11, 30))) / (24 * 60 * 60 * 1000);
        }

        function sheet_from_array_of_arrays(rows, opts) {
            var ws = {};
            var range = { s: { c: 10000000, r: 10000000 }, e: { c: 0, r: 0 } };
            for (var R = 0; R != rows.length; ++R) {
                for (var C = 0; C != rows[R].length; ++C) {
                    if (range.s.r > R) range.s.r = R;
                    if (range.s.c > C) range.s.c = C;
                    if (range.e.r < R) range.e.r = R;
                    if (range.e.c < C) range.e.c = C;
                    var cell = { v: rows[R][C] };
                    if (cell.v == null) continue;
                    var cell_ref = XLSX.utils.encode_cell({ c: C, r: R });

                    if (typeof cell.v === 'number') cell.t = 'n';
                    else if (typeof cell.v === 'boolean') cell.t = 'b';
                    else if (cell.v instanceof Date) {
                        cell.t = 'n'; cell.z = XLSX.SSF._table[14];
                        cell.v = datenum(cell.v);
                    }
                    else cell.t = 's';

                    ws[cell_ref] = cell;
                }
            }
            if (range.s.c < 10000000) ws['!ref'] = XLSX.utils.encode_range(range);
            return ws;
        }

        let rows = [];
        let header = []
        exceptionTableDataStore.getTableHeaderList().forEach((headerEach) => {
            if (headerEach.displayName != "checkBox") {
                header.push(headerEach.displayName);
            }
        });
        rows.push(header);
        let dataToDownload = fileDownloadStore.getDownloadedData().length > 0 ? fileDownloadStore.getDownloadedData() : exceptionTableDataStore.getTableData();
        dataToDownload.map((item) => {
            let row = [];
            exceptionTableDataStore.getTableHeaderList().forEach((headerEach) => {
                if (headerEach.fieldName != "checkBox") {
                    row.push(item[headerEach.fieldName]);
                }
            });
            rows.push(row);
        });
        var ws_name = "Exception table";

        function Workbook() {
            if (!(this instanceof Workbook)) return new Workbook();
            this.SheetNames = [];
            this.Sheets = {};
        }
        var wb = new Workbook(), ws = sheet_from_array_of_arrays(rows);
        wb.SheetNames.push(ws_name);
        wb.Sheets[ws_name] = ws;
        var wopts = { bookType: 'xlsx', bookSST: false, type: 'binary' };
        var wbout = XLSX.write(wb, wopts);
        function s2ab(s) {
            var buf = new ArrayBuffer(s.length);
            var view = new Uint8Array(buf);
            for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
            return buf;
        }
        fileDownload(s2ab(wbout), 'EW_' + activeExceptionCategoryListStore.getActiveCategory() + '_' + exceptionSummaryDataStore.getActiveCriticality() + '.xlsx', { type: "application/octet-stream" });
    }

    handlePdfDownloadClick() {
        var doc = new jsPDF()
        doc.text(20, 20, 'Exceptions Detail')
        doc.text(20, 30, 'Detail Comes here')
        doc.addPage()
        doc.text(20, 20, 'More detail')
        doc.save('EW_' + activeExceptionCategoryListStore.getActiveCategory() + '_' + exceptionSummaryDataStore.getActiveCriticality() + '.pdf');
    }

    handleDownloadMouseEnter(e) {
        this.popup.yposition = e.target.getBoundingClientRect().bottom;
        this.popup.xposition = e.target.getBoundingClientRect().left;
        this.setState({
            cssProps: {
                display: 'none'
            }
        });
    }

    handleDownloadMouseLeave(e) {
        this.setState({
            cssProps: {
                display: 'none'
            }
        });
    }

    handleImClick() {
        this.setState({
            chatPopupDisplay: !this.state.chatPopupDisplay
        });
    }

    handleHelpClick() {
        // let message = {
        //   emailId: 'subham.kumar.singh@citi.com',
        //   subject: 'Help! Exception workbench',
        //   from: 'User'
        // };
        // let email = message.emailId;
        // let subject = message.subject;
        // let emailBody = 'Hi ';
        // document.location = "mailto:" + email + "?subject=" + subject + "&body=" + emailBody;
        this.setState({
            helpCenterPopup: true
        });
    }

    handleOpenDynamicTabPopup() {
        // this.setState({
        //   dynamicTabPopupDisplay: true
        // });
    }

    handleCloseDynamicTabPopup() {
        // this.setState({
        //   dynamicTabPopupDisplay: false
        // });
    }

    AddDynamicTab(selectedParam) {
        this.state.dynamicTabPopupDisplay = false;
        Action.addDynamicNavigationTab(selectedParam);
    }

    handleDeleteNavTab(e, name) {
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();
        Action.deleteDynamicNavigationTab(name);
    }

    handleRefreshOnClick() {
                 Action.refreshTradeStateData();
            Action.refreshTradeStateSummaryData();
    }

    closeHelpCenterPopup() {
        this.setState({
            helpCenterPopup: false,
        });
    }

    closeFeedbackCenterPopup() {
        this.setState({
            feedbackPopup: false
        });
    }

    openFeedbackPopup() {
        this.setState({
            helpCenterPopup: false,
            feedbackPopup: true
        });
    }

    openHelpPopup() {
        this.setState({
            helpCenterPopup: true,
            feedbackPopup: false
        });
    }
    handleSettingMouseEnter(e) {
        this.settingPopup.xposition = e.target.getBoundingClientRect().right;
        this.settingPopup.yposition = e.target.getBoundingClientRect().bottom;
        this.setState({
            settingCssProps: {
                display: 'block'
            }
        });
        this.setState({
            settingPopup: false
        });
    }

    handleSettingMouseLeave(e) {
        this.setState({
            settingCssProps: {
                display: 'none'
            }
        });
    }
    handleSettingClick() {
        this.setState({
            settingPopup: true
        });
    }
    closeSettingPopup() {
        this.setState({
            settingPopup: false,
        });
    }

    handleMouseEnterNavOption(e) {
        this.navOptionPopup.xposition = e.target.getBoundingClientRect().right - 20;
        this.navOptionPopup.yposition = e.target.getBoundingClientRect().bottom - 20;
        this.setState({
            showNavOption: true
        });
    }

    handleMouseLeaveNavOption() {
        this.setState({
            showNavOption: false
        });
    }

    handleLogoutCLick() {
        Action.logoutUser();
    }

    render() {
        if (!userDetailDataStore.getLoggedInStatus()) {
            hashHistory.push('login');
            return (<div></div>);
        }
        let navOptionStyle = {
            'position': 'fixed',
            'top': this.navOptionPopup.yposition,
            'left': this.navOptionPopup.xposition
        };
        if (this.state.showNavOption) {
            navOptionStyle.display = 'block';
        }
        else {
            navOptionStyle.display = 'none';
        }
        let popupStyle = {
            display: this.state.cssProps.display,
            'position': 'fixed',
            'top': this.popup.yposition - 2,
            'left': this.popup.xposition
        };
        let setttingPopupStyle = {
            display: this.state.settingCssProps.display,
            'position': 'fixed',
            'top': this.settingPopup.yposition - 2,
            'left': this.settingPopup.xposition - 24
        };
        if (this.state.chatPopupDisplay || this.state.chatPopup != null) {
            this.state.chatPopup = <ChatPopup chatShow={this.state.chatPopupDisplay} closeChat={this.handleImClick.bind(this)} />;
        }
        let helpCenterTab;
        if (this.state.helpCenterPopup) {
            helpCenterTab = <HelpCenter openFeedbackPopup={this.openFeedbackPopup.bind(this)} closeHelpCenterPopup={this.closeHelpCenterPopup.bind(this)} />
        }
        let feedbackTab;
        if (this.state.feedbackPopup) {
            feedbackTab = <Feedback openHelpPopup={this.openHelpPopup.bind(this)} closeFeedbackCenterPopup={this.closeFeedbackCenterPopup.bind(this)} />
        }
        let settingTab;
        if (this.state.settingPopup) {
            settingTab = <Setting closeSettingPopup={this.closeSettingPopup.bind(this)} />
        }
        let dynamicTabs = this.state.dynamicTabData.map((item) => {
            return (
                <div className={this.getTabClassName(item.link)} onClick={(e) => { hashHistory.push('app/dynamic/' + item.link) }}>
                    <span className='navigationpanel-tab-span'>{item.name}</span>
                    <span className='navigationpanel-tab-span-minus' onClick={(e) => { this.handleDeleteNavTab(e, item.name) }}>--</span>
                </div>
            );
        });

        let dashboardChangeStyle = {
            display: 'none'
        };
        if (this.state.dashboardChanged && !(this.props.children.props.route.component.name == 'EwDashboard')) {
            dashboardChangeStyle.display = 'block';
        }

        let dashboardChangedCOntainer = <DashboardChange style={dashboardChangeStyle} value={userDetailDataStore.getDashboardChangedValues()} />;
        return (
            <div className='app-div'>
                <div className='navigationpanel-container-div'>
                    <div className='navigationpanel-citi-logo-container'>
                        <div className='navigationpanel-citi-logo'>
                        </div>
                    </div>
                    <div className='navigationpanel-tabs-div'>
                        <div className='navigationpanel-tabs-text'>
                            Trade Life Cycle
</div>
                        <div className='navigationpanel-tabs-left-bottom-div'>
                            <div className='ewdashboard-header-nav-option-div' onMouseEnter={(e) => { this.handleMouseEnterNavOption(e) }}
                                onMouseLeave={(e) => { this.handleMouseLeaveNavOption() }}>
                                <NavigationOption style={navOptionStyle} />
                            </div>
                            <div className={this.getTabClassName('TradeState')} onClick={(e) => { hashHistory.push('ts/tradestate') }}>
                                <span className='navigationpanel-tab-span'>Trade Life Cycle</span>
                            </div>
                            {dynamicTabs}
                            {/*<div className='navigationpanel-tab-addtab' onClick={(e) => { this.handleOpenDynamicTabPopup() }}>
                                <span className='navigationpanel-tab-span-add'>+</span>
                            </div>*/}
                            <DynamicTabAddPopup preFiledInput='' createTab={this.AddDynamicTab.bind(this)} closePopup={this.handleCloseDynamicTabPopup.bind(this)} display={this.state.dynamicTabPopupDisplay} />
                        </div>
                    </div>
                    <div className='navigationpanel-icons-div'>

                        <div className='navigationpanel-icons-left-bottom-div'>
                            <div className='ewdashboard-header-userdiv'>
                                <span className='ewdashboard-header-userdiv-span'>
                                    {userDetailDataStore.getUserName()}
                                </span>
                            </div>
                            <div className='navigationpanel-icon navigationpanel-icon-home' onClick={(e) => { hashHistory.push('home') }}></div>
                            <div className='navigationpanel-icon navigationpanel-icon-download' onMouseEnter={(e) => { this.handleDownloadMouseEnter(e) }} onMouseLeave={(e) => { this.handleDownloadMouseLeave(e) }}>
                                <div className='navigationpanel-icon-download-div' style={popupStyle}>
                                    <div className='navigationpanel-icon-download-type-div' onClick={(e) => { this.handleCsvDownloadClick() }}>CSV</div>
                                    <div className='navigationpanel-icon-download-type-div' onClick={(e) => { this.handleXlsDownloadClick() }}>Excel</div>
                                </div>

                            </div>

                            <div className='navigationpanel-icon navigationpanel-icon-refresh' onClick={() => { this.handleRefreshOnClick() }}></div>
                            <div className='navigationpanel-icon navigationpanel-icon-profile' ></div>
                            {/*<div className='navigationpanel-icon navigationpanel-icon-setting'/>*/}
                            <div className='navigationpanel-icon navigationpanel-icon-setting'
                                onClick={(e) => { this.handleSettingClick() }}>
                                {/*<div className='navigationpanel-icon-setting-div' style={setttingPopupStyle}>
                  <div className='navigationpanel-icon-setting-type-div' onClick={(e) => { this.handleSettingClick() }}>Workflow Configuration</div>
                </div>*/}
                            </div>
                            {settingTab}
                            <div className='navigationpanel-icon navigationpanel-icon-filter' ></div>
                            <div className='navigationpanel-icon navigationpanel-icon-im' onClick={(e) => { this.handleImClick() }}></div>
                            {this.state.chatPopup}
                            <div className='navigationpanel-icon navigationpanel-icon-help' onClick={(e) => { this.handleHelpClick() }}></div>
                            {helpCenterTab}
                            <div className='navigationpanel-icon navigationpanel-icon-logout' onClick={(e) => { this.handleLogoutCLick() }}></div>
                            {feedbackTab}
                            {dashboardChangedCOntainer}
                        </div>
                    </div>
                </div>

                <div id='componentDiv' className='component-view-div'>
                    {this.props.children}
                </div>
            </div>
        );
    }

    componentDidMount() {
        userDetailDataStore.on("HandleImClick", () => {
            this.handleImClick();
        });

        userDetailDataStore.on("HandleHelpClick", () => {
            this.handleHelpClick();
        });
    }

    componentWillUnmount() {
        userDetailDataStore.removeListener("DynamicDashboardNavigationTabUpdated", () => {
        });
    }

}
