import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'


class ExceptionSummaryDataStore extends EventEmitter {
  constructor() {
    super();
    this.data = {
      criticalitySummaryData: [{
        name: 'Critical', value: 0, exception: [{ name: 'Exception1', value: 0, status: [{ name: 'Status1', value: 0 }] }, { name: 'Exception2', value: 0, status: [{ name: 'Status2', value: 0 }] }, { name: 'Exception3', value: 0, status: [{ name: 'Status3', value: 0 }] },
        { name: 'Exception4', value: 0, status: [{ name: 'Status4', value: 0 }] }]
      },
      { name: 'High', value: 0, exception: [{ name: 'ExceptionH', value: 0, status: [{ name: 'Status', value: 0 }] }] },
      { name: 'Medium', value: 0, exception: [{ name: 'ExceptionM', value: 0, status: [{ name: 'Status', value: 0 }] }] }
        , { name: 'Low', value: 0, exception: [{ name: 'ExceptionL', value: 0, status: [{ name: 'Status', value: 0 }] }] }
        , { name: 'All', value: 0, exception: [{ name: 'ExceptionA', value: 0, status: [{ name: 'Status', value: 0 }] }] }
      ],
      criticalityLookup: [
        { value: 'critical', cssColor: '#ff3232', name: 'Critical' },
        { value: 'high', cssColor: '#FF8029', name: 'High' },
        { value: 'medium', cssColor: '#FFC000', name: 'Medium' },
        { value: 'low', cssColor: '#33adff', name: 'Low' },
        { value: 'all', cssColor: '#464646', name: 'All' }
      ],
      activeCriticality: 'Critical',
      activeListPopUpIndex: -1,
    }
  }

  changeSummaryData(action) {
    console.log("CHANGE========>",action.type);
    switch (action.type) {
      case 'CHANGE_ACTIVE_CRITICALITY': {
        console.log("CHANGE_ACTIVE_CRITICALITY");
        this.data.activeCriticality = action.text;
        this.data.activeListPopUpIndex = -1;
        this.emit('ResetIndexOfChossenExceptionCategory');
        this.emit("ActiveCriticalityChanged");
        this.emit("ResetPageNumber");
        break;
      }
      case 'CHANGE_ACTIVE_CRITICALITY_ONLY': {
        console.log("CHANGE_ACTIVE_CRITICALITY_ONLY");
        this.data.activeCriticality = action.text;
        this.data.activeListPopUpIndex = -1;
        this.emit('ResetIndexOfChossenExceptionCategory');
        this.emit("ResetPageNumber");
        break;
      }
      case 'CRITICALITY_SUMMARY_DATA_REFRESH': {
        console.log("CRITICALITY_SUMMARY_DATA_REFRESH");
        this.data.criticalitySummaryData = action.text;
        // this.emit('ResetIndexOfChossenExceptionCategory');
        this.emit("CriticalitySmmaryDataRefreshed");
        break;
      }
      case 'ACTIVE_LIST_POPUP_INDEX_CHANGE': {
        // console.log("ACTIVE_LIST_POPUP_INDEX_CHANGE");
        if (this.data.activeListPopUpIndex === action.text) {
          this.data.activeListPopUpIndex = -1;
        }
        else {
          this.data.activeListPopUpIndex = action.text;
        }
        this.emit("ActiveCategoryListPopUpIndexChanged");
        break;
      }
    }


  }

  clearPopIndex(){
    this.data.activeListPopUpIndex=-1;
  }

  getCriticalityLookup() {
    return this.data.criticalityLookup;
  }

  getActiveCriticality() {
    return this.data.activeCriticality;
  }

  getActiveCriticalityValue() {
    return this.data.criticalityLookup.find((item) => { return this.data.activeCriticality === item.name }).value;
  }

    getActiveCriticalityColor() {
    return this.data.criticalityLookup.find((item) => { return this.data.activeCriticality === item.name }).cssColor;
  }

  getCriticalitySummaryData() {

    return this.data.criticalitySummaryData;
  }

  getActiveSummaryDataException() {
    return this.data.criticalitySummaryData.find((item) => {
      return item.name === this.data.activeCriticality;
    }).exception;
  }

  getCriticalSummaryDataCount(name) {
   
    return this.data.criticalitySummaryData.find((item) => {
      return item.name === name;
    }).value;
  }

  getActiveListPopUpIndex() {
    return this.data.activeListPopUpIndex;
  }

  getLastUpdateTime(){
    return this.data.lastUpdateTime;
  }


}

const exceptionSummaryDataStore = new ExceptionSummaryDataStore;
ActionDispatcher.register(exceptionSummaryDataStore.changeSummaryData.bind(exceptionSummaryDataStore));
export default exceptionSummaryDataStore;
