import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'


class GraphDataStore extends EventEmitter {
  constructor() {
    super();
    this.graphData = {
      graphTypeSelected: 'Stacked Bar Chart',
      chartData: [],
      graphTypeList: ['Pie Chart', 'Stacked Bar Chart', 'Stacked Column Chart', 'Tree Map Chart'],
      graphNameList: ['Exception by Asset Class','Exception by Stage'],
      graphNameSelected: 'Exception by Asset Class'
    };
  }

  changeGraphData(action) {
    switch (action.type) {
      case 'CHANGE_GRAPH_NAME_SELECTED': {
        console.log("CHANGE_GRAPH_NAME_SELECTED");
        this.graphData.graphNameSelected = action.text;
        this.emit("GraphNameSelectedChanged");
        break;
      }
      case 'CHANGE_GRAPH_TYPE_SELECTED': {
        console.log("CHANGE_GRAPH_TYPE_SELECTED");
        this.graphData.graphTypeSelected = action.text;
        this.emit("GraphTypeSelectedChanged");
        break;
      }
      case 'CHART_DATA_REFRESH': {
        console.log("CHART_DATA_REFRESH");
        this.graphData.chartData = action.text;
        this.emit("ChartDataRefreshed");
        break;
      }
    }
  }

  getChartData() {
    return this.graphData.chartData;
  }

  getGraphTypeSelected() {
    return this.graphData.graphTypeSelected;
  }

  getGraphNameSelected() {
    return this.graphData.graphNameSelected;
  }

  getGraphTypeList() {
    return this.graphData.graphTypeList;
  }

  getGraphNamelist() {
    return this.graphData.graphNameList;
  }

}

const graphDataStore = new GraphDataStore;
ActionDispatcher.register(graphDataStore.changeGraphData.bind(graphDataStore));
export default graphDataStore;
