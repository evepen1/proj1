import React from "react";
import { EventEmitter } from "events";
import ActionDispatcher from "../dispatcher/actionDispatcher";
import exceptionTableDataStore from "../store/exceptionTableDataStore";

class FileDownloadStore extends EventEmitter {
  constructor() {
    super();
    this.data = [];
    this.checkBoxData = [];
    this.currentPageData = [];

  }

  changeFileDownloadData(action) {
    switch (action.type) {
      case "REFRESH_FILE_DOWNLOAD_DATA": {
        let matchIndex = -1;
        for (let i in this.data) {
          let item = this.data[i];
          if (item._id === action.text._id && item.exceptionId === action.text.exceptionId
            && item.status === action.text.status) {
            matchIndex = i;
            break;
          }
        };
        if (matchIndex > -1) {
          this.data.splice(matchIndex, 1);
        } else {
          this.data.push(action.text);
        }

        this.emit('FileDataRefreshed');
        break;
      }

      case "REFRESH_ALL_FILE_DOWNLOAD_DATA": {
        //handle current page
        let matchIndex = -1;
        for (let i in this.currentPageData) {
          let item = this.currentPageData[i];
          if (item === action.text.currentPage) {
            matchIndex = i;
            break;
          }
        };
        if (matchIndex > -1) {
          this.currentPageData.splice(matchIndex, 1);
        } else {
          this.currentPageData.push(action.text.currentPage);
        }


        action.text.tempData.map((item, index) => {
          let matchIndex = -1;
          for (let i in this.checkBoxData) {
            let checkboxItem = this.checkBoxData[i];
            if (item._id === checkboxItem._id && item.exceptionId === checkboxItem.exceptionId
              && item.status === checkboxItem.status) {
              matchIndex = i;
              break;
            }
          }
          if (matchIndex > -1) {
            this.checkBoxData.splice(matchIndex, 1);
          } else {
            this.checkBoxData.push(item);
          }
        });
     
        //push data to data object
        this.data = []; 
        for (let i in this.checkBoxData) {
            let item = this.checkBoxData[i];
            this.data.push(item);
          }
      
      //  console.log(this.data);
        this.emit('FileDataRefreshed');
        break;
      }
    }


  }



  getDownloadedData() {
  //  console.log("data ");
    //console.log(this.data);
    return this.data;
  }

  checkedAllCurrentPage(currentPage) {

    let matchIndex = -1;

    for (let i in this.currentPageData) {
      let item = this.currentPageData[i];
      if (item === currentPage) {
        matchIndex = i;
        break;
      }
    };
    return matchIndex > -1;
  }

  isAlreadyExist(uiItem) {

    let matchIndex = -1;

    for (let i in this.data) {
      let item = this.data[i];
      if (item._id === uiItem._id && item.exceptionId === uiItem.exceptionId
        && item.status === uiItem.status) {
        matchIndex = i;
        break;
      }
    };

    return matchIndex > -1;
  }

  clearFileDataStore() {
    this.data = [];
  }

}

const fileDownloadStore = new FileDownloadStore();
ActionDispatcher.register(
  fileDownloadStore.changeFileDownloadData.bind(fileDownloadStore)
);
export default fileDownloadStore;
