import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'
import userDetailDataStore from './userDetailDataStore'
import exceptionSummaryDataStore from './exceptionSummaryDataStore'

class ActiveExceptionCategoryListStore extends EventEmitter {
  constructor() {
    super();
    this.data = {
      exceptionCountSummary: { "PRICING": { "type": "CRITICAL", "count": 0 }, "CONFIRMATION": { "type": "CRITICAL", "count": 0 }, "DATA DELIVERY": { "type": "CRITICAL", "count": 0 }, "SETTLEMENT": { "type": "CRITICAL", "count": 0 }, "ACCOUNTING": { "type": "CRITICAL", "count": 0 }, "TRADE CAPTURE": { "type": "CRITICAL", "count": 0 } },
      activeCategory: 'all',
      headerLookup: [
        { value: 'all', cssTag: 'showall', name: 'All' },
        { value: 'Trade_Capture', cssTag: 'tc', name: 'Trade Capture' },
        { value: 'Confirmation', cssTag: 'c', name: 'Confirmation' },
        { value: 'Pricing', cssTag: 'p', name: 'Pricing' },
        { value: 'Settlement', cssTag: 's', name: 'Settlement' },
        { value: 'Accounting', cssTag: 'a', name: 'Accounting' },
        { value: 'Data_Delivery', cssTag: 'dd', name: 'Data Delivery' }
      ],
      lastUpdateTime: new Date()
    };
  }

  changeActiveCategory(action) {
    switch (action.type) {
      case 'CATEGORY_CHANGED': {
        console.log("CATEGORY_CHANGED");
        this.data.activeCategory = action.text;
        exceptionSummaryDataStore.clearPopIndex();
        this.emit("ResetIndexOfChossenExceptionCategory");
        this.emit("ActiveCategoryChanged");
        this.emit("ResetPageNumber");
        break;
      }
      case 'CATEGORY_CHANGED_ONLY': {
        console.log("CATEGORY_CHANGED_ONLY");
        this.data.activeCategory = action.text;
        exceptionSummaryDataStore.clearPopIndex();
        this.emit("ResetIndexOfChossenExceptionCategory");
        this.emit("ResetPageNumber");
        break;
      }
      case 'EXCEPTION_COUNT_SUMMARY_REFRESH': {
        //   console.log("EXCEPTION_COUNT_SUMMARY_REFRESH");
        this.data.exceptionCountSummary = action.text;
        this.data.lastUpdateTime = new Date();
        this.emit("ExceptionCountSummaryRefreshed");
        break;
      }
    }
  }

  getActiveCategoryValue(name) {
    return this.data.headerLookup.find((item) => {
      return item.name == name;
    }).value;
  }

  getActiveCategory() {
    return this.data.activeCategory;
  }

  getHeaderLookup() {
    let headerLookup = this.data.headerLookup.filter((item) => {
      return userDetailDataStore.getWorkflowConf().stages.indexOf(item.name.toUpperCase()) > -1
    });
    return headerLookup;
  }

  getExceptionCountSummary() {
    return this.data.exceptionCountSummary;
  }

  getLastUpdateTime() {
    return this.data.lastUpdateTime;
  }

}

const activeExceptionCategoryListStore = new ActiveExceptionCategoryListStore;
ActionDispatcher.register(activeExceptionCategoryListStore.changeActiveCategory.bind(activeExceptionCategoryListStore));
export default activeExceptionCategoryListStore;
