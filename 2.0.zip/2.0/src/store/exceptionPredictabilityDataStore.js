import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'

class ExceptionPredictabilityDataStore extends EventEmitter {

    constructor() {
        super();
        this.data = {
            exceptionPredictability: {
                projectedexception: {
                    
                    firm: {
                        fstp: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 ]
                        },
                        omgi: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 ]
                        },
                        sli: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 ]
                        },
                        dfa: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 ]
                        }
                    },
                     exceptioncategory: {
                        tradecapture: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        },
                        pricing: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        },
                        confirmation: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        }
                    },
                     source: {
                        mom: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        },
                        moto: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        },
                        confirmation: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        }
                    }
                },
                 projectedcost: {
                    firm: {
                        fstp: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 ]
                        },
                        omgi: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 ]
                        },
                        sli: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 ]
                        },
                        dfa: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 , Math.floor(Math.random() * 999) + 1 ]
                        }
                    },
                     exceptioncategory: {
                        tradecapture: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        },
                        pricing: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        },
                        confirmation: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        }
                    },
                     source: {
                        mom: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        },
                        moto: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1, Math.floor(Math.random() * 999) + 1]
                        }
                    }
                },
                 probabilityslabreach: {
                    firm: {
                        fstp: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2]
                        },
                        omgi: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2]
                        },
                        sli: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2]
                        },
                        dfa: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2]
                        }
                    },
                    exceptioncategory: {
                        tradecapture: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2]
                        },
                        accounting: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2]
                        },
                        settlement: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2]
                        },
                        confirmation: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2]
                        },
                        datadelivery: {
                            categories: [2015, 2016, 2017, 2018, 2019],
                            data: [Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2, Math.random()*0.2]
                        }
                    }
                }
            }
        }
    }

    changeExceptionPredictabilityData(action) {
        switch (action.type) {

        }
    }

    getExceptionPredictabilityData() {
        return this.data.exceptionPredictability;
    }

}


const exceptionPredictabilityDataStore = new ExceptionPredictabilityDataStore;
ActionDispatcher.register(exceptionPredictabilityDataStore.changeExceptionPredictabilityData.bind(exceptionPredictabilityDataStore));
export default exceptionPredictabilityDataStore;