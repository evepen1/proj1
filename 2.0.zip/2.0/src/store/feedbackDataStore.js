import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'


class FeedbackDataStore extends EventEmitter {
    constructor() {
        super();
        this.data = {
            feedbackSelector: [
                {
                    value: 'Idea'
                },
                {
                    value: 'Question'
                },
                {
                    value: 'Problem'
                },
                {
                    value: 'Praise'
                }
            ],
            feedbackSelectorSelected: 'Idea'
        };
    }

    changeFeedbackData(action) {
        switch (action.type) {
            case 'CHANGE_FEEDBACK_CATEGORY': {
                this.data.feedbackSelectorSelected=action.text;
                this.emit('FeedbackTypeSelectedChanged');
                break;
            }
        }
    }

    getFeedbackSelector() {
        return this.data.feedbackSelector;
    }

    getFeedbackSelected() {
        return this.data.feedbackSelectorSelected;
    }

}

const feedbackDataStore = new FeedbackDataStore;
ActionDispatcher.register(feedbackDataStore.changeFeedbackData
    .bind(feedbackDataStore));
export default feedbackDataStore;