import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'


class HelpCenterDataStore extends EventEmitter {
    constructor() {
        super();
        this.data = {
            productDetails: [{
                title: 'MOM',
                detail: 'MOM application description',
                number: '+123-456-7890',
                mail: 'mom@citi.com'
            }, {
                title: 'MOTO',
                detail: 'MOTO application description',
                number: '+123-456-7890',
                mail: 'moto@citi.com',
                bgcolor: '#19B5FE'
            }, {
                title: 'Multifond',
                detail: 'Multifond application description',
                number: '+123-456-7890',
                mail: 'multifond@citi.com',
                bgcolor: '#F39C12'
            }, {
                title: 'Calypso',
                detail: 'Calypso application description',
                number: '+123-456-7890',
                mail: 'calypso@citi.com',
                bgcolor: '#F64747'
            }, {
                title: 'Parser',
                detail: 'Parser application description',
                number: '+123-456-7890',
                mail: 'parser@citi.com',
                bgcolor: '#913D88'
            }],
            faq: [
                {
                    question: 'Ques',
                    answer: 'Ans'
                },
                {
                    question: 'Ques',
                    answer: 'Ans'
                },
                {
                    question: 'Ques',
                    answer: 'Ans'
                },
                {
                    question: 'Ques',
                    answer: 'Ans'
                },
                {
                    question: 'Ques',
                    answer: 'Ans'
                },
                {
                    question: 'Ques',
                    answer: 'Ans'
                }
            ]
        };
    }

    changeHelpCenterData(action) {
        switch (action.type) {
            case 'TEST__': {
                break;
            }
        }
    }

    getProductDetails() {
        return this.data.productDetails;
    }

    getFaq() {
        return this.data.faq;
    }

}

const helpCenterDataStore = new HelpCenterDataStore;
ActionDispatcher.register(helpCenterDataStore.changeHelpCenterData
    .bind(helpCenterDataStore));
export default helpCenterDataStore;