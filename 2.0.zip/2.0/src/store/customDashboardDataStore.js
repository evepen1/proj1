import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'
import request from 'sync-request'

class CustomDashboardDataStore extends EventEmitter {
  constructor() {
    super();
    this.customDashboardData = {
      custDashTab: [{
        name: 'MOM', tabs: [{ graphType: 'Pie Chart', graphName: 'Client Volume Status', chartData: [] },
        { graphType: 'Stacked Bar Chart', graphName: 'Client Volume Status', chartData: [] },
        { graphType: 'Tree Map Chart', graphName: 'Client Volume Status', chartData: [] }]
      }
        , { name: 'MOTO', tabs: [] }, { name: 'Calypso', tabs: [] }, { name: 'MF loader', tabs: [] }, { name: 'Saturn', tabs: [] }],
      selectedCustTab: 'MOM'
    };
  }

  changeCustomDashboardData(action) {
    switch (action.type) {
      case 'ADD_NEW_TAB': {
        console.log("ADD_NEW_TAB");
        action.text.tabs = [];
        this.customDashboardData.custDashTab.push(action.text);
        this.emit("AddNewTabDone");
        break;
      }
      case 'CUSTOM_TAB_CHANGE': {
        console.log("CUSTOM_TAB_CHANGE");
        this.customDashboardData.selectedCustTab = action.text;
        this.emit("CustomTabChangeDone");
        break;
      }
      case 'TAB_CHART_DATA_CHANGE_' + action.text.index: {
        console.log('TAB_CHART_DATA_CHANGE_' + action.text.index);
        this.customDashboardData.custDashTab.find(function (eachSeg) {
          return eachSeg.name == action.text.name;
        }).tabs[action.text.index].chartData = action.text.chartData;
        this.emit('TabChartDataChanged_' + action.text.index);
        break;
      }
      case 'REMOVE_DASHBOARD_TAB': {
        console.log("REMOVE_DASHBOARD_TAB");
        for (var i = 0; i < this.customDashboardData.custDashTab.length; ++i) {
          if (this.customDashboardData.custDashTab[i].name == action.text) {
            this.customDashboardData.custDashTab.splice(i, 1);
          }
        }
        this.emit("RemoveTabDone");
        break;
      }
      case 'REMOVE_GRAPH_CONTAINER': {
        console.log("REMOVE_GRAPH_CONTAINER");
        for (var i = 0; i < this.customDashboardData.custDashTab.length; ++i) {
          console.log(action.text);
          console.log(this.customDashboardData.custDashTab[i].name + action.text.name);
          if (this.customDashboardData.custDashTab[i].name == action.text.name) {
            this.customDashboardData.custDashTab[i].tabs.splice(action.text.index, 1);
            console.log(this.customDashboardData.custDashTab[i]);
            break;
          }
        }
        this.emit("RemoveGraphContainerDone");
        break;
      }
      case 'ADD_GRAPH_CONTAINER': {
        console.log("ADD_GRAPH_CONTAINER");
        for (var i = 0; i < this.customDashboardData.custDashTab.length; ++i) {
          console.log(action.text);
          console.log(this.customDashboardData.custDashTab[i].name + action.text);
          if (this.customDashboardData.custDashTab[i].name == action.text) {
            this.customDashboardData.custDashTab[i].tabs.push({ graphType: 'Stacked Column Chart', graphName: 'Client Volume Status', chartData: [] });
            console.log(this.customDashboardData.custDashTab[i]);
            break;
          }
        }
        this.emit("AddGraphContainerDone");
        break;
      }
      case 'GRAPH_NAME_CHANGE': {
        console.log("GRAPH_NAME_CHANGE");
        this.getSelectedCustTab().tabs[action.text.index].graphName = action.text.value;
        break;
      }
      case 'GRAPH_TYPE_CHANGE': {
        console.log("GRAPH_TYPE_CHANGE");
        this.getSelectedCustTab().tabs[action.text.index].graphType = action.text.value;
        break;
      }
    }
  }

  getCustomDashboardTabData() {
    return this.customDashboardData.custDashTab;
  }

  getSelectedCustTabName() {
    return this.customDashboardData.selectedCustTab;
  }

  getSelectedCustTab() {
    for (var i = 0; i < this.customDashboardData.custDashTab.length; ++i) {
      if (this.customDashboardData.custDashTab[i].name == this.customDashboardData.selectedCustTab) {
        return this.customDashboardData.custDashTab[i];
      }
    }
  }

  getGraphName(name, i) {
    return this.customDashboardData.custDashTab.find(function (eachSeg) {
      return eachSeg.name == name;
    }).tabs[i].graphName;
  }

}

const customDashboardDataStore = new CustomDashboardDataStore;
ActionDispatcher.register(customDashboardDataStore.changeCustomDashboardData.bind(customDashboardDataStore));
export default customDashboardDataStore;
customDashboardDataStore
