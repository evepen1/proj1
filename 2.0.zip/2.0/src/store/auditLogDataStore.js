import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'
import DynamicDashboard from '../component/GfsMetricsDashboard/DynamicDashboard';
import RankingDynamicDashboard from '../component/RankingDashboard/RankingDynamicDashboard';
import { hashHistory } from 'react-router';

class AuditLogDataStore extends EventEmitter {
    constructor() {
        super();
        this.data = {
            auditHistory: [],
            auditFilterActive: false,
            auditFilter: {},
            headerList: [
                { displayName: 'Firm Code', fieldName: 'firmCode' },
                { displayName: 'Allocation Id', fieldName: 'allocationId' },
                { displayName: 'Exception Description', fieldName: 'errorDescription' },
                { displayName: 'Changed by', fieldName: 'user' },
                { displayName: 'Field updated', fieldName: 'fieldName' },
                { displayName: 'Old Value', fieldName: 'oldValue' },
                { displayName: 'New Value', fieldName: 'newValue' },
                { displayName: 'Approver', fieldName: 'approver' },
                { displayName: 'Remarks', fieldName: 'remark' },
                { displayName: 'Time', fieldName: 'time' }
            ],
        }
    }

    changeAuditLog(action) {
        switch (action.type) {
            case 'UPDATE_AUDIT_HISTORY': {
                console.log('UPDATE_AUDIT_HISTORY');
                this.data.auditHistory = action.text;
                this.emit('updateAuditHistory');
                break;
            }
            case 'CHANGE_AUDIT_FILTER_VALUE': {
                console.log('CHANGE_AUDIT_FILTER_VALUE');
                this.data.auditFilter[action.text.fieldName] = action.text.newValue;
                this.emit('auditFilterValueChanged');
                break;
            }
            case 'CHANGE_AUDIT_FILTER_STATUS': {
                console.log('CHANGE_AUDIT_FILTER_STATUS');
                this.data.auditFilterActive = action.text;
                if (!action.text) {
                    this.data.auditFilter = {};
                }
                this.emit('auditFIlterStatusChanged');
                break;
            }
        }
    }

    getAuditHistory() {
        let filteredValue = [];
        let filterConditionFieldName = Object.keys(this.data.auditFilter);
        if (filterConditionFieldName.length == 0) {
            return this.data.auditHistory;
        }
        else {
            this.data.auditHistory.forEach((item) => {
                let filteredSufilteringStatus = true;
                filterConditionFieldName.forEach((fieldName) => {
                    if (item[fieldName].search(new RegExp(this.data.auditFilter[fieldName], 'i')) < 0) {
                        filteredSufilteringStatus = false;
                    }
                });
                if (filteredSufilteringStatus) {
                    filteredValue.push(item);
                }
            });
        }
        return filteredValue;
    }

    getHeaderList() {
        return this.data.headerList;
    }
    getAuditFilterStatus() {
        return this.data.auditFilterActive;
    }
    getAuditFilter() {
        return this.data.auditFilter;
    }
}

const auditLogDataStore = new AuditLogDataStore;
auditLogDataStore.setMaxListeners(100);
ActionDispatcher.register(auditLogDataStore.changeAuditLog.bind(auditLogDataStore));
export default auditLogDataStore;