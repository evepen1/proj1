import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'


class TradeStateDataStore extends EventEmitter {
    constructor() {
        super();
        this.data = {
            tradeStateSummaryData: {},
            tableData: [],
            headerList: [
                { displayName: 'Client', fieldName: 'client' },
                { displayName: 'Trade Id', fieldName: 'tradeId' },
                { displayName: 'Block Id', fieldName: 'blockId' },
                { displayName: 'Asset Class', fieldName: 'assetClass' },
                { displayName: 'Fund', fieldName: 'fund' },
                { displayName: 'Trade Capture', fieldName: 'tradeCapture' },
                { displayName: 'Confirmation', fieldName: 'confirmation' },
                { displayName: 'Settlement', fieldName: 'settlement' },
                { displayName: 'Accounting', fieldName: 'accounting' },
                { displayName: 'Data Delivery', fieldName: 'dataDelivery' }
            ],
            summaryHeaderList: [
                { displayName: 'Trade Capture', fieldName: 'tradeCapture' },
                { displayName: 'Confirmation', fieldName: 'confirmation' },
                { displayName: 'Settlement', fieldName: 'settlement' },
                { displayName: 'Accounting', fieldName: 'accounting' },
                { displayName: 'Data Delivery', fieldName: 'dataDelivery' }
            ]
        };
    }


    changeTradeStateData(action) {
        switch (action.type) {
            case 'TRADE_STATE_DATA_REFRESH': {
                console.log("TRADE_STATE_DATA_REFRESH");
                this.data.tableData = action.text;
                this.emit("TradeStateDataRefreshed");
                break;
            }
            case 'TRADE_STATE_SUMMARY_DATA_REFRESH': {
                console.log("TRADE_STATE_SUMMARY_DATA_REFRESH");
                this.data.tradeStateSummaryData = action.text;
                this.emit("TradeStateSummaryDataRefreshed");
                break;
            }
        }
    }

    getTradeStateData() {
        return this.data.tableData;
    }

    getTradeStateHeaderList() {
        return this.data.headerList;
    }

    getTradeStateSummaryData() {
        return this.data.tradeStateSummaryData;
    }
    getTradeStateSummaryHeaderList() {
        return this.data.summaryHeaderList;
    }
}

const tradeStateDataStore = new TradeStateDataStore;
ActionDispatcher.register(tradeStateDataStore.changeTradeStateData.bind(tradeStateDataStore));
export default tradeStateDataStore;