import ActionDispatcher from '../dispatcher/actionDispatcher'
import Request from 'superagent';
import __ from 'lodash';
import { hashHistory } from 'react-router';
import activeExceptionCategoryListStore from '../store/actveExceptionCategoryStore'
import activeExceptionCategoryListAborNavStore from '../store/activeExceptionCategoryListAborNavStore'
import exceptionSummaryDataStore from '../store/exceptionSummaryDataStore';
import exceptionSummaryAborNavDataStore from '../store/exceptionSummaryAborNavDataStore';
import exceptionTableDataStore from '../store/exceptionTableDataStore'
import userDetailDataStore from '../store/userDetailDataStore'
import graphDataStore from '../store/graphDataStore'
import graphAborNavDataStore from '../store/graphAborNavDataStore'

var url_node = process.env.EXCEPTION_API_URL + ':' + process.env.EXCEPTION_API_PORT;

function getExceptionTableData(q, c) {
  var url = url_node + '/exceptiontradedetails?q=' + q + '&type=' + c + '&client=' + userDetailDataStore.getClientFilterActive() +
    '&sla=' + encodeURI(userDetailDataStore.getSLAFilterActive());
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      ActionDispatcher.dispatch({
        type: "TABLE_DATA_REFRESH",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error fetching data', error);
      return {};
    }
  }
  );
}

function getAiuditHistory() {
  var url = url_node + '/audithistory';
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      ActionDispatcher.dispatch({
        type: "UPDATE_AUDIT_HISTORY",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error fetching data', error);
      return {};
    }
  }
  );
}

function getExceptionTableAborNavData(c) {
  var url = url_node + '/nav/navtradedetails?type=' + c;
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      ActionDispatcher.dispatch({
        type: "TABLE_ABOR_NAV_DATA_REFRESH",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error fetching data', error);
      return {};
    }
  }
  );
}

function getTradeDetail(allocId) {
  var url = url_node + '/tradedetail?allocId=' + allocId;
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      ActionDispatcher.dispatch({
        type: "TRADE_DETAIL_REFRESH",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error fetching data', error);
      return {};
    }
  }
  );
}

function getExceptionCountSummary(q) {
  var url = url_node + '/exceptioncriticality?q=' + q + '&client=' + userDetailDataStore.getClientFilterActive() +
    '&sla=' + encodeURI(userDetailDataStore.getSLAFilterActive());;
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log("Get expected count Data from Middleend");
      ActionDispatcher.dispatch({
        type: "EXCEPTION_COUNT_SUMMARY_REFRESH",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error getting expected count data ', error);
      return {};
    }
  }
  );
}

function getDownloadData(q, c) {
  var url = url_node + '/exceptiontradedetails?q=' + q + '&type=' + c + '&client=' + userDetailDataStore.getClientFilterActive();
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      ActionDispatcher.dispatch({
        type: "DOWNLOAD_DATA_BROUGHT",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error fetching data', error);
      return {};
    }
  }
  );
}

function getCriticalitySummaryData(category) {
  
  var url = url_node + '/exceptionsummary?q=' + category + '&client=' + userDetailDataStore.getClientFilterActive() +
    '&sla=' + encodeURI(userDetailDataStore.getSLAFilterActive());
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      ActionDispatcher.dispatch({
        type: "CRITICALITY_SUMMARY_DATA_REFRESH",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error fetching data', error);
      return {};
    }
  }
  );
}

function getCriticalitySummaryAborNavData() {
  var url = url_node + '/nav/navexceptionsummary';
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      ActionDispatcher.dispatch({
        type: "CRITICALITY_SUMMARY_ABOR_NAV_DATA_REFRESH",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error fetching data', error);
      return {};
    }
  }
  );
}

function getGraphData(q) {
  var url = url_node + '/graph/' + q + '?client=' + userDetailDataStore.getClientFilterActive() +
    '&sla=' + encodeURI(userDetailDataStore.getSLAFilterActive());
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      ActionDispatcher.dispatch({
        type: "CHART_DATA_REFRESH",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error fetching graph data', error);
      return {};
    }
  }
  );
}

function getGraphAborNavData(q) {
  var url = url_node + '/nav/graph/' + q;
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      ActionDispatcher.dispatch({
        type: "CHART_ABOR_NAV_DATA_REFRESH",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error fetching graph data', error);
      return {};
    }
  }
  );
}

function generateQueryString(categoryList) {
  var qStr = '';
  categoryList.map((item, index) => {
    if (index == 0) {
      qStr = qStr + item;
    }
    else {
      qStr = qStr + '+' + item;
    }
  });
  if (qStr === '') {
    return 'all';
  }
  return qStr;
}

function getQueryForSelectedDropdownvalue(selectedValue) {
  var q = '';
  switch (selectedValue) {
    case 'Exception by Stage': {
      q = 'clientvolume';
      break;
    }
    case 'Exception by Asset Class': {
      q = 'clientasset';
      break;
    }
  }
  return q;
}

function getQueryForSelectedAborNavDropdownvalue(selectedValue) {
  var q = '';
  switch (selectedValue) {
    case 'Exception by Branch': {
      q = 'exceptionbybranch';
      break;
    }
    case 'Exception by Client': {
      q = 'exceptionbyclient';
      break;
    }
  }
  return q;
}


export function changeActiveCategory(newActiveCategory) {
  console.log('Active category change event Triggered');
  ActionDispatcher.dispatch({
    type: "CATEGORY_CHANGED",
    text: newActiveCategory
  })
}

export function changeActiveCategoryOnly(newActiveCategory) {
  console.log('Active category change event Triggered');
  ActionDispatcher.dispatch({
    type: "CATEGORY_CHANGED_ONLY",
    text: newActiveCategory
  })
}

export function changeActiveCriticality(newActiveCriticality) {
  console.log('Active criticality change event Triggered');
  ActionDispatcher.dispatch({
    type: "CHANGE_ACTIVE_CRITICALITY",
    text: newActiveCriticality
  })
}

export function changeActiveCriticalityOnly(newActiveCriticality) {
  console.log('Active criticality change event Triggered');
  ActionDispatcher.dispatch({
    type: "CHANGE_ACTIVE_CRITICALITY_ONLY",
    text: newActiveCriticality
  })
}

export function changeActiveCriticalityAborNav(newActiveCriticality) {
  console.log('Active criticality ABOR NAV change event Triggered');
  ActionDispatcher.dispatch({
    type: "CHANGE_ACTIVE_CRITICALITY_ABOR_NAV",
    text: newActiveCriticality
  })
}

export function refereshCriticalitySummaryData(category) {
  console.log('Active criticality change event Triggered');
  getCriticalitySummaryData(category);
}

export function refereshCriticalitySummaryAborNavData() {
  console.log('Active criticality Abor Nav change event Triggered');
  getCriticalitySummaryAborNavData();
}

export function updateAuditHistory() {
  console.log('Get Audit Hostory data event Triggered');
  getAiuditHistory();
}

export function changeActiveListPopUpIndex(newGnewIndex) {
  // console.log('Active graph type change event Triggered');
  ActionDispatcher.dispatch({
    type: "ACTIVE_LIST_POPUP_INDEX_CHANGE",
    text: newGnewIndex
  })
}

export function changeActiveListAborNavPopUpIndex(newGnewIndex) {
  // console.log('Active graph type change event Triggered');
  ActionDispatcher.dispatch({
    type: "ACTIVE_LIST_ABOR_NAV_POPUP_INDEX_CHANGE",
    text: newGnewIndex
  })
}

// Graph Division

export function changeGraphName(newGraphName) {
  console.log('Active graph name change event Triggered');
  ActionDispatcher.dispatch({
    type: "CHANGE_GRAPH_NAME_SELECTED",
    text: newGraphName
  })
}

export function changeGraphNameAborNav(newGraphName) {
  console.log('Active graph name abor nav change event Triggered');
  ActionDispatcher.dispatch({
    type: "CHANGE_GRAPH_NAME_SELECTED_ABOR_NAV",
    text: newGraphName
  })
}

export function changeGraphType(newGraphType) {
  console.log('Active graph type change event Triggered');
  ActionDispatcher.dispatch({
    type: "CHANGE_GRAPH_TYPE_SELECTED",
    text: newGraphType
  })
}

export function changeGraphTypeAborNav(newGraphType) {
  console.log('Active graph type change ABOR NAV event Triggered');
  ActionDispatcher.dispatch({
    type: "CHANGE_GRAPH_TYPE_SELECTED_ABOR_NAV",
    text: newGraphType
  })
}

export function refreshChartData(graphName) {
  console.log('Refresh chart data event Triggered');
  getGraphData(getQueryForSelectedDropdownvalue(graphName));
}

export function refreshChartAborNavData(graphName) {
  console.log('Refresh chart data abor nav event Triggered');
  getGraphAborNavData(getQueryForSelectedAborNavDropdownvalue(graphName));
}

export function refreshExceptionCountSummaryData(activeCriticality) {
  console.log('Refresh exception count summary data event Triggered');
  getExceptionCountSummary(activeCriticality);
}

export function refreshExceptionTableData(category, criticality) {
  console.log('Refresh exception table data event Triggered');
  getExceptionTableData(category, criticality);
}

export function refreshExceptionTableAborNavData(criticality) {
  console.log('Refresh exception table data ABOR NAV event Triggered');
  getExceptionTableAborNavData(criticality);
}

export function refreshFileDownloadData(item) {
  ActionDispatcher.dispatch({
    type: "REFRESH_FILE_DOWNLOAD_DATA",
    text: item
  });
}

export function updateComment(commentUpdate) {
  var url = url_node + '/updatecomment';
  console.log('URL - ' + url);
  console.log(commentUpdate);
  Request.post(url).send(commentUpdate).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log("Post update comment Data from Middleend");
      console.log(response.body);
      refreshExceptionTableData(activeExceptionCategoryListStore.getActiveCategory(), exceptionSummaryDataStore.getActiveCriticalityValue());
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating comment data', error);
      //e.value = prevComment;
      return {};
    }
  }
  );
}

export function updateStatus(e, prevStatus, statusUpdate) {
  var url = url_node + '/updatestatus';
  console.log('URL - ' + url);
  console.log(statusUpdate);
  Request.post(url).send(statusUpdate).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log("Post update status Data from Middleend");
      console.log(response.body);
      refereshCriticalitySummaryData(activeExceptionCategoryListStore.getActiveCategory());
      refreshExceptionCountSummaryData(exceptionSummaryDataStore.getActiveCriticality());
      refreshChartData(graphDataStore.getGraphNameSelected());
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      e.value = prevStatus;
      return {};
    }
  }
  );
}


export function refreshSelectedDropdownValue(value) {
  console.log('REFRESH SELECTED DROP DOWN with ' + value);
  ActionDispatcher.dispatch({
    type: "DROP_DOWN_CHANGE",
    text: value
  })
}

export function refreshAllFileDownloadData(item) {
  ActionDispatcher.dispatch({
    type: "REFRESH_ALL_FILE_DOWNLOAD_DATA",
    text: item
  });
}

export function addGfsMetricsUserConf() {
  console.log('Add gfs metrics user conf tab');
  ActionDispatcher.dispatch({
    type: "ADD_GFS_METRICS_USER_TAB",
    text: null
  })
}

export function addRankingMetricsUserConf() {
  console.log('Add ranking metrics user conf tab');
  ActionDispatcher.dispatch({
    type: "ADD_RANKING_METRICS_USER_TAB",
    text: null
  })
}

export function addExceptionPredictabilityUserConf() {
  console.log('Add exception predictability user conf tab');
  ActionDispatcher.dispatch({
    type: "ADD_EXCEPTION_PREDICTABILITY_USER_TAB",
    text: null
  })
}

export function deleteGfsMetricsUserConf(deleteTab) {
  console.log('Delete gfs metrics user conf tab');
  ActionDispatcher.dispatch({
    type: "DELETE_GFS_METRICS_USER_TAB",
    text: deleteTab
  })
}

export function deleteExceptionPredictabilityUserConf(deleteTab) {
  console.log('Delete exception predictability user conf tab');
  ActionDispatcher.dispatch({
    type: "DELETE_EXCEPTION_PREDICTABILITY_USER_TAB",
    text: deleteTab
  })
}

export function deleteRankingMetricsUserConf(deleteTab) {
  console.log('Delete ranking metrics user conf tab');
  ActionDispatcher.dispatch({
    type: "DELETE_RANKING_METRICS_USER_TAB",
    text: deleteTab
  })
}

export function addDynamicDashBoardTab(name) {
  console.log('Add dynamic dash user conf tab for tab name -' + name);
  ActionDispatcher.dispatch({
    type: "ADD_DYNAMIC_DASHBOARD_USER_TAB",
    text: name
  })
}

export function addGeneralDynamicDashBoardTab(obj) {
  console.log('Add general dynamic dash user conf tab for tab name -' + obj);
  ActionDispatcher.dispatch({
    type: "ADD_GENERAL_DYNAMIC_DASHBOARD_USER_TAB",
    text: obj
  })
}

export function addDynamicNavigationTab(selectedParam) {
  console.log('Add dynamic dash navigation tab for tab name');
  ActionDispatcher.dispatch({
    type: "ADD_DYNAMIC_DASHBOARD_NAVIGATION_TAB",
    text: selectedParam
  })
}

export function deleteDynamicNavigationTab(name) {
  console.log('Delete dynamic dash navigation tab for tab name');
  ActionDispatcher.dispatch({
    type: "DELETE_DYNAMIC_DASHBOARD_NAVIGATION_TAB",
    text: name
  })
}
export function popupOpenClicked(item) {
  console.log('Popup Open Clicked Event Triggered');
  ActionDispatcher.dispatch({
    type: "POPUP_OPEN_CLICKED",
    text: item
  })
}
export function popupCloseClicked() {
  console.log('Popup Close Clicked Event Triggered');
  ActionDispatcher.dispatch({
    type: "POPUP_CLOSED_CLICKED",
    text: 'none'
  })
}

export function changeRankingDashboardUserConfig(valueToChange, value, indexValue, dynamicDashName) {
  console.log('Change selected value for ranking metrics dashboard');
  ActionDispatcher.dispatch({
    type: "CHANGE_RANKING_DASHBOARD_TAB_CONFIG",
    text: {
      valueToChange: valueToChange,
      value: value,
      indexValue: indexValue,
      dynamicDashName: dynamicDashName
    }
  })
}

export function changeExceptionPredictabilityUserConfig(valueToChange, value, indexValue, dynamicDashName) {
  console.log('Change selected value for ranking metrics dashboard');
  ActionDispatcher.dispatch({
    type: "CHANGE_EXCEPTION_PREDICTABILITY_TAB_CONFIG",
    text: {
      valueToChange: valueToChange,
      value: value,
      indexValue: indexValue,
      dynamicDashName: dynamicDashName
    }
  })
}

export function changeGfsMetricsUserConfig(valueToChange, value, indexValue, dynamicDashName) {
  console.log('Change selected value for gfs metrics dashboard');
  ActionDispatcher.dispatch({
    type: "CHANGE_GFS_METRICS_TAB_CONFIG",
    text: {
      valueToChange: valueToChange,
      value: value,
      indexValue: indexValue,
      dynamicDashName: dynamicDashName
    }
  })
}


export function updateAssignee(e, prevAssignee, assigneeUpdate) {
  var url = url_node + '/updateAssignee';
  console.log('URL - ' + url);
  console.log(assigneeUpdate);
  Request.post(url).send(assigneeUpdate).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log("Post update assigne Data from Middleend");
      console.log(response.body);
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating assigne data', error);
      e.value = prevAssignee;
      return {};
    }
  }
  );
}

export function changeActiveCategoryExceptionTable(category) {
  console.log('Active Category Selected change event Triggered');
  ActionDispatcher.dispatch({
    type: "ACTIVE_CATEGORY_EXCEPTION_TABLE_CHANGE",
    text: category
  })
}

export function changeActiveCategoryExceptionTableAborNav(category) {
  console.log('Active Category Selected ABOR NAV change event Triggered');
  ActionDispatcher.dispatch({
    type: "ACTIVE_CATEGORY_ABOR_NAV_EXCEPTION_TABLE_CHANGE",
    text: category
  })
}

export function changeActiveCategoryPopupExceptionTable(category) {
  console.log('Active graph type change event Triggered');
  ActionDispatcher.dispatch({
    type: "ACTIVE_CATEGORY_POPUP_EXCEPTION_TABLE_CHANGE",
    text: category
  })
}

export function changeActiveCategoryPopupAborNavExceptionTable(category) {
  console.log('Active graph type change event Triggered');
  ActionDispatcher.dispatch({
    type: "ACTIVE_CATEGORY_POPUP_ABOR_NAV_EXCEPTION_TABLE_CHANGE",
    text: category
  })
}

export function changeFeedbackCategorySelected(newValue) {
  console.log('Change feedback selected event Triggered');
  ActionDispatcher.dispatch({
    type: "CHANGE_FEEDBACK_CATEGORY",
    text: newValue
  })
}

export function handleSearchBoxFilter(headerFieldItem) {
  ActionDispatcher.dispatch({
    type: "SEARCH_BOX_FILTER_CHANGE",
    text: headerFieldItem
  });
}

export function clearFilterSelected(headerFieldItem) {
  ActionDispatcher.dispatch({
    type: "CLEAR_EXCEPTION_TABLE_POPUP_FILTER",
    text: headerFieldItem
  });
}

export function changeClientFilter(clientName) {
  ActionDispatcher.dispatch({
    type: "CLIENT_FILTER_CHANGED",
    text: clientName
  });
}

export function changeSLAFilter(slaName) {
  ActionDispatcher.dispatch({
    type: "SLA_FILTER_CHANGED",
    text: slaName
  });
}

export function changeClientFilterOnly(clientName) {
  ActionDispatcher.dispatch({
    type: "CLIENT_FILTER_CHANGED_ONLY",
    text: clientName
  });
}

export function selectAllFilterPopupChange(headerFieldItem) {
  ActionDispatcher.dispatch({
    type: "SELECT_ALL_EXCEPTION_TABLE_POPUP_FILTER",
    text: headerFieldItem
  });
}

export function refreshFilterExceptionTableData() {
  ActionDispatcher.dispatch({
    type: "REFRESH_CHANGE_EXCEPTION_TABLE_DATA_SELECTED_SEARCH",
    text: null
  });
}

export function refreshSelectedSimilarExceptionList(element) {
  ActionDispatcher.dispatch({
    type: "REFRESH_SIMILAR_EXCEPTION_SELECTED_LIST",
    text: element
  });
}

export function refreshSelectedSimilarExceptionListAll(element) {
  ActionDispatcher.dispatch({
    type: "REFRESH_SIMILAR_EXCEPTION_SELECTED_LIST_ALL",
    text: element
  });
}





export function handleDrillDownHeaderIconClick(icon) {
  ActionDispatcher.dispatch({
    type: "DRILLDOWN_HEADER_ICON_CLICK",
    text: icon
  });
}


export function refreshTradeDetail(allocId) {
  getTradeDetail(allocId);
}

export function authenticateUser(credentials) {
  var url = url_node + '/login';
  Request.post(url).send(credentials).withCredentials().end((error, response) => {
    if (!error && response) {
      if (!response.unauthorized) {
        console.log(response.body);
        ActionDispatcher.dispatch({
          type: "LOGIN_SUCCESS",
          text: response.body
        });
      }
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error fetching data', error);
      return {};
    }
  }
  );
}


export function logoutUser() {
  var url = url_node + '/logout';
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      ActionDispatcher.dispatch({
        type: "LOGOUT_SUCCESS",
        text: null
      });
    } else {
      console.log('There was an error fetching data', error);
      return {};
    }
  }
  );
}

export function updateUserConfiguration(obj) {
  var url = url_node + '/assignrole';
  console.log('URL - ' + url);
  Request.post(url).send(obj).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('Update user conf api succesfully called');
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function cancelUserDashboardChangeConf() {
  ActionDispatcher.dispatch({
    type: "CANCEL_DAHSBOARD_CHANGE",
    text: null
  });
}

export function saveUserDashboardChangeConf() {
  var url = url_node + '/updateuserdashboardconf';
  console.log('URL - ' + url);
  Request.post(url).send(userDetailDataStore.getUserDashboardChangeDataToSave()).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('save user conf api succesfully called');
      ActionDispatcher.dispatch({
        type: "SAVE_DAHSBOARD_CHANGE",
        text: null
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function getUserList() {
  var url = url_node + '/userlist';
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('get user list api succesfully called');
      ActionDispatcher.dispatch({
        type: "USER_LIST_ACQUIRED",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function getRoleList() {
  var url = url_node + '/rolelist';
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('get role list api succesfully called');
      ActionDispatcher.dispatch({
        type: "ROLE_LIST_ACQUIRED",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function getBussinessOpsTeam(roleName) {
  var url = url_node + '/bussinessopsteam?name=' + roleName;
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('get role name based user list api succesfully called');
      ActionDispatcher.dispatch({
        type: "BUSSINESS_OPS_LIST_ACQUIRED",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function getClientAndStageForRole(roleName) {
  var url = url_node + '/rolebasedclientstage?name=' + roleName;
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('get role name based client stage list api succesfully called');
      ActionDispatcher.dispatch({
        type: "CLIENT_STAGE_LIST_ACQUIRED",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function updateRoleConfiguration(obj) {
  var url = url_node + '/updateroleconf';
  console.log('URL - ' + url);
  Request.post(url).send(obj).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('update role name based client stage list api succesfully called');
      // ActionDispatcher.dispatch({
      //   type: "CLIENT_STAGE_LIST_ACQUIRED",
      //   text: response.body
      // });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function getClientList() {
  var url = url_node + '/clientlist';
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('get client  list api succesfully called');
      ActionDispatcher.dispatch({
        type: "CLIENT_LIST_UPDATE",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function openFile(filePath) {
  var url = url_node + '/gettradefile?filePath=' + filePath;
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('get trade file path api succesfully called');
      console.log(url_node + response.body);
      window.open(url_node + '/' + response.body, '_blank');
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function uploadTradeFile(data) {
  var url = url_node + '/uploadfile';
  console.log('URL - ' + url);
  alert('File Processing started');
  Request.post(url).send(data).retry(0).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('upload  succesfully');
      alert('File Processed Successfully');
    } else {
      console.log('File Uploading Failed', error);
      alert('File Processing Failed');
      return {};
    }
  }
  );
}

export function updateMomtableField(data) {
  var url = url_node + '/updatemomtable';
  console.log('URL - ' + url);
  Request.post(url).send(data).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('Field Updated Successfully');
    } else {
      console.log('Field Updation Failed', error);
      alert('Field Updation Failed');
      return {};
    }
  }
  );
}

export function updateAborNavComment(commentUpdate) {
  var url = url_node + '/nav/updatecomment';
  console.log('URL - ' + url);
  console.log(commentUpdate);
  Request.post(url).send(commentUpdate).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log("Post update comment Data from Middleend");
      console.log(response.body);
      refreshExceptionTableAborNavData(exceptionSummaryAborNavDataStore.getActiveCriticalityValue());
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating comment data', error);
      //e.value = prevComment;
      return {};
    }
  }
  );
}

export function updateAborNavStatus(e, prevStatus, statusUpdate) {
  var url = url_node + '/nav/updatestatus';
  console.log('URL - ' + url);
  console.log(statusUpdate);
  Request.post(url).send(statusUpdate).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log("Post update status Data from Middleend");
      console.log(response.body);
      refereshCriticalitySummaryAborNavData(activeExceptionCategoryListAborNavStore.getActiveCategory());
      refreshChartAborNavData(graphAborNavDataStore.getGraphNameSelected());
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      e.value = prevStatus;
      return {};
    }
  }
  );
}

export function updateAborNavAssignee(e, prevAssignee, assigneeUpdate) {
  var url = url_node + '/nav/updateassignee';
  console.log('URL - ' + url);
  console.log(assigneeUpdate);
  Request.post(url).send(assigneeUpdate).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log("Post update assigne Data from Middleend");
      console.log(response.body);
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating assigne data', error);
      e.value = prevAssignee;
      return {};
    }
  }
  );
}


export function refreshTradeStateData() {
  var url = url_node + '/tradestatedata';
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('get trade state data api succesfully called');
      ActionDispatcher.dispatch({
        type: "TRADE_STATE_DATA_REFRESH",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function refreshTradeStateSummaryData() {
  var url = url_node + '/tradestatesummary';
  console.log('URL - ' + url);
  Request.get(url).withCredentials().end((error, response) => {
    if (!error && response) {
      console.log('get trade state summary data api succesfully called');
      ActionDispatcher.dispatch({
        type: "TRADE_STATE_SUMMARY_DATA_REFRESH",
        text: response.body
      });
    } else if (response.statusCode === 401) {
      hashHistory.push('login');
    } else {
      console.log('There was an error updating status data', error);
      return {};
    }
  }
  );
}

export function toggleAuditFilterStatus(newValue) {
  ActionDispatcher.dispatch({
    type: "CHANGE_AUDIT_FILTER_STATUS",
    text: newValue
  });
}

export function addAuditFilter(newValue, fieldName) {
  ActionDispatcher.dispatch({
    type: "CHANGE_AUDIT_FILTER_VALUE",
    text: { newValue, fieldName }
  });
}


