import React, { Component } from 'react';
import OptionDropdown from './OptionDropdown';
import rankingMetricsDataStore from '../../../store/rankingMetricsDataStore';
import OptionNumber from './OptionNumber';
import GraphTypeIcon from '../../Utilities/GraphTypeIcon';

export default class GfsGraphOption extends Component {

    constructor() {
        super();
    }

    handleChangeTypeSelected(newTypeSelected) {
        this.props.changeTypeSelected(newTypeSelected);
    }

    handleChangeBasisSelected(newBasisSelected) {
        this.props.changeBasisSelected(newBasisSelected);
    }

    handleChangeTopNumberSelected(newTopNumberelected) {
        this.props.changeTopNumberSelected(newTopNumberelected);
    }

    render() {
        let typeSelectedObject = {};
        let typesSelectedValue = this.props.typeSelected;
        if (this.props.typeSelected === null) {
            typeSelectedObject = this.props.rankingMetricsData[Object.keys(this.props.rankingMetricsData)[0]];
            typesSelectedValue = Object.keys(this.props.rankingMetricsData)[0];
        }
        else {
            typeSelectedObject = this.props.rankingMetricsData[this.props.typeSelected];
        }
        let basisSelectedObject = {};
        let nextOption = function () {
            let basisSelectedValue = this.props.basisSelected;
            if (this.props.basisSelected === null) {
                basisSelectedObject = typeSelectedObject[Object.keys(typeSelectedObject)[0]];
            }
            else {
                basisSelectedObject = typeSelectedObject[this.props.basisSelected];
            }
            return (
                <OptionDropdown selectedvalue={basisSelectedValue} dropdownChange={(newBasisSelected) => { this.handleChangeBasisSelected(newBasisSelected) }} parentObj={typeSelectedObject} />
            );
        }.call(this);

        let style = {};
        if (!this.props.editEnabled) {
            style.width = '0%';
            style.display = 'none';
        }
        let typeOfGraphList = [
        <GraphTypeIcon active={this.props.typeOfGraph} onclickaction={this.props.changeTypeOfGraph} type='line' detail='Line' />,
        <GraphTypeIcon active={this.props.typeOfGraph} onclickaction={this.props.changeTypeOfGraph} type='bar' detail='Bar' />
        ];
        return (
            <div style={style} className='gfsmetricsdashboard-graphblock-option-div'>
                <OptionDropdown selectedvalue={typesSelectedValue} dropdownChange={(newTypeselected) => { this.handleChangeTypeSelected(newTypeselected) }} parentObj={this.props.rankingMetricsData} />
                {nextOption}
                <OptionNumber value={this.props.topNumberSelected} changeTopSelectedNumber={(newValue) => { this.handleChangeTopNumberSelected(newValue) }} />
                <div style={{ margin: '2px 0px 0px 0px', height: '30%', overflow: 'auto' }}>
                    {typeOfGraphList}
                </div>
            </div>
        );
    }

}