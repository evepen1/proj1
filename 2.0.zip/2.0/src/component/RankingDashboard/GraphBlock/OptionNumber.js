import React, { Component } from 'react';

export default class OptionNumber extends Component {

    constructor(props) {
        super(props);
        this.state = {
            value: this.props.value
        };
    }

    handleOnChange(e) {
        if(e.target.value==0 && this.state.value<0){
            e.target.value=1;
        }
          if(e.target.value==0 && this.state.value>0){
            e.target.value=-1;
        }
        this.props.changeTopSelectedNumber(e.target.value);
        this.setState({
            value: e.target.value
        });
    }

    render() {
        return (
            <div className='gfsmetricsdashboard-graphblock-option-number-div'>
                <input className='gfsmetricsdashboard-graphblock-option-radiobutton-input' type="number" min={-5} max={5} value={this.state.value} onChange={(e) => { this.handleOnChange(e) }}
                    onKeyPress={(e) => {
                        e.preventDefault();
                    }} />
            </div>
        );
    }
}