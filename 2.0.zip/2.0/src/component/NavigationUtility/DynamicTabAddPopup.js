import React, { Component } from 'react';
import userDetailDataStore from '../../store/userDetailDataStore';
import * as Action from '../../action/Actions';

export default class DynamicTabAddPopup extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedDynamicTabType: 'Gfs Metrics Dashboard',
            dynamicTypeDashboardSelector: ['Gfs Metrics Dashboard', 'Ranking Dashboard', 'Exception Analytics Dashboard'],
            dynamicDashName: this.props.preFiledInput
        };
    }

    handleCancelClick() {
        this.state = {
            selectedDynamicTabType: 'Gfs Metrics Dashboard',
            dynamicTypeDashboardSelector: ['Gfs Metrics Dashboard', 'Ranking Dashboard', 'Exception Analytics Dashboard'],
            dynamicDashName: this.props.preFiledInput
        };
        this.props.closePopup();
    }

    handleCreateClick() {
        if (this.state.dynamicDashName === '') {
            alert('Dashboard with empty name not allowed.');
            this.setState(
                {
                    selectedDynamicTabType: 'Gfs Metrics Dashboard',
                    dynamicTypeDashboardSelector: ['Gfs Metrics Dashboard', 'Ranking Dashboard', 'Exception Analytics Dashboard'],
                    dynamicDashName: this.props.preFiledInput
                }
            );
        }
        else if (userDetailDataStore.getListOfDynamicDashName().indexOf(this.state.dynamicDashName) == -1) {
            this.props.createTab({
                selectedDynamicTabType: this.state.selectedDynamicTabType,
                dynamicDashName: this.state.dynamicDashName
            });
            this.state = {
                selectedDynamicTabType: 'Gfs Metrics Dashboard',
                dynamicTypeDashboardSelector: ['Gfs Metrics Dashboard', 'Ranking Dashboard', 'Exception Analytics Dashboard'],
                dynamicDashName: this.props.preFiledInput
            }
        }
        else {
            alert('Dashboard with name "' + this.state.dynamicDashName + '" already exist. Please try with different name.');
            this.setState(
                {
                    selectedDynamicTabType: 'Gfs Metrics Dashboard',
                    dynamicTypeDashboardSelector: ['Gfs Metrics Dashboard', 'Ranking Dashboard', 'Exception Analytics Dashboard'],
                    dynamicDashName: this.props.preFiledInput
                }
            );
        }

    }


    render() {
        let style = { display: 'none' };
        if (this.props.display) {
            style.display = 'block'
        }
        let listRadio = this.state.dynamicTypeDashboardSelector.map((item) => {
            if (item === this.state.selectedDynamicTabType) {
                return (
                    <label className='gfsmetricsdashboard-graphblock-option-radiobutton-label'>
                        <input type="radio"
                            value={item}
                            checked
                            onChange={(e) => {
                                this.setState({
                                    selectedDynamicTabType: e.target.value
                                });
                            }}
                        />
                        {item}
                    </label>
                );
            }
            else {
                return (
                    <label className='gfsmetricsdashboard-graphblock-option-radiobutton-label'>
                        <input type="radio"
                            value={item}
                            onChange={(e) => {
                                this.setState({
                                    selectedDynamicTabType: e.target.value
                                });
                            }}
                        />
                        {item}
                    </label>
                );
            }
        });
        return (
            <div>

                <div style={style} className="ewdashboard-exceptiontable-white_content_fixed" onClick={(e) => { e.stopPropagation(); e.nativeEvent.stopImmediatePropagation(); }}>
                    <div style={style} className='ewdashboard-exceptiontable-popup-selection-div'>
                        <table className='ewdashboard-exceptiontable-white_content_fixed_table'>
                            <tbody>
                                <tr>
                                    <td className='gfsmetricsdashboard-graphblock-option-td'>   Dynamic Dashboard Name
                                    </td>
                                    <td className='gfsmetricsdashboard-graphblock-option-td'>
                                        <label className='gfsmetricsdashboard-graphblock-option-dashname-label'>
                                            <input type="text"  className='gfsmetricsdashboard-graphblock-option-dashname-input'
                                                value={this.state.dynamicDashName} required autoFocus
                                                onChange={(e) => {
                                                    this.setState({ dynamicDashName: e.target.value });
                                                }}
                                            />

                                        </label>
                                    </td>
                                </tr>
                                {/*<tr>
                                    <td className='gfsmetricsdashboard-graphblock-option-td'>
                                        Select Dashboard Type
                                </td>
                                    <td className='gfsmetricsdashboard-graphblock-option-td'>
                                        {listRadio}
                                    </td>
                                </tr>*/}
                                <tr>
                                    <td colSpan='2' className='gfsmetricsdashboard-graphblock-option-td'>
                                        <input type="button" className='ewdashboard-exceptiontable-white_content_fixed_table_button_input'
                                            value='Create'
                                            onClick={(e) => { this.handleCreateClick(e); }}
                                        />
                                        <input type="button" className='ewdashboard-exceptiontable-white_content_fixed_table_button_input_red'
                                            value='Cancel'
                                            onClick={(e) => {
                                                this.handleCancelClick();
                                            }}
                                        />
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div style={style} className="ewdashboard-exceptiontable-black_overlay_fixed" onClick={(e) => {
                    this.handleCancelClick();
                }}></div>
            </div >
        );
    }

}