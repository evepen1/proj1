import React, { Component } from 'react';
import * as Action from '../../action/Actions';

export default class DashboardChange extends Component {

    constructor(props) {
        super(props);
    }

    handleCancelClick(){
        Action.cancelUserDashboardChangeConf();
    }

     handleSaveCancelClick(){
        Action.saveUserDashboardChangeConf();
    }

    render() {
        let saveValue = 'Save (' + this.props.value + ')';
        return (
            <div style={this.props.style} className='navigationpanel-dashboardchange-div-container'>
                <input type='button' value={saveValue} className='navigationpanel-dashboardchange-input' 
                onClick={(e)=>{this.handleSaveCancelClick()}} />
                <input type='button' value='Cancel' className='navigationpanel-dashboardchange-input' 
                onClick={(e)=>{this.handleCancelClick()}} />
            </div >
        );
    }
}