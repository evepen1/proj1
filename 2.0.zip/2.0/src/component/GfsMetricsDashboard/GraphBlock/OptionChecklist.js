import React, { Component } from 'react';

export default class OptionChecklist extends Component {

    constructor() {
        super();
    }

    handleCheckboxChange(e) {
        this.props.updateCheckList(e.target.value);
    }

    render() {
        let list = Object.keys(this.props.checklist).map((itemKey) => {
            if (this.props.checkedChecklist.indexOf(itemKey) > -1) {
                return (
                    <div key={itemKey} className='gfsmetricsdashboard-graphblock-option-popup-eachcheckbox-div'>
                        <input type="checkbox" value={itemKey} onChange={(e) => { this.handleCheckboxChange(e) }} checked />
                        {itemKey.toUpperCase()}
                    </div>
                );
            }
            else {
                return (
                    <div key={itemKey} className='gfsmetricsdashboard-graphblock-option-popup-eachcheckbox-div'>
                        <input type="checkbox" value={itemKey} onChange={(e) => { this.handleCheckboxChange(e) }} />
                        {itemKey.toUpperCase()}
                    </div>
                );
            }
        });
        return (
            <div className='gfsmetricsdashboard-graphblock-option-popup-div' style={this.props.popupStyle}>
                {list}
            </div>
        );
    }

}