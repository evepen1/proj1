import React, { Component } from 'react';
import EPGraphBlock from '../ExceptionPredictabilityDashboard/GraphBlock/GraphBlock';
import RGraphBlock from '../RankingDashboard/GraphBlock/GraphBlock';
import GMGraphBlock from '../GfsMetricsDashboard/GraphBlock/GraphBlock';
import userDetailDataStore from '../../store/userDetailDataStore';
import AddTabPopup from './AddTabPopup';
import * as Action from '../../action/Actions';

export default class GeneralDynamicDashboard extends Component {

    constructor(props) {
        super(props);
        this.state = {
            exceptionPredictionConf: userDetailDataStore.getUserTabConfig(this.props.name),
            addTabPopupDisplay: false
        };
    }

    handleAddGraphBlock(graphType) {
        this.state.addTabPopupDisplay = false;
        Action.addGeneralDynamicDashBoardTab({ graphType: graphType, name: this.props.name });
    }

    handleAddGraphBlockClick() {
        this.setState({
            addTabPopupDisplay: true
        });
    }

    handleCloseTabAddPopup() {
        this.setState({
            addTabPopupDisplay: false
        });
    }

    render() {
        let graphBlockList = this.state.exceptionPredictionConf.map((item, index) => {
            if (item.dashborardType === 'RankingDynamicDashboard') {
                return (
                    <RGraphBlock key={index + '_' + new Date().valueOf()} sequence={index}
                        addCssname={index + '_' + new Date().valueOf()}
                        typeSelected={item.typeSelected} basisSelected={item.basisSelected}
                        topNumberSelected={item.topNumberSelected}
                        durationSelected={item.durationSelected}
                        editEnabled={item.editEnabled}
                        typeOfGraph={item.typeOfGraph}
                        dynamicDashName={this.props.name} />
                );
            }
            else if (item.dashborardType === 'ExceptionPredictabilityDynamicDashboard') {
                return (
                    <EPGraphBlock key={index + '_' + new Date().valueOf()} sequence={index}
                        addCssname={index + '_' + new Date().valueOf()}
                        typeSelected={item.typeSelected}
                        basisSelected={item.basisSelected}
                        checkedList={item.checkedList}
                        editEnabled={item.editEnabled}
                        typeOfGraph={item.typeOfGraph}
                        dynamicDashName={this.props.name} />
                );
            }
            else {
                return (
                    <GMGraphBlock key={index + new Date().valueOf()}
                        dynamicDashName={this.props.name} sequence={index}
                        addCssname={index + new Date().valueOf()}
                        typeSelected={item.typeSelected}
                        basisSelected={item.basisSelected}
                        criticalitySelected={item.criticalitySelected}
                        checkedList={item.checkedList}
                        editEnabled={item.editEnabled}
                        typeOfGraph={item.typeOfGraph}
                        durationSelected={item.durationSelected} />
                );
            }
        }
        );
        return (
            <div className='gfsmetricsdashboard-container'>
                {graphBlockList}
                <div className='gfsmetricsdashboard-graphblock-div gfsmetricsdashboard-graphblock-div-addnew' onClick={() => { this.handleAddGraphBlockClick() }}>

                </div>
                <AddTabPopup createTab={this.handleAddGraphBlock.bind(this)} closePopup={this.handleCloseTabAddPopup.bind(this)} display={this.state.addTabPopupDisplay} />
            </div>
        );
    }

    componentDidMount() {
        userDetailDataStore.on("DynamicDashboardUserConfUpdated" + this.props.name, () => {
            this.setState({
                exceptionPredictionConf: userDetailDataStore.getUserTabConfig(this.props.name)
            });
        });
        userDetailDataStore.on("refreshAllDashboard", () => {
            this.setState({
                exceptionPredictionConf: userDetailDataStore.getUserTabConfig(this.props.name)
            });
        });
    }

    componentWillUnmount() {
        userDetailDataStore.removeListener("DynamicDashboardUserConfUpdated" + this.props.name, () => {
        });
        userDetailDataStore.removeListener("refreshAllDashboard" + this.props.name, () => {
        });
    }
}