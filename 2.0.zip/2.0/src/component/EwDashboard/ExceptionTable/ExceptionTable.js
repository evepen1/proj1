import React, { Component } from "react";
import exceptionTableDataStore from "../../../store/exceptionTableDataStore";
import activeExceptionCategoryListStore
  from "../../../store/actveExceptionCategoryStore";
import exceptionSummaryDataStore
  from "../../../store/exceptionSummaryDataStore";
import * as Action from "../../../action/Actions";
import fileDownloadStore from "../../../store/fileDownloadStore";
import DrillDownPopup from "./DrillDownPopup"
import TableTextArea from './TableTextArea'
import FilterPopup from "./FilterPopup";

export default class ExceptionTable extends Component {
  constructor() {
    super();
    this.state = {
      exceptionTableData: exceptionTableDataStore.getTableData(),
      tableDataDisplay: false,
      currentPage: 1,
      lastPage: 1,
      rowPerPageLimit: 10,
      data: {
        dropDownOptions: ['Open', 'Work in progress', 'At Risk', 'Resolved'],
        // assigneeDropDownOptions: ['', 'Barry Grist', 'Michelle Kennedy', 'Michal Wyrzykowski'],
        prevStatus: 'S',
        prevComment: 'C',
        prevAssignee: 'S',
      },
      checkBoxAll: 0,
      activeItemId: null,
      displayPopUp: false,
      activeHeader: null,
      activeHeaderPopup: false,
      checkedItemSearchBox: exceptionTableDataStore.getCheckedItemSearchBox(),
      tableDescIndexSelected: -1,
    };
    this.agingContainer = {};
    this.filterPopup = {
      xposition: 0,
      yposition: 0
    };
  }

  createAndRemoveBlink(id, value) {
    clearInterval(this.agingContainer[id]);
    let t = true;
    if (value) {
      this.agingContainer[id] = setInterval(() => {
        if (document.getElementById(id) != null) {
          if (t) {
            document.getElementById(id).style.backgroundColor = '#ff3232';
            document.getElementById(id).style.color = 'white';
            //  document.getElementById(id).style.boxShadow = '1px 1px 7px 7px #ff3232';
          }
          else {
            document.getElementById(id).style.backgroundColor = 'transparent';
            document.getElementById(id).style.color = 'red';
            //  document.getElementById(id).style.boxShadow = '';
          }
          t = !t;
        }
        else {
          clearInterval(this.agingContainer[id]);
        }
      }, 500);
    }
  }

  clearAllBlinkers() {
    Object.keys(this.agingContainer).forEach((id) => {
      clearInterval(this.agingContainer[id]);
    });
  }

  handleMouseEnterOverDescription(e, value) {
    this.setState({
      tableDescIndexSelected: value
    });
  }

  handleMouseLeaveOverDescription(e, value) {
    this.setState({
      tableDescIndexSelected: -1
    });
  }

  pageIncrement() {
    if (this.state.currentPage < this.state.lastPage) {
      this.setState({
        currentPage: this.state.currentPage + 1
      });
    }
  }

  pageDecrement() {
    if (this.state.currentPage > 1) {
      this.setState({
        currentPage: this.state.currentPage - 1
      });
    }
  }

  getSeverityColor(criticality) {
    switch (criticality.toUpperCase()) {
      case 'CRITICAL': {
        return '#ff3232';
      }
      case 'HIGH': {
        return '#FF8029';
      }
      case 'MEDIUM': {
        return '#FFC000';
      }
      case 'LOW': {
        return '#33adff';
      }
      default: {
        return '#464646';
      }
    }
  }

  handleMouseWheeling(e) {
    if (e.deltaY < 0) {
      this.pageIncrement();
    } else {
      this.pageDecrement();
    }
  }

  handleCheckBoxOnChange(item) {
    Action.refreshFileDownloadData(item);
  }

  handleOnFocusStatus(e) {
    this.state.data.prevStatus = e.target.value;
  }

  handleOnFocusAssignee(e) {
    this.state.data.prevAssignee = e.target.value;
  }
  handleDropDownChange(e, statusUpdate) {
    Action.updateStatus(e.target, this.state.data.prevStatus, statusUpdate);
  }
  handleAssigneeDropDownChange(e, assigneeUpdate) {
    Action.updateAssignee(e.target, this.state.data.prevAssignee, assigneeUpdate);
  }
  handleCheckBoxToSellectAllOnCurrentPage() {
    let tempTableData = [];
    for (
      let i = (this.state.currentPage - 1) * this.state.rowPerPageLimit;
      i < this.state.exceptionTableData.length &&
      i < this.state.currentPage * this.state.rowPerPageLimit;
      ++i
    ) {
      tempTableData.push(this.state.exceptionTableData[i]);
    }

    Action.refreshAllFileDownloadData({
      tempData: tempTableData,
      currentPage: this.state.currentPage
    })
  }

  handleOnClickOpenPopup(itemId) {
    this.setState({
      activeItemId: itemId
    });
  }
  handlePopupClose() {
    this.setState({
      activeItemId: null
    });
  }
  handleOnClickFilterPopupOpen(e, header) {

    this.filterPopup.xposition = e.target.getBoundingClientRect().right - 20;
    this.filterPopup.yposition = e.target.getBoundingClientRect().top + 15;
    this.setState({ activeHeader: header });
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
  }

  handleOnClickFilterPopupClose() {
    this.setState({ activeHeader: null });
    // e.stopPropagation();
    // e.nativeEvent.stopImmediatePropagation();
  }
  render() {
    let style = {
      backgroundColor: '#ff4c4c',
      float: 'left'
    };
    if (this.props.autoRefreshOn) {
      style = {
        backgroundColor: '#90EC7D',
        float: 'right'
      };
    }
    let filterPopupStyle = {
      'position': 'fixed',
      'top': this.filterPopup.yposition,
      'left': this.filterPopup.xposition
    };


    if (this.state.tableDataDisplay) {
      let header = exceptionTableDataStore.getTableHeaderList().map(item => {
        if (item.displayName == "checkBox") {

          if (fileDownloadStore.checkedAllCurrentPage(this.state.currentPage)) {
            return (
              <th className="ewdashboard-exceptiontable-th-header">
                <input
                  className="ewdashboard-exceptiontable-checkbox"
                  type="checkbox" checked onChange={(e) =>
                  { this.handleCheckBoxToSellectAllOnCurrentPage(); }}
                />
              </th>
            );
          } else {
            return (
              <th className="ewdashboard-exceptiontable-th-header">
                <input
                  className="ewdashboard-exceptiontable-checkbox"
                  type="checkbox" onChange={(e) =>
                  { this.handleCheckBoxToSellectAllOnCurrentPage(); }}
                />
              </th>
            );
          }
        }
        else {
          let style = {
            backgroundColor: '#333'
          }
          if (this.state.checkedItemSearchBox[item.fieldName] != undefined) {
            style.backgroundColor = '#3399FF';
          }
          let filterPopUpDisplay;
          if (this.state.activeHeader === item.fieldName) {
            filterPopUpDisplay = <div className="ewdashboard-exceptiontable-filter-div-popup" style={filterPopupStyle}><FilterPopup
              handleonclose={this.handleOnClickFilterPopupClose.bind(this)}
              headerFieldName={item.fieldName}
              checkedItemSearchBoxList={this.state.checkedItemSearchBox[item.fieldName]}
            /></div>;
          }
          return (
            <th style={style} className="ewdashboard-exceptiontable-th-header">
              <div>
                <div className="ewdashboard-exceptiontable-Headers"> {item.displayName}</div>
                {/*<div className="ewdashboard-exceptiontable-icon-filter"
                  onClick={(e) => this.handleOnClickFilterPopupOpen(e, item.fieldName)}>
                  {filterPopUpDisplay}
                </div>*/}
              </div>
            </th>
          );
        }
      });

      let tempTableData = [];
      for (
        let i = (this.state.currentPage - 1) * this.state.rowPerPageLimit;
        i < this.state.exceptionTableData.length &&
        i < this.state.currentPage * this.state.rowPerPageLimit;
        ++i
      ) {
        tempTableData.push(this.state.exceptionTableData[i]);
      }
      let records = tempTableData.map((item, index) => {



        let colList = exceptionTableDataStore
          .getTableHeaderList()
          .map(header => {

            let options = this.state.data.dropDownOptions.map(dropdownItem => {
              if (dropdownItem == item['status']) {
                return (<option selected className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={dropdownItem}>{dropdownItem}</option>);
              }
              return (<option className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={dropdownItem}>{dropdownItem}</option>);
            });
            let assigneeOptions = item['assigneeList'].map(dropdownItem => {
              if (dropdownItem == item[header.fieldName]) {
                return (<option selected className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={dropdownItem}>{dropdownItem}</option>);
              }
              return (<option className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={dropdownItem}>{dropdownItem}</option>);
            });
            if (
              item[header.fieldName] == undefined &&
              header.fieldName == "checkBox"
            ) {
              if (fileDownloadStore.isAlreadyExist(item)
                || fileDownloadStore.checkedAllCurrentPage(this.state.currentPage)) {
                return (
                  <td className="ewdashboard-exceptiontable-td">
                    <input
                      className="ewdashboard-exceptiontable-checkbox"
                      value={item}
                      onChange={(e) => { this.handleCheckBoxOnChange(item); }}
                      type="checkbox" checked
                    />
                  </td>
                );
              }
              else {
                return (
                  <td className="ewdashboard-exceptiontable-td">
                    <input
                      className="ewdashboard-exceptiontable-checkbox"
                      value={item}
                      onChange={(e) => { this.handleCheckBoxOnChange(item); }}
                      type="checkbox"
                    />
                  </td>
                );
              }
            }
            else if (header.fieldName == 'status') {
              return (<td className='ewdashboard-exceptiontable-td'>
                <select className='ewdashboard-exceptiontable-status-dropdown'
                  onClick={(e) => this.handleOnFocusStatus(e)}
                  onChange={(e) => {
                    this.handleDropDownChange(e, {
                      exceptionId: item.exceptionId,
                      id: item._id,
                      errorDescription: item.errorDescription,
                      firmCode: item.firmCode,
                      oldValue: this.state.data.prevStatus,
                      newValue: e.target.value,
                      fieldName: header.displayName,
                      allocationId: item.allocationId,
                      time: Date().toString()
                    });
                  }}>
                  {options}
                </select>
              </td>);
            }

            else if (header.fieldName == 'comment') {
              return (<td className='ewdashboard-exceptiontable-td'>
                <TableTextArea key={item._id + item.exceptionId} item={item} />
              </td>);
            }
            else if (header.fieldName == 'allocationId') {
              if (this.state.activeItemId === item._id) {
                this.state.displayPopUp = true;
              }
              let popUpDisplay;
              if (this.state.displayPopUp) {
                this.state.displayPopUp = false;
                popUpDisplay = <DrillDownPopup handleonclose={this.handlePopupClose.bind(this)} item={item} />;
              }
              return (<td className='ewdashboard-exceptiontable-td-link'>
                <div className="ewdashboard-exceptiontable-popup"
                  onClick={(e) => this.handleOnClickOpenPopup(item._id)}>{item[header.fieldName]}</div>
                {popUpDisplay}
              </td>);
            }
            else if (header.fieldName == "assignee") {
              return (<td className='ewdashboard-exceptiontable-td'>
                <select className='ewdashboard-exceptiontable-status-dropdown'
                  onClick={(e) => this.handleOnFocusAssignee(e)}
                  onChange={(e) => {
                    this.handleAssigneeDropDownChange(e, {
                      exceptionId: item.exceptionId,
                      id: item._id,
                      errorDescription: item.errorDescription,
                      firmCode: item.firmCode,
                      oldValue: this.state.data.prevAssignee,
                      newValue: e.target.value,
                      fieldName: header.displayName,
                      allocationId: item.allocationId,
                      time: Date().toString()
                    });
                  }}>
                  {assigneeOptions}
                </select>
              </td>);
            }
            else if (header.fieldName == "errorDescription") {
              let desc = item[header.fieldName];
              if (this.state.tableDescIndexSelected === index || desc.length <= 30) {
                return (
                  <td className="ewdashboard-exceptiontable-td-description"
                    onMouseEnter={(e) => { this.handleMouseEnterOverDescription(e, index) }} onMouseLeave={(e) => { this.handleMouseLeaveOverDescription(e, index) }}>
                    <div >{desc}</div>
                  </td>
                );
              }
              else {
                return (
                  <td className="ewdashboard-exceptiontable-td-description"
                    onMouseEnter={(e) => { this.handleMouseEnterOverDescription(e, index) }} onMouseLeave={(e) => { this.handleMouseLeaveOverDescription(e, index) }}>
                    <div >{desc.substr(0, 30) + ' ...'}</div>
                  </td>
                );
              }
            }
            else if (header.fieldName == "aging") {
              let circleStyle = {
                backgroundColor: this.getSeverityColor(item.criticality),
                color: item.criticality == 'MEDIUM' ? 'black' : 'white'
              };
              let timeStr = String(item[header.fieldName]);
              let toShowTimeStr = '';
              if (timeStr != 'undefined') {
                if (timeStr.length > 2) {
                  let tStr = timeStr.slice(0, timeStr.length - 2);
                  toShowTimeStr = (tStr == '' ? '00' : (tStr == '-' ? '-00' : tStr)) + ':' + timeStr.slice(-2);
                }
                else {
                  if (timeStr[0] == '-') {
                    toShowTimeStr = timeStr[0] + '00:0' + timeStr[1];
                  }
                  else {
                    toShowTimeStr = '00:' + timeStr;
                  }
                }
              }
              this.createAndRemoveBlink(item.allocationId + '_' + index, item[header.fieldName] < 30);
              return (
                <td className="ewdashboard-exceptiontable-td">
                  <div className="ewdashboard-exceptiontable-td-text-aging-container">
                    {/*<div className="ewdashboard-exceptiontable-td-text-div">
                      <div className="ewdashboard-exceptiontable-td-text">
                        {toShowTimeStr}
                      </div>
                    </div>
                    <div className="ewdashboard-exceptiontable-td-aging-div">
                      <div id={item.allocationId + '_' + index} style={circleStyle} className="ewdashboard-exceptiontable-td-circle">
                      </div>
                    </div>*/}
                    <div id={item.allocationId + '_' + index} style={circleStyle} className="ewdashboard-exceptiontable-text-div">
                      <div className="ewdashboard-exceptiontable-text">
                        {toShowTimeStr}
                      </div>
                    </div>
                  </div>
                </td>
              );
            }
            else {
              return (
                <td className="ewdashboard-exceptiontable-td">
                  <div >{item[header.fieldName]}</div>
                </td>
              );
            }
          });
        return (
          <tr
            key={item._id + item.exceptionId + index}
            className={"ewdashboard-exceptiontable-tr-" + index % 2}
          >
            {colList}
          </tr>
        );
      });
      return (
        <div className="ewdashboard-exceptiontable-div" onClick={(e) => { this.handleOnClickFilterPopupClose() }}>
          <div className="ewdashboard-exceptiontable-table-div">
            <table
              className="ewdashboard-exceptiontable-table"
            >
              <thead className="ewdashboard-exceptiontable-table-thead">
                <tr
                  key="header"
                  className="ewdashboard-exceptiontable-tr-header"
                >
                  {header}
                </tr>
              </thead>
              <tbody className="ewdashboard-exceptiontable-table-tbody">
                {records}
              </tbody>
            </table>
          </div>
          <div className="ewdashboard-exceptiontable-pagination-div">
            <div className="ewdashboard-exceptiontable-pagination-pagediv">
              <div
                className="ewdashboard-exceptiontable-pagination-leftArrow"
                onClick={e => {
                  this.pageDecrement();
                }}
              />
              <div className="ewdashboard-exceptiontable-pagination-centertext">
                Page {this.state.currentPage} of {this.state.lastPage}
              </div>
              <div
                className="ewdashboard-exceptiontable-pagination-rightArrow"
                onClick={e => {
                  this.pageIncrement();
                }}
              />
            </div>
          </div>
          <div className='ewdashboard-header-autoplay-container' onClick={(e) => { this.props.toggleAutoRefresh() }}>
            <div className='ewdashboard-header-autoplay'>
              <div style={style} className='ewdashboard-header-autoplay-circle'>
              </div>
            </div>
            <div className='ewdashboard-header-autoplay-text'>
              auto refresh
                    </div>
          </div>
        </div>
      );
    } else {
      return <div className="ewdashboard-exceptiontable-div-loading" />;
    }
  }

  componentDidMount() {
    exceptionTableDataStore.on("TableDataRefreshed", () => {
      fileDownloadStore.clearFileDataStore();
      let lastPage = Math.ceil(exceptionTableDataStore.getTableData().length / 10);
      if (lastPage == 0) {
        lastPage = 1;
      }
      let curPage = this.state.currentPage;
      if (curPage > lastPage) {
        curPage = 1;
      }
      this.setState({
        exceptionTableData: exceptionTableDataStore.getTableData(),
        checkedItemSearchBox: exceptionTableDataStore.getCheckedItemSearchBox(),
        tableDataDisplay: true,
        currentPage: curPage,
        lastPage: lastPage
      });
    });
    exceptionTableDataStore.on("FilterListChanged", () => {
      this.setState({
        checkedItemSearchBox: exceptionTableDataStore.getCheckedItemSearchBox()
      });
    });
    fileDownloadStore.on("FileDataRefreshed", () => {
      this.setState({});
    });
    activeExceptionCategoryListStore.on("ResetPageNumber", () => {
      this.setState({
        currentPage: 1
      });
    });
    exceptionSummaryDataStore.on("ResetPageNumber", () => {
      this.setState({
        currentPage: 1
      });
    });
    Action.refreshExceptionTableData(
      activeExceptionCategoryListStore.getActiveCategory(),
      exceptionSummaryDataStore.getActiveCriticalityValue()
    );
  }

  componentWillUnmount() {
    this.clearAllBlinkers();
    exceptionTableDataStore.removeListener("TableDataRefreshed", () => { });
    exceptionTableDataStore.removeListener("FilterListChanged", () => { });
    fileDownloadStore.removeListener("FileDataRefreshed", () => { });
    activeExceptionCategoryListStore.removeListener("ResetPageNumber", () => { });
    exceptionSummaryDataStore.removeListener("ResetPageNumber", () => { });
  }
}
