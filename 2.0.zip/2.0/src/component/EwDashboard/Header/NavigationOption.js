import React, { Component } from 'react';
import { hashHistory } from 'react-router';
import * as Action from '../../../action/Actions';
import userDetailDataStore from '../../../store/userDetailDataStore';

export default class NavigationOption extends Component {
    render() {
        let dynamicLi = userDetailDataStore.getDynamicTabData().map((item, index) => {
            return (
                <li key={item.name} className='ewdashboard-header-navoption-div-li' onClick={(e) => { hashHistory.push('app/dynamic/' + item.link) }}>{item.name}</li>
            );
        });
        return (<div style={this.props.style} className='ewdashboard-header-navoption-div'>
            <ul>
                <li key={5} ><span className='ewdashboard-header-navoption-div-li-span-active' onClick={(e) => { hashHistory.push('etf/etfdash') }}>ETF Workflow Process</span></li>
                <li key={0}><span className='ewdashboard-header-navoption-div-li-span-active' onClick={(e) => { hashHistory.push('nav/navupstream') }}>NAV Workflow Process</span>
                    <ul style={{ listStyle: 'none' }}>
                        <li key={1 - 1} className='ewdashboard-header-navoption-div-li' onClick={(e) => { hashHistory.push('nav/navupstream') }}>NAV Dashboard</li>
                        <li key={1 - 2} className='ewdashboard-header-navoption-div-li' onClick={(e) => { hashHistory.push('nav/abornav') }}>NAV Exceptions</li>
                    </ul>
                </li>
                <li key={1} className='ewdashboard-header-navoption-div-li-top'>Pricing Dashboard</li>
                <li key={2} className='ewdashboard-header-navoption-div-li-top'> Frontier (Recon) Dashboard</li>
                <li key={4} ><span className='ewdashboard-header-navoption-div-li-span-active' onClick={(e) => { hashHistory.push('app/ewdashboard') }}>Trade Workflow Process</span>
                    <ul style={{ listStyle: 'none' }}>
                        <li key={4 - 1} className='ewdashboard-header-navoption-div-li' onClick={(e) => { hashHistory.push('app/ewdashboard') }}>Trade Processing Exceptions</li>
                        <li key={4 - 2} className='ewdashboard-header-navoption-div-li' onClick={(e) => { hashHistory.push('app/tradestate') }}>Trade Life Cycle</li>
                        {dynamicLi}
                    </ul>
                </li>
            </ul>
        </div>);
    }
}