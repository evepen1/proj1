import React, { Component } from 'react';
import SummaryDetail from './SummaryDetail';
import SummaryGraph from './SummaryGraph';

export default class Summary extends Component {
    render() {
        return (
            <div className='ewdashboard-summary-container'>
                <SummaryDetail />
                {/* <SummaryGraph /> */}
            </div>
        );
    }
}