import React, { Component } from 'react';
import CriticalityBox from './CriticalityBox';
import CategoryList from './CategoryList';
import exceptionSummaryDataStore from '../../../store/exceptionSummaryDataStore';
import activeExceptionCategoryListStore from '../../../store/actveExceptionCategoryStore';
import * as Action from '../../../action/Actions';

export default class SummaryDetail extends Component {

    constructor() {
        super();
        this.state = {
            activeCriticality: exceptionSummaryDataStore.getActiveCriticality(),
            activeSummaryException: exceptionSummaryDataStore.getActiveSummaryDataException()
        };
        
    }

    render() {
        
        let criticalitybox = exceptionSummaryDataStore.getCriticalityLookup().map((item) => {

            let arrowStyle = {
                display: 'none'
            };
            if (item.name === this.state.activeCriticality)
            { arrowStyle.display = 'block' }
            return (
                <CriticalityBox key={item.value} countValue={exceptionSummaryDataStore.getCriticalSummaryDataCount(item.name)} name={item.name} arrowStyle={arrowStyle} style={{ 'background-color': item.cssColor }} arrowCssClassName={'ewdashboard-summary-detail-criticality-box-arrow-' + item.value} />
            );
        });
        return (
            <div className='ewdashboard-summary-detail-div'>
                <div className='ewdashboard-summary-detail-criticality-div'>
                    {criticalitybox}
                </div>
                <div className='ewdashboard-summary-detail-category-div'>
                    <CategoryList initialIndex={-1} value={this.state.activeCriticality.toLowerCase()} activeSummaryException={this.state.activeSummaryException} />
                </div>
            </div>
        );
    }

    componentDidMount() {
            

        exceptionSummaryDataStore.on("ActiveCriticalityChanged", () => {
            this.setState({
                activeCriticality: exceptionSummaryDataStore.getActiveCriticality(),
                activeSummaryException: exceptionSummaryDataStore.getActiveSummaryDataException()
            });
            Action.refreshExceptionTableData(activeExceptionCategoryListStore.getActiveCategory(), exceptionSummaryDataStore.getActiveCriticalityValue());
                Action.refreshExceptionCountSummaryData(exceptionSummaryDataStore.getActiveCriticality());   
     });
        exceptionSummaryDataStore.on("CriticalitySmmaryDataRefreshed", () => {
            this.setState({
                activeCriticality: exceptionSummaryDataStore.getActiveCriticality(),
                activeSummaryException: exceptionSummaryDataStore.getActiveSummaryDataException()
            });
        });
        Action.refereshCriticalitySummaryData(activeExceptionCategoryListStore.getActiveCategory());
    }

    componentWillUnmount() {
        exceptionSummaryDataStore.removeListener("ActiveCriticalityChanged", () => {
        });
        exceptionSummaryDataStore.removeListener("CriticalitySmmaryDataRefreshed", () => {
        });
    }

}