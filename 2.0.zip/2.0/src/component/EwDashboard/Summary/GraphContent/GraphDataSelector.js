import React, { Component } from 'react';
import graphDataStore from '../../../../store/graphDataStore';
import * as Action from '../../../../action/Actions';

export default class GraphDataSelector extends Component {

    constructor() {
        super();
        this.state = {
            graphNameSelected: graphDataStore.getGraphNameSelected()
        };
    }

    handleGraphNameTabClick(name) {
        Action.changeGraphName(name);
    }
    render() {
        let graphNamelist = graphDataStore.getGraphNamelist().map((item) => {
            let cssClass = 'ewdashboard-summary-graph-data-selector-tab';
            if (item === this.state.graphNameSelected) {
                cssClass = cssClass + '-active';
            }
            return (
                <div className={cssClass} onClick={(e) => { this.handleGraphNameTabClick(item) }}>
                    {item}
                </div>
            );
        });
        let options = graphDataStore.getGraphNamelist().map(dropdownItem => {
            if (dropdownItem === this.state.graphNameSelected) {
                return (<option selected className='ewdashboard-summary-graph-container-option-dropdown'
                    value={dropdownItem}>{dropdownItem}</option>);
            }
            return (<option className='ewdashboard-summary-graph-container-option-dropdown'
                value={dropdownItem}>{dropdownItem}</option>);
        });
        //  graphDataStore.getGraphNamelist().map((item) => {
        return (
            <div className='ewdashboard-summary-graph-data-selector-div'>
                <select className='ewdashboard-summary-graph-container-select-dropdown'
                    onChange={(e) => { this.handleGraphNameTabClick(e.target.value) }}
                >
                    {options}
                </select>
            </div>
        );
        // });
    }

    componentDidMount() {
        graphDataStore.on("GraphNameSelectedChanged", () => {
            this.setState({
                graphNameSelected: graphDataStore.getGraphNameSelected()
            });
            Action.refreshChartData(graphDataStore.getGraphNameSelected());
        });
        Action.refreshChartData(graphDataStore.getGraphNameSelected());
    }

    componentWillUnmount() {
        graphDataStore.removeListener("GraphNameSelectedChanged", () => {
        });
    }
}