import React, { Component } from 'react';
import * as Action from '../../action/Actions';
import userDetailDataStore from '../../store/userDetailDataStore';

export default class WorkflowConfigration extends Component {
    constructor() {
        super();
        this.state = {
            roleOptions: userDetailDataStore.getRoleList(),
            userOptions: userDetailDataStore.getUserList(),
            businessOpsTeam: userDetailDataStore.getBussinessOpsTeam(),
            addOpsTeamMemb: null,
            selectedRole: 'SLI_OPS_USER',
            suggestionPopuoDisplay: false
        }
        this.suggestionPopup = {
            xposition: 0,
            yposition: 0,
            width: 0
        };
    }
    handleOnChangeOpsTeamMemb(e) {
        this.setState({
            addOpsTeamMemb: e.target.value
        });
    }

    hadleRoleSelectOnChange(e) {
        this.setState({
            selectedRole: e.target.value
        });
        Action.getBussinessOpsTeam(e.target.value);
    }

    handleOnClickAddOpsTeam() {
        let member = this.state.userOptions.filter((item) => {
            return item.userId === this.state.addOpsTeamMemb || item.userName === this.state.addOpsTeamMemb
        });
        let memberFrombot = this.state.businessOpsTeam.filter((item) => {
            return item.userId === this.state.addOpsTeamMemb || item.userName === this.state.addOpsTeamMemb
        });
        if (member.length > 0 && memberFrombot.length == 0) {
            this.state.businessOpsTeam.push(member[0]);
        }
        this.setState({
            businessOpsTeam: this.state.businessOpsTeam,
            addOpsTeamMemb: null
        });
    }

    handleBussinesTeamRemove(value) {
        for (let i = 0; i < this.state.businessOpsTeam.length; ++i) {
            if (this.state.businessOpsTeam[i].userName == value.userName && this.state.businessOpsTeam[i].userId == value.userId) {
                this.state.businessOpsTeam.splice(i, 1);
                break;
            }
        }
        this.setState({
            businessOpsTeam: this.state.businessOpsTeam
        });
    }

    handleUserAddSaveClick() {
        let userList = [];
        userList = this.state.businessOpsTeam.map((item) => {
            return item.userId;
        });
        Action.updateUserConfiguration({
            userList: userList,
            selectedRole: this.state.selectedRole.toUpperCase()
        });
    }

    handleGetUserList(e) {
        this.state.suggestionPopuoDisplay = true;
        this.state.addOpsTeamMemb = null;
        this.suggestionPopup.yposition = e.target.getBoundingClientRect().bottom;
        this.suggestionPopup.xposition = e.target.getBoundingClientRect().left;
        this.suggestionPopup.width = Math.abs(e.target.getBoundingClientRect().left - e.target.getBoundingClientRect().right);
        Action.getUserList();
    }

    getSuggestionList() {
        let suggestionList = [];
        this.state.userOptions.forEach((user) => {
            if (this.state.addOpsTeamMemb===null || user.userId.toLowerCase().startsWith(this.state.addOpsTeamMemb.toLowerCase()) || user.userName.toLowerCase().startsWith(this.state.addOpsTeamMemb.toLowerCase())) {
                suggestionList.push(user);
            }
        });
        return suggestionList;
    }

    handleCloseSuggestion() {
        this.setState({
            suggestionPopuoDisplay: false
        });
    }

    handleUserSelect(value) {
        this.setState({
            addOpsTeamMemb: value.userName,
            suggestionPopuoDisplay: false
        });
    }

    render() {

        let roleOptions = this.state.roleOptions.map(dropdownItem => {
            if (dropdownItem === this.state.selectedStage) {
                return (<option className='gfsmetricsdashboard-graphblock-option-dropdown-option' selected value={dropdownItem}>{dropdownItem}</option>);
            }
            return (<option className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={dropdownItem}>{dropdownItem}</option>);
        });
        let dispListBussinesTeam = this.state.businessOpsTeam.map((item) => {
            return (
                <div className='setting-workflowconf-team-each-div'>
                    <div className='setting-workflowconf-team-each-content'>
                        {item.userName}
                    </div>
                    <div className='setting-workflowconf-team-each-remove' onClick={(e) => { this.handleBussinesTeamRemove(item) }}>
                    </div>
                </div>
            );
        });

        let suggestedUsers = this.getSuggestionList().map((user) => {
            return (<div className='setting-suggestion-div-eachuser' onClick={(e) => { this.handleUserSelect(user) }}>
                {user.userName + '  (' + user.userId + ')'}
            </div>);
        });

        let suggestionPopupStyle = {
            display: 'none',
            position: 'fixed'
        };

        if (this.state.suggestionPopuoDisplay) {
            suggestionPopupStyle.display = 'block';
            suggestionPopupStyle.width = this.suggestionPopup.width;
            suggestionPopupStyle.position = 'fixed';
            suggestionPopupStyle.top = this.suggestionPopup.yposition;
            suggestionPopupStyle.left = this.suggestionPopup.xposition;
        }

        return (
            <div className='workfloW-configration-top-div' onClick={(e) => { this.handleCloseSuggestion() }}>
                <div className='workfloW-configration-bottom-content-div'>
                    <table>
                        <tr>
                            <td className='setting-table-td' colSpan='1'>Roles</td>
                            <td className='setting-table-td' ><select className='settin-status-dropdown' onChange={(e) => { this.hadleRoleSelectOnChange(e) }}>
                                {roleOptions}
                            </select>
                            </td>
                        </tr>
                        <tr>
                            <td className='setting-table-td' colSpan='1'>Business Ops Lead </td>
                            <td className='setting-table-td'><input type="text" style={{ width: '100%' }} className='setting-text' /></td>
                        </tr>
                        <tr>
                            <td className='setting-table-td'>Business Ops Team</td>
                            <td className='setting-table-td' >
                                <div className='setting-workflowconf-team-div'>
                                    {dispListBussinesTeam}
                                </div>
                            </td>
                        </tr>
                        <tr onClick={(e) => {
                            e.stopPropagation();
                            e.nativeEvent.stopImmediatePropagation();
                        }}>
                            <td></td>
                            <td>
                                <input type="text" value={this.state.addOpsTeamMemb} style={{ width: '75%' }} className='setting-text'
                                    onChange={e => this.handleOnChangeOpsTeamMemb(e)}
                                    onFocus={(e) => { this.handleGetUserList(e) }}
                                />
                                <input type="button" style={{ width: '15%', float: 'right' }} className='setting-td-button'
                                    value='Add' onClick={e => this.handleOnClickAddOpsTeam()} />
                            </td>
                            <div style={suggestionPopupStyle} className='setting-suggestion-div-container'>
                                {suggestedUsers}
                            </div>
                        </tr>
                        <tr>
                            <td className='setting-table-td' colSpan='2' ><input type="button" className='setting-td-button'
                                value='Save' onClick={(e) => { this.handleUserAddSaveClick() }} /></td>
                        </tr>
                    </table>
                </div>
            </div >
        );
    }

    componentDidMount() {
        userDetailDataStore.on("RolelistRefreshed", () => {
            this.setState({
                roleOptions: userDetailDataStore.getRoleList()
            });
            Action.getBussinessOpsTeam(userDetailDataStore.getRoleList()[0]);
        });
        userDetailDataStore.on("UserlistRefreshed", () => {
            this.setState({
                userOptions: userDetailDataStore.getUserList()
            });
        });
        userDetailDataStore.on("BussinessOpsTeamRefreshed", () => {
            this.setState({
                businessOpsTeam: userDetailDataStore.getBussinessOpsTeam()
            });
        });
    }

    componentWillUnmount() {
        userDetailDataStore.removeListener("RolelistRefreshed", () => {
        });
        userDetailDataStore.removeListener("UserlistRefreshed", () => {
        });
        userDetailDataStore.removeListener("BussinessOpsTeamRefreshed", () => {
        });
    }

}