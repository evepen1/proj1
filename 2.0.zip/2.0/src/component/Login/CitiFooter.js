import React, {Component} from 'react';

export default class CitiFooter extends Component {
  render() {
    return ( <div className='login-footer-container'>
              <footer>
                  {/*<ul className="nav">
                      <li><a href="http://www.citigroup.net/CITINETWebApp/" target="_blank">Citigroup.net</a></li>
                      <li><a href="http://www.citigroup.net/tos/" target="_blank">Terms &amp; Conditions</a></li>
                      <li><a href="http://www.citigroup.net/citigroup.net/newcitigroupdotnet/accessibility.html" target="_blank">Accessibility</a></li>
                  </ul>*/}
                  <div id="copyright">
                      <a target="_blank" href="http://www.citigroup.net/CITINETWebApp/">
                          <img src="http://www.citigroup.net/ti/csduserexperience/bootstrap/assets/img/logos/citilogo_footer.png"/></a>
                      <span>Citigroup.com is the global source of information about and access to financial services provided by the Citigroup companies.</span>
                      <span className="pull-right copyright">&copy; 2017 Citigroup Inc.</span>
                  </div>
              </footer>
        </div>

    );
  }
}

