import React from 'react';


const CitiHeader = (props) => {
    return (            
                
                <div className="login-header-div"> 
                   
                    <div className="login-header-title">
                        {props.siteTitle}
                    </div>
                     <div className="login-header-logo">          
                        <span><a href="//www.citigroup.com/citi/"><img alt="citi-logo" src="./../../assets/img/citiLogo.png"/></a> 
                        </span>             
                        
                    </div>
                </div>    
        );
};

export default CitiHeader;
