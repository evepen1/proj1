import React, { Component } from 'react';
import { hashHistory } from 'react-router';

export default class HomeTab extends Component {

    constructor(props) {
        super(props);
    }

    handleClick() {
        if (!(this.props.link == 'fr' || this.props.link == 'pr')) {
            hashHistory.push(this.props.link);
        }
    }

    render() {
        return (
            <div className='home-tab-div'
                onClick={(e) => { this.handleClick() }}>
                <div className='home-tab-closure'>
                    <div className={'home-tab-image-' + this.props.cssAddon}>
                    </div>
                    <div className='home-tab-link'>
                        <div className='home-tab-link-text'>
                            {this.props.text}
                        </div>
                    </div>
                </div>
            </div>
        );
    }

}