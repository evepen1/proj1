import React, { Component } from 'react';
import { hashHistory } from 'react-router';

export default class HomeTab extends Component {

    constructor(props) {
        super(props);
        this.state = {
            cssName: 'nohover'
        };
    }

    handleClick() {
        hashHistory.push(this.props.link);
    }

    handleMouseEnter() {
        this.setState({
            cssName: 'hover'
        });
    }

    handleMouseLeave() {
        this.setState({
            cssName: 'nohover'
        });
    }

    render() {
        return (
            <div className='home-each-tab-div home-tp-tab-div'>
                <div className='home-each-tab-div-interior' onClick={(e) => { this.handleClick() }}
                    onMouseOver={(e) => { this.handleMouseEnter() }}
                onMouseLeave={(e) => { this.handleMouseLeave() }}>
                    <div className={'home-each-tab-div-img home-img-div-' + this.props.cssAddon}>

                    </div>
                    <div className='home-each-tab-div-content'>
                        <div className={'home-each-tab-div-data-'+this.state.cssName}>
                            {this.props.text}
                        </div>
                    </div>
                </div>
            </div>
        );
    }

}