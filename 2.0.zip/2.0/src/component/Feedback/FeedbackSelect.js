import React, { Component } from 'react';
import * as Action from '../../action/Actions';
import helpCenterDataStore from '../../store/helpCenterDataStore';

export default class FeedbackSelect extends Component {

    handleClick(newFeedbackValue) {
        Action.changeFeedbackCategorySelected(newFeedbackValue);
    }

    render() {
        let style = {
            backgroundColor: 'transparent'
        };
        if (this.props.isSelected) {
            style.backgroundColor = '#0080FF'
        }
        return (
            <div style={style} className='feedback-bottom-div-category-field-select-div' onClick={(e) => { this.handleClick(this.props.value); }}>
                {this.props.value}
            </div>
        );
    }

}