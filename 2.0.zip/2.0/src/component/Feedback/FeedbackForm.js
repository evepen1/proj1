import React, { Component } from 'react';
import * as Action from '../../action/Actions';
import StarRating from 'react-star-rating';

export default class FeedbackForm extends Component {

    constructor() {
        super();
        this.state = {
            firstName: '',
            lastName: '',
            email: '',
            feedbackText: '',
            rating: 0
        };
    }

    handleInputOnChange(type, value) {
        switch (type) {
            case 'firstName': {
                this.setState({
                    firstName: value
                });
                break;
            }
            case 'lastName': {
                this.setState({
                    lastName: value
                });
                break;
            }
            case 'email': {
                this.setState({
                    email: value
                });
                break;
            }
            case 'feedbackText': {
                this.setState({
                    feedbackText: value
                });
                break;
            }
            case 'rating': {
                this.setState({
                    rating: value
                });
                break;
            }
        }
    }

    handleClear() {
        this.setState({
            firstName: '',
            lastName: '',
            email: '',
            feedbackText: '',
            rating: 0
        });
    }

    handleRatingClick(e, ratObj) {
        this.setState({
            rating: ratObj.rating
        });
    }

    render() {
        return (
            <div className='feedback-bottom-div-form-div'>
                <table className='feedback-bottom-div-form-table'>
                    <tbody className='feedback-bottom-div-form-table-tbody'>
                        <tr>
                            <td className='feedback-bottom-div-form-table-td-left'>First Name</td>
                            <td className='feedback-bottom-div-form-table-td-right'>
                                <input type='text' value={this.state.firstName} className='feedback-bottom-div-form-table-input-text'
                                    onChange={(e) => { this.handleInputOnChange('firstName', e.target.value); }} />
                            </td>
                        </tr>
                        <tr>
                            <td className='feedback-bottom-div-form-table-td-left'>Last Name</td>
                            <td className='feedback-bottom-div-form-table-td-right'>
                                <input type='text' value={this.state.lastName} className='feedback-bottom-div-form-table-input-text'
                                    onChange={(e) => { this.handleInputOnChange('lastName', e.target.value); }} />
                            </td>
                        </tr>
                        <tr>
                            <td className='feedback-bottom-div-form-table-td-left'>Email address</td>
                            <td className='feedback-bottom-div-form-table-td-right'>
                                <input type='text' value={this.state.email} className='feedback-bottom-div-form-table-input-text'
                                    onChange={(e) => { this.handleInputOnChange('email', e.target.value); }} />
                            </td>
                        </tr>
                        <tr>
                            <td className='feedback-bottom-div-form-table-td-left'>Your feedback</td>
                            <td className='feedback-bottom-div-form-table-td-right'>
                                <textarea rows='5' value={this.state.feedbackText} className='feedback-bottom-div-form-table-input-textarea'
                                    onChange={(e) => { this.handleInputOnChange('feedbackText', e.target.value); }}></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td className='feedback-bottom-div-form-table-td-left feedback-bottom-div-form-table-td-rating'>Rating</td>
                            <td className='feedback-bottom-div-form-table-td-right feedback-bottom-div-form-table-td-rating'>
                                <StarRating rating={this.state.rating} totalStars={5} onRatingClick={(e, ratObj) => { this.handleRatingClick(e, ratObj); }} />
                            </td>
                        </tr>
                        <tr>
                            <td className='feedback-bottom-div-form-table-td-left'></td>
                            <td className='feedback-bottom-div-form-table-td-right'>
                                <input style={{ backgroundColor: '#0080FF' }} type='button' value='Submit Feedback' onClick={(e) => { this.handleClear(); }} className='feedback-bottom-div-form-table-input-button' />
                                <input type='button' value='Clear' className='feedback-bottom-div-form-table-input-button' onClick={(e) => { this.handleClear(); }} />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div >
        );
    }

}