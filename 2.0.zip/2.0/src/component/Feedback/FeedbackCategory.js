import React, { Component } from 'react';
import * as Action from '../../action/Actions';
import FeedbackSelect from './FeedbackSelect';
import feedbackDataStore from '../../store/feedbackDataStore';

export default class FeedbackCategory extends Component {

    constructor(props) {
        super(props);
        this.state = {
            feedbackSelector: feedbackDataStore.getFeedbackSelector(),
            feedbackSelectorSelected: feedbackDataStore.getFeedbackSelected()
        };
    }

    render() {
        let categoryList = this.state.feedbackSelector.map((item) => {
            let isSelected = false;
            if (this.state.feedbackSelectorSelected === item.value) {
                isSelected = true;
            }
            return (
                <FeedbackSelect value={item.value} isSelected={isSelected} />
            );
        });
        return (
            <div className='feedback-bottom-div-category-div'>
                <div className='feedback-bottom-div-category-label-div'>
                    <label>Select from below</label>
                </div>
                <div className='feedback-bottom-div-category-list-div'>
                    {categoryList}
                </div>
            </div>
        );
    }

    componentDidMount() {
        feedbackDataStore.on("FeedbackTypeSelectedChanged", () => {
            this.setState({
                feedbackSelectorSelected: feedbackDataStore.getFeedbackSelected()
            });
        });
    }

    componentWillUnmount() {
        feedbackDataStore.removeListener("FeedbackTypeSelectedChanged", () => {
        });
    }

}