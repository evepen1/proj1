import React, { Component } from "react";
import tradeStateDataStore from "../../../store/tradeStateDataStore";
import * as Action from "../../../action/Actions";

export default class TradeStateTable extends Component {
  constructor() {
    super();
    this.state = {
      exceptionTableData: tradeStateDataStore.getTradeStateData(),
      tableDataDisplay: false,
      currentPage: 1,
      lastPage: 1,
      rowPerPageLimit: 10,
    };
  }

  pageIncrement() {
    if (this.state.currentPage < this.state.lastPage) {
      this.setState({
        currentPage: this.state.currentPage + 1
      });
    }
  }

  pageDecrement() {
    if (this.state.currentPage > 1) {
      this.setState({
        currentPage: this.state.currentPage - 1
      });
    }
  }

  render() {

    if (this.state.tableDataDisplay) {
      let header = tradeStateDataStore.getTradeStateHeaderList().map(item => {
        return (
          <th className="ewdashboard-exceptiontable-th-header">
            <div>
              <div className="ewdashboard-exceptiontable-Headers"> {item.displayName}</div>
            </div>
          </th>
        );
      });

      let tempTableData = [];
      for (
        let i = (this.state.currentPage - 1) * this.state.rowPerPageLimit;
        i < this.state.exceptionTableData.length &&
        i < this.state.currentPage * this.state.rowPerPageLimit;
        ++i
      ) {
        tempTableData.push(this.state.exceptionTableData[i]);
      }
      let records = tempTableData.map((item, index) => {
        let colList = tradeStateDataStore.getTradeStateHeaderList().map(header => {
          let style = {
            color: 'white'
          };
          if (item[header.fieldName] == 'X') {
            style.color = '#ff4c4c';
            style.width = '20px';
            style.height = '18px';
            style.position = 'relative';
            style.left = '45%';
            style.borderRadius = '10px';
            style.backgroundColor = '#ff4c4c';
          }
          else if (item[header.fieldName] == 'W') {
            style.color = '#ffc04c';
            style.width = '20px';
            style.height = '18px';
            style.position = 'relative';
            style.left = '45%';
            style.borderRadius = '10px';
            style.backgroundColor = '#ffc04c';
          }
          else if (item[header.fieldName] == 'Y') {
            style.color = '#90EC7D';
            style.width = '20px';
            style.height = '18px';
            style.position = 'relative';
            style.left = '45%';
            style.borderRadius = '10px';
            style.backgroundColor = '#90EC7D';
          }
          return (
            <td className="tradestate-exceptiontable-td">
              <div style={style}>{item[header.fieldName]}</div>
            </td>
          );
        });
        return (
          <tr
            key={item.client + item.tradeId}
            className={"tradestate-exceptiontable-tr-" + index % 2}
          >
            {colList}
          </tr>
        );
      });
      return (
        <div className="tradestate-exceptiontable-div">
          <div className="ewdashboard-exceptiontable-table-div">
            <table
              className="ewdashboard-exceptiontable-table"
            >
              <thead className="ewdashboard-exceptiontable-table-thead">
                <tr
                  key="header"
                  className="ewdashboard-exceptiontable-tr-header"
                >
                  {header}
                </tr>
              </thead>
              <tbody className="ewdashboard-exceptiontable-table-tbody">
                {records}
              </tbody>
            </table>
          </div>
          <div className="ewdashboard-exceptiontable-pagination-div">
            <div className="ewdashboard-exceptiontable-pagination-pagediv">
              <div
                className="ewdashboard-exceptiontable-pagination-leftArrow"
                onClick={e => {
                  this.pageDecrement();
                }}
              />
              <div className="ewdashboard-exceptiontable-pagination-centertext">
                Page {this.state.currentPage} of {this.state.lastPage}
              </div>
              <div
                className="ewdashboard-exceptiontable-pagination-rightArrow"
                onClick={e => {
                  this.pageIncrement();
                }}
              />
            </div>
          </div>
        </div>
      );
    } else {
      return <div className="ewdashboard-exceptiontable-div-loading" />;
    }
  }

  componentDidMount() {
    tradeStateDataStore.on("TradeStateDataRefreshed", () => {
      let lastPage = Math.ceil(tradeStateDataStore.getTradeStateData().length / 10);
      if (lastPage == 0) {
        lastPage = 1;
      }
      let curPage = this.state.currentPage;
      if (curPage > lastPage) {
        curPage = 1;
      }
      this.setState({
        exceptionTableData: tradeStateDataStore.getTradeStateData(),
        tableDataDisplay: true,
        currentPage: curPage,
        lastPage: lastPage
      });
    });
    Action.refreshTradeStateData();
  }

  componentWillUnmount() {
    tradeStateDataStore.removeListener("TradeStateDataRefreshed", () => { });
  }
}
