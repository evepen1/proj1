import React, { Component } from 'react';
import SummaryDetail from './SummaryDetail';

export default class Summary extends Component {
    render() {
        return (
            <div className='ewdashboard-summary-container'>
                <SummaryDetail />
            </div>
        );
    }
}