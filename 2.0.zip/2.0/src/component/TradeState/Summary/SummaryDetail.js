import React, { Component } from 'react';
import tradeStateDataStore from '../../../store/tradeStateDataStore';
import ProgressBar from '../../ProgressBar/ProgressBar';
import * as Action from '../../../action/Actions';

export default class SummaryDetail extends Component {

    constructor() {
        super();
        this.state = {
            tradeStateSummaryData: tradeStateDataStore.getTradeStateSummaryData()
        };
    }

    render() {
        let headRow = tradeStateDataStore.getTradeStateSummaryHeaderList().map((item) => {
            let arrowStyle = {display : 'block'}
            if(item.fieldName === 'dataDelivery') {
                arrowStyle = {display : 'none'}
            }
            let arrowDiv = <div style={arrowStyle} className='tradestate-summary-detail-arrow-icon'></div>;
            return <th className='tradestate-summary-detail-table-th'>
                {item.displayName}
                {arrowDiv}
            </th>
        });
        let records = Object.keys(this.state.tradeStateSummaryData).map((clientName) => {
            let totalTrades = 0;
            let sumDataPerClient = this.state.tradeStateSummaryData[clientName];
            let subRecords = tradeStateDataStore.getTradeStateSummaryHeaderList().map((stageName) => {
                totalTrades += (sumDataPerClient[stageName.fieldName].Y + sumDataPerClient[stageName.fieldName].W + sumDataPerClient[stageName.fieldName].X);
                return <td>
                    <ProgressBar stageName={stageName.displayName} clientName={clientName} green={sumDataPerClient[stageName.fieldName].Y}
                        orange={sumDataPerClient[stageName.fieldName].W}
                        red={sumDataPerClient[stageName.fieldName].X} />
                </td>;
            });
            return <tr className='tradestate-summary-detail-table-tr'>
                <td className='tradestate-summary-detail-table-td'>
                    <span> {clientName}</span>
                    <span className='tradestate-summary-detail-table-total-trade-span'>{'   (' + totalTrades / 5 + ')'}</span>
                </td>
                {subRecords}
            </tr>;
        });
        return (
            <div className='tradestate-summary-detail-div'>
                <div className='tradestate-summary-detail-table-div'>
                    <table className='tradestate-summary-detail-table'>
                        <thead className='tradestate-summary-detail-thead'>
                            <tr>
                                <th>
                                </th>
                                {headRow}
                            </tr>
                        </thead>
                        <tbody>
                            {records}
                        </tbody>
                    </table>
                </div>
                <div className='tradestate-summary-detail-legend-div'>
                    <div className='tradestate-summary-detail-legend-container'>
                        <div className='tradestate-summary-detail-legend-green'>

                        </div>
                        <div className='tradestate-summary-detail-legend-green-data'>
                            Processed
                    </div>
                        <div className='tradestate-summary-detail-legend-orange'>

                        </div>
                        <div className='tradestate-summary-detail-legend-orange-data'>
                            Not Recieved
                    </div>
                        <div className='tradestate-summary-detail-legend-red'>

                        </div>
                        <div className='tradestate-summary-detail-legend-red-data'>
                            Exception
                    </div>
                    </div>
                </div>
            </div>
        );
    }

    componentDidMount() {
        tradeStateDataStore.on("TradeStateSummaryDataRefreshed", () => {
            this.setState({
                tradeStateSummaryData: tradeStateDataStore.getTradeStateSummaryData()
            });
        });
        Action.refreshTradeStateSummaryData();
    }

    componentWillUnmount() {
        tradeStateDataStore.removeListener("TradeStateSummaryDataRefreshed", () => {
        });
    }

}