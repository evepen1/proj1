import React, { Component } from 'react';
import { hashHistory } from 'react-router';
import CriticalityBox from './CriticalityBox';
import CategoryList from './CategoryList';
import exceptionSummaryDataStore from '../../../store/exceptionSummaryDataStore';
import activeExceptionCategoryListStore from '../../../store/actveExceptionCategoryStore';
import * as Action from '../../../action/Actions';

export default class SummaryDetail extends Component {

    render() {

        return (
            <div className='navupstream-summary-left-div'>
                <div className='navupstream-summary-left-table-container-div'>
                    <table className='navupstream-summary-left-table'>
                        <tbody>
                            <tr>
                                <td></td>
                                <td>Trade</td>
                                <td>TA</td>
                                <td>CA</td>
                                <td>FxRate</td>
                                <td>Pricing</td>
                                <td>Auto Trigger</td>
                                <td>Trigger Accounting</td>
                                <td>NAV exceptions</td>
                            </tr>
                            <tr>
                                <td>NAV GRP1</td>
                                <td className='navupstream-summary-left-td-no'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td>
                                    <input type='checkbox' checked />
                                </td>
                                <td>
                                    <input type='button' disabled value='Submit' className='navupstream-summary-left-submit-disable' />
                                </td>
                                <td>
                                    -
                                </td>
                            </tr>
                            <tr>
                                <td>NAV GRP2</td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-no'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td>
                                    <input type='checkbox' />
                                </td>
                                <td>
                                    <input type='button' disabled value='Submit' className='navupstream-summary-left-submit-disable' />
                                </td>
                                <td>
                                    -
                                </td>
                            </tr>
                            <tr>
                                <td>NAV GRP3</td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-no'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td>
                                    <input type='checkbox' />
                                </td>                                <td>
                                    <input type='button' disabled value='Submit' className='navupstream-summary-left-submit-disable' />
                                </td>
                                <td>
                                    -
                                </td>
                            </tr>
                            <tr>
                                <td>NAV GRP4</td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td>
                                    <input type='checkbox' />
                                </td>                                <td>
                                    <input type='button' value='Submit' className='navupstream-summary-left-submit-enable' />
                                </td>
                                <td>
                                    -
                                </td>
                            </tr>
                            <tr>
                                <td>NAV GRP5</td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td>
                                    <input type='checkbox' checked />
                                </td>
                                <td>
                                    <input type='button' value='Submited' className='navupstream-summary-left-submited' />
                                </td>
                                <td className='navupstream-summary-left-td-exception'
                                    onClick={(e) => { hashHistory.push('nav/abornav'); }}></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }

    componentDidMount() {

    }

    componentWillUnmount() {

    }

}