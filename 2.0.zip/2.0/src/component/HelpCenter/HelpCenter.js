import React, { Component } from 'react';
import * as Action from '../../action/Actions';
import HelpCenterSearch from './HelpCenterSearch';
import ProductLines from './ProductLines';
import Faqs from './Faqs';

export default class HelpCenter extends Component {

    render() {
        return (
            <div>
                <div className='helpcenter-container-div-white-overlay'>
                    <div className='helpcenter-top-div-container'>
                        <div className='helpcenter-top-top-div'>
                            <div className='helpcenter-top-top-help-icon-div'></div>
                            <div className='helpcenter-top-top-help-text-div'><i>Help Center</i></div>
                            <div className='helpcenter-top-top-close-div' onClick={(e) => { this.props.closeHelpCenterPopup(); }}>X</div>
                            <div className='helpcenter-top-top-feedback-div' onClick={(e) => { this.props.openFeedbackPopup(); }}></div>
                        </div>
                        <HelpCenterSearch />
                    </div>
                    <div className='helpcenter-bottom-div-container'>
                        <ProductLines />
                        <Faqs />
                    </div>
                </div>
                <div className='helpcenter-container-div-dark-overlay' onClick={(e) => { this.props.closeHelpCenterPopup(); }}>

                </div>
            </div>
        );
    }

}