import React, { Component } from 'react';
import Slider from 'react-slick';
import Product from './Product'
import helpCenterDataStore from '../../store/helpCenterDataStore';

export default class ProductLines extends Component {

    render() {
        let settings = {
            slidesToShow: 3,
            slidesToScroll: 2,
            autoplay: true,
            autoplaySpeed: 2000,
            pauseOnHover: true,
            infinite: true,
            swipeToSlide: true,
            arrows: false,
            useCSS: true,
            className: 'left'
        };
        let style = {
            height: '129%',
            width: 'auto'
        }
        let productDetails = helpCenterDataStore.getProductDetails();
        let products = productDetails.map((item, index) => {
            return (
                <div data-index={index} style={style} className='helpcenter-product-container'>
                    <Product {...item} key={index} />
                </div>);
        });
        return (
            <div className='helpcenter-bottom-productline-div'>
                <Slider {...settings}>
                    {products}
                </Slider>
            </div>
        );
    }

}