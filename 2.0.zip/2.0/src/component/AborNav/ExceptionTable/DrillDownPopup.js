import React from 'react'
import * as Action from "../../../action/Actions";
import PopupStore from "../../../store/PopupStore";
import exceptionTableAborNavDataStore from "../../../store/exceptionTableAborNavDataStore";
import CommentHistoryPopUp from "./CommentHistoryPopUp"
export default class DrillDownPopup extends React.Component {

    constructor() {
        super();
        this.data = {
            headerList: [
                { displayName: 'Validation Code', fieldName: 'validationCode' },
                { displayName: 'Approval State Description', fieldName: 'approvalStateDescription' },
                { displayName: 'Exception Description', fieldName: 'exceptionDescription' },
                { displayName: 'Override', fieldName: 'override' },
                { displayName: 'Override User', fieldName: 'overrideUser' },
                { displayName: 'Tolerance', fieldName: 'tolerance' },
                { displayName: 'Status', fieldName: 'status' }
            ]
        }
        this.state = {
            clickedRow: 0,
            clickedRowItem: {},
            //selectedSecurityId: 'AxySID : GLB1.EB, Ticker : GLB1, Sector : (Consumer, Non-cyclical), Exchange : EB',
            collapseRemediation: true,
            collapseCommentary: true
        };
        this.clicked = false;
        // this.securityIdOptions = ['AxySID : GLB1.EB, Ticker : GLB1, Sector : (Consumer, Non-cyclical), Exchange : EB',
        //     'AxySID : SMWC.P, Ticker : SMWC, Sector : (Consumer, Cyclical), Exchange : XLON',
        //     'AxySID : FN.MBS.827591, Ticker : FN, Sector : Financial, Exchange : OTCNY',
        //     'AxySID : FN.MBS.935340, Ticker : FN, Sector : Financial, Exchange : OTCUS'];
    }

    handleOnClickClose(e) {
        this.props.handleonclose();
    }

    handleClickRow(e, index, item) {
        if (this.index != 0 && this.state.clickedRow == index) {
            this.setState({ clickedRow: 0, clickedRowItem: {} })
        } else if (index == 0) {
            this.setState({ clickedRow: 0, clickedRowItem: item })
        } else {
            this.setState({ clickedRow: index, clickedRowItem: item })
        }
        console.log(index);
    }

    handleImClick() {
        Action.handleDrillDownHeaderIconClick("chat");
    }

    handleHelpClick() {
        this.handleOnClickClose();
        Action.handleDrillDownHeaderIconClick("help");
    }

    handleRemediationArrowToggle() {
        if (this.state.collapseRemediation) {
            this.setState({ collapseRemediation: false });
        } else {
            this.setState({ collapseRemediation: true });
        }
    }

    handleCommentaryArrowToggle() {
        if (this.state.collapseCommentary) {
            this.setState({ collapseCommentary: false });
        } else {
            this.setState({ collapseCommentary: true });
        }
    }

    // handleTradeFileClick() {
    //     console.log(this.props.item);
    //     if (this.props.item.filePath === undefined) {
    //         alert('No file found!');
    //     }
    //     else {
    //         Action.openFile(this.props.item.filePath);
    //     }
    // }

    showAlertMessage() {
        confirm('Request Submitted Successfully');
    }

    render() {

        let style = { display: 'block' };

        let toggleRemediationStyle = {
            arrowStyle: {},
            container: {}
        }

        let toggleCommentaryStyle = {
            arrowStyle: {},
            container: {}
        }

        if (this.state.collapseRemediation) {
            toggleRemediationStyle.arrowStyle.borderTop = '8px solid transparent';
            toggleRemediationStyle.arrowStyle.borderLeft = '13px solid #999';
            toggleRemediationStyle.container.display = 'none';
        }

        if (this.state.collapseCommentary) {
            toggleCommentaryStyle.arrowStyle.borderTop = '8px solid transparent';
            toggleCommentaryStyle.arrowStyle.borderLeft = '13px solid #999';
            toggleCommentaryStyle.container.display = 'none';
        }

        let header = this.data.headerList.map(item => {
            return (
                <th className="ewdashboard-exceptiontable-th-header">
                    {item.displayName}
                </th>
            );

        });


        let records = exceptionTableAborNavDataStore.getDetailedData(this.props.item.validationKey)
            .map((item, index) => {
                var tddCSS = 'ewdashboard-exceptiontable-tr-';
                if (index == 0) {
                    this.state.clickedRowItem = item;
                }
                if (index === this.state.clickedRow) {
                    tddCSS = tddCSS + 'clicked-';
                }
                let colList = this.data.headerList
                    .map(header => {
                        return (
                            <td className="ewdashboard-exceptiontable-td">
                                <div >{item[header.fieldName]}</div>
                            </td>
                        );
                    });
                return (
                    <tr
                        key={item._id + item.exceptionId + index}
                        className={tddCSS + index % 2}
                        onClick={(e) => { this.handleClickRow(e, index, item) }}
                    >
                        {colList}
                    </tr>
                );
            });

        let selectedRemediationSteps;

        return (
            <div>
                <div style={style} className="ewdashboard-exceptiontable-drilldown-popup-div">
                    <div className='ewdashboard-exceptiontable-popup-close'>
                        <div className='navigationpanel-icon navigationpanel-icon-im' onClick={(e) => { this.handleImClick() }}></div>
                        <div className='navigationpanel-icon navigationpanel-icon-help' onClick={(e) => { this.handleHelpClick() }}></div>
                        <input className='ewdashboard-exceptiontable-popup-x-close'
                            type='button' value='X'
                            onClick={(e) => { this.handleOnClickClose(e) }} />
                    </div>
                    <div className='ewdashboard-exceptiontable-drilldown-popup-content-div'>
                        <div style={style} className='ewdashboard-exceptiontable-popup-summary-div'>
                            <table className="ewdashboard-exceptiontable-popup-summary-table">
                                <tbody>
                                    <tr>
                                        <th style={{ color: '#999' }} scope="row">Branch : </th>
                                        <td>{this.props.item.branch}</td>
                                        <th style={{ color: '#999' }} scope="row">Fund Code : </th>
                                        <td>{this.props.item.fundCode}</td>
                                    </tr>
                                    <tr>
                                        <th style={{ color: '#999' }} scope="row">Client : </th>
                                        <td>{this.props.item.client}</td>
                                        <th style={{ color: '#999' }} scope="row">Domicile : </th>
                                        <td>{this.props.item.domicile}</td>
                                    </tr>
                                    <tr>
                                        <th style={{ color: '#999' }} scope="row">Price Location : </th>
                                        <td>{this.props.item.priceLocation}</td>
                                        <th style={{ color: '#999' }} scope="row">Price Run Type : </th>
                                        <td>{this.props.item.priceRunType}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div style={style} className="ewdashboard-exceptiontable-popup-detailed-div">
                            <div className="ewdashboard-exceptiontable-detailed-header-div">
                                <span style={{ color: '#999' }}> Exception Details : </span>
                            </div>
                            <div className="ewdashboard-exceptiontable-detailed-table-div">
                                <table className="ewdashboard-exceptiontable-detailed-table">
                                    <thead className="ewdashboard-exceptiontable-table-thead">
                                        <tr
                                            key="header"
                                            className="ewdashboard-exceptiontable-tr-header"
                                        >
                                            {header}
                                        </tr>
                                    </thead>
                                    <tbody className="ewdashboard-exceptiontable-table-tbody">
                                        {records}
                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <div className="ewdashboard-exceptiontable-popup-remediation-div">
                            <div className="ewdashboard-exceptiontable-popup-component-header" onClick={() => this.handleRemediationArrowToggle()}>
                                <div style={toggleRemediationStyle.arrowStyle} className="ewdashboard-exceptiontable-popup-arrow-toggle"></div>
                                <span style={{ color: '#999' }}> Remediation Steps : </span>
                            </div>
                            <div style={toggleRemediationStyle.container} className="ewdashboard-exceptiontable-popup-remediation-data">
                                {selectedRemediationSteps}
                            </div>
                        </div>

                        <div className="ewdashboard-exceptiontable-popup-commentary-div">
                            <div className="ewdashboard-exceptiontable-popup-component-header" onClick={() => this.handleCommentaryArrowToggle()}>
                                <div style={toggleCommentaryStyle.arrowStyle} className="ewdashboard-exceptiontable-popup-arrow-toggle"></div>
                                <span style={{ color: '#999' }}> Commentary : </span>
                            </div>
                            <CommentHistoryPopUp item={this.state.clickedRowItem} style={toggleCommentaryStyle.container} />
                        </div>

                    </div>
                </div>
                <div style={style} className="ewdashboard-exceptiontable-black_overlay"></div>
            </div>
        );
    }

}