import React from 'react'
import * as Action from "../../../action/Actions";
export default class TableTextArea extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      value: this.props.item.comment
    };
    this.data = {
      prevComment: '',
      prevStatus: ''
    };
  }

  handleCommentBlur(e, comment) {
    if(this.data.prevComment != e.target.value && e.target.value != "") {
    //Action.updateComment(e.target, this.data.prevComment, comment);
    }
  }

  handleDropDownChange(e, statusUpdate) {
    Action.updateStatus(e.target, this.data.prevStatus, statusUpdate);
  }

  handleOnFocusComment(e) {
    this.data.prevComment = e.target.value;
  }

  handleOnFocusStatus(e) {
    this.data.prevStatus = e.target.value;
  }

  handleOnChangeComment(e) {
      this.setState({ value: e.target.value });
  }

  render() {
    return (<textarea value={this.state.value} className='ewdashboard-exceptiontable-comment-textarea' 
    onChange={(e) => this.handleOnChangeComment(e)} 
    onFocus={(e) => this.handleOnFocusComment(e)} onBlur={(e) => {
      this.handleCommentBlur(e,
        { exceptionId: this.props.item.exceptionId,
         id: this.props.item._id, comment: e.target.value }
      );
    }}>
    </textarea>
    );
  }

}
