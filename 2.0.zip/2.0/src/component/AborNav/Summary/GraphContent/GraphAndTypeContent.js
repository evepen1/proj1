import React, { Component } from 'react';
import GraphTypeSelector from './GraphTypeSelector';
import GraphContainer from './GraphContainer';

export default class GraphAndTypeContent extends Component {

    render() {
        return (
            <div className='ewdashboard-summary-graph-type-selector-div'>
                {/*<GraphTypeSelector />*/}
                <GraphContainer />
            </div>
        );
    }

}