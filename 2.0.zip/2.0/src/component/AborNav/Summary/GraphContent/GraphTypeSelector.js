import React, { Component } from 'react';
import graphAborNavDataStore from '../../../../store/graphAborNavDataStore';
import * as Action from '../../../../action/Actions';

export default class GraphTypeSelector extends Component {

    constructor() {
        super();
        this.state = {
            grpahTypeSelected: graphAborNavDataStore.getGraphTypeSelected()
        };
    }

    handleGraphTypeOnChange(type) {
        Action.changeGraphTypeAborNav(type);
    }

    render() {
        let options = graphAborNavDataStore.getGraphTypeList().map((item) => {
            if (item == this.state.grpahTypeSelected) {
                return (
                    <option selected value={item} className='ewdashboard-summary-graph-type-dropdown-option'>{item}</option>
                );
            }
            return (
                <option value={item} className='ewdashboard-summary-graph-type-dropdown-option'>{item}</option>
            );
        });
        return (
            <div className='ewdashboard-summary-graph-type-dropdown-div'>
                <select className='ewdashboard-summary-graph-type-dropdown-select' onChange={(e) => { this.handleGraphTypeOnChange(e.target.value) }}>
                    {options}
                </select>
            </div>
        );
    }

    componentDidMount() {
        graphAborNavDataStore.on("GraphTypeSelectedChangedAborNav", () => {
            this.setState({
                grpahTypeSelected: graphAborNavDataStore.getGraphTypeSelected()
            });
        });
    }
    componentWillUnmount() {
        graphAborNavDataStore.removeListener("GraphTypeSelectedChangedAborNav", () => {
        });
    }

}