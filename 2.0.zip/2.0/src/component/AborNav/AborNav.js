import React, { Component } from 'react';
import HeaderBar from './Header/Header';
import Summary from './Summary/Summary';
import ExceptionTable from './ExceptionTable/ExceptionTable';
import * as Action from '../../action/Actions';
import activeExceptionCategoryListAborNavStore from '../../store/activeExceptionCategoryListAborNavStore';
import exceptionSummaryAborNavDataStore from '../../store/exceptionSummaryAborNavDataStore';
import graphAborNavDataStore from '../../store/graphAborNavDataStore';

export default class AborNav extends Component {
    render() {
        return (
            <div className='ewdashboard-container'>
                <div className='ewdashboard-container-abornav-header'></div>
                <Summary />
                <ExceptionTable />
            </div>
        );
    }

    componentDidMount() {
        this.autoRefresh = setInterval(function () {
            Action.refereshCriticalitySummaryAborNavData();
            Action.refreshChartAborNavData(graphAborNavDataStore.getGraphNameSelected());
            Action.refreshExceptionTableAborNavData(exceptionSummaryAborNavDataStore.getActiveCriticalityValue());
        }, 10000);
    }

    componentWillUnmount() {
        clearInterval(this.autoRefresh);
    }
}