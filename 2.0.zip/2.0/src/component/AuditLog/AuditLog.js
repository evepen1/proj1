import React from 'react'
import auditLogDataStore from '../../store/auditLogDataStore';
import * as Action from '../../action/Actions';

export default class AuditLog extends React.Component {

    constructor() {
        super();
        this.state = {
            auditHistory: auditLogDataStore.getAuditHistory(),
            auditFilerActive: auditLogDataStore.getAuditFilterStatus(),
            auditFilter: auditLogDataStore.getAuditFilter()
        }
    }

    handleHeaderClick() {
        Action.toggleAuditFilterStatus(!this.state.auditFilerActive);
    }

    handleInputChange(newValue, fieldName) {
        Action.addAuditFilter(newValue, fieldName);
    }

    render() {
        let headerList = auditLogDataStore.getHeaderList().map((header) => {
            return (
                <td>{header.displayName}</td>
            );
        });
        let records = this.state.auditHistory.map((item) => {
            let colList = auditLogDataStore.getHeaderList().map((header) => {
                return (
                    <td className='auditing-table-td'>
                        {item[header.fieldName]}
                    </td>
                );
            });
            return (
                <tr className='auditing-table-tr'>{colList}</tr>
            );
        });
        let filterRow;
        if (this.state.auditFilerActive) {
            filterRow = <tr>
                {auditLogDataStore.getHeaderList().map((header) => {
                    return (
                        <td className='auditing-table-td'>
                            <input className='audit-filter-input-text'
                                placeholder={header.displayName}
                                type='text'
                                onChange={(e) => {
                                    this.handleInputChange(e.target.value, header.fieldName)
                                }}
                                value={this.state.auditFilter[header.fieldName]} />
                        </td>
                    );
                })}
            </tr>
        }
        return (
            <div>
                <div className='auditlog-container-div-white-overlay'>
                    <div className='auditlog-top-div-container'>
                        <div className='feedback-top-top-div'>
                            <div className='auditlog-top-top-feedback-icon-div'></div>
                            <div className='feedback-top-top-feedback-text-div'>
                                <div className='auditlog-text-aling-mid'>
                                    <i>Audit Logs</i>
                                </div>
                            </div>
                            <div className='auditlog-top-top-close-div' onClick={(e) => { this.props.closeAuditLogPopup(); }}>
                                <div className='auditlog-text-aling-mid'>
                                    X
                              </div>
                            </div>
                        </div>
                    </div>
                    <div className='auditlog-bottom-div-container'>
                        <table className='auditing-table'>
                            <thead>
                                <tr className='auditing-table-tr auditing-table-tr-head' onClick={(e) => {
                                    this.handleHeaderClick()
                                }}>
                                    {headerList}
                                </tr>
                            </thead>
                            <tbody>
                                {filterRow}
                                {records}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className='auditlog-container-div-dark-overlay' onClick={(e) => { this.props.closeAuditLogPopup(); }}>

                </div>
            </div>
        );
    }

    componentDidMount() {
        auditLogDataStore.on("updateAuditHistory", () => {
            this.setState({
                auditHistory: auditLogDataStore.getAuditHistory()
            });
        });
        auditLogDataStore.on("auditFIlterStatusChanged", () => {
            this.setState({
                auditHistory: auditLogDataStore.getAuditHistory(),
                auditFilerActive: auditLogDataStore.getAuditFilterStatus(),
                auditFilter: auditLogDataStore.getAuditFilter()
            });
        });
        auditLogDataStore.on("auditFilterValueChanged", () => {
            this.setState({
                auditHistory: auditLogDataStore.getAuditHistory(),
                auditFilter: auditLogDataStore.getAuditFilter()
            });
        });
        Action.updateAuditHistory();
        this.autoRefresh = setInterval(function () {
            Action.updateAuditHistory();
        }, 10000);
    }

    componentWillUnmount() {
        auditLogDataStore.removeListener("updateAuditHistory", () => {
        });
        auditLogDataStore.removeListener("auditFIlterStatusChanged", () => {
        });
        auditLogDataStore.removeListener("auditFilterValueChanged", () => {
        });
        clearInterval(this.autoRefresh);
    }

}