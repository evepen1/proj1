import React, { Component } from "react";
import exceptionTableDataStore from "../../../store/exceptionTableDataStore";
import activeExceptionCategoryListStore
  from "../../../store/actveExceptionCategoryStore";
import exceptionSummaryDataStore
  from "../../../store/exceptionSummaryDataStore";
import * as Action from "../../../action/Actions";
import fileDownloadStore from "../../../store/fileDownloadStore";
import DrillDownPopup from "./DrillDownPopup"
import TableTextArea from './TableTextArea'
import FilterPopup from "./FilterPopup";

export default class ExceptionTable extends Component {
  constructor() {
    super();
    this.state = {
      exceptionTableData: exceptionTableDataStore.getTableData(),
      tableDataDisplay: false,
      currentPage: 1,
      lastPage: 1,
      rowPerPageLimit: 10,
      data: {
        dropDownOptions: ['Open', 'Work in progress', 'At Risk','Resolved'],
        // assigneeDropDownOptions: ['', 'Barry Grist', 'Michelle Kennedy', 'Michal Wyrzykowski'],
        prevStatus: 'S',
        prevComment: 'C',
        prevAssignee: 'S',
      },
      checkBoxAll: 0,
      activeItemId: null,
      displayPopUp: false,
      activeHeader: null,
      activeHeaderPopup: false,
      checkedItemSearchBox: exceptionTableDataStore.getCheckedItemSearchBox(),
      tableDescIndexSelected: -1
    };
    this.filterPopup = {
      xposition: 0,
      yposition: 0
    };
  }

  handleMouseEnterOverDescription(e, value) {
    this.setState({
      tableDescIndexSelected: value
    });
  }

  handleMouseLeaveOverDescription(e, value) {
    this.setState({
      tableDescIndexSelected: -1
    });
  }

  pageIncrement() {
    if (this.state.currentPage < this.state.lastPage) {
      this.setState({
        currentPage: this.state.currentPage + 1
      });
    }
  }

  pageDecrement() {
    if (this.state.currentPage > 1) {
      this.setState({
        currentPage: this.state.currentPage - 1
      });
    }
  }

  handleMouseWheeling(e) {
    if (e.deltaY < 0) {
      this.pageIncrement();
    } else {
      this.pageDecrement();
    }
  }

  handleCheckBoxOnChange(item) {
    Action.refreshFileDownloadData(item);
  }

  handleOnFocusStatus(e) {
    this.state.data.prevStatus = e.target.value;
  }

  handleOnFocusAssignee(e) {
    this.state.data.prevAssignee = e.target.value;
  }
  handleDropDownChange(e, statusUpdate) {
    Action.updateStatus(e.target, this.state.data.prevStatus, statusUpdate);
  }
  handleAssigneeDropDownChange(e, assigneeUpdate) {
    Action.updateAssignee(e.target, this.state.data.prevAssignee, assigneeUpdate);
  }
  handleCheckBoxToSellectAllOnCurrentPage() {
    let tempTableData = [];
    for (
      let i = (this.state.currentPage - 1) * this.state.rowPerPageLimit;
      i < this.state.exceptionTableData.length &&
      i < this.state.currentPage * this.state.rowPerPageLimit;
      ++i
    ) {
      tempTableData.push(this.state.exceptionTableData[i]);
    }

    Action.refreshAllFileDownloadData({
      tempData: tempTableData,
      currentPage: this.state.currentPage
    })
  }

  handleOnClickOpenPopup(itemId) {
    this.setState({
      activeItemId: itemId
    });
  }
  handlePopupClose() {
    this.setState({
      activeItemId: null
    });
  }
  handleOnClickFilterPopupOpen(e, header) {

    this.filterPopup.xposition = e.target.getBoundingClientRect().right - 20;
    this.filterPopup.yposition = e.target.getBoundingClientRect().top + 15;
    this.setState({ activeHeader: header });
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
  }

  handleOnClickFilterPopupClose() {
    this.setState({ activeHeader: null });
    // e.stopPropagation();
    // e.nativeEvent.stopImmediatePropagation();
  }
  render() {

    let filterPopupStyle = {
      'position': 'fixed',
      'top': this.filterPopup.yposition,
      'left': this.filterPopup.xposition
    };


    if (this.state.tableDataDisplay) {
      let header = exceptionTableDataStore.getEtfTableHeaderList().map(item => {
        if (item.displayName == "checkBox") {

          if (fileDownloadStore.checkedAllCurrentPage(this.state.currentPage)) {
            return (
              <th className="ewdashboard-exceptiontable-th-header">
                <input
                  className="ewdashboard-exceptiontable-checkbox"
                  type="checkbox" checked onChange={(e) =>
                  { this.handleCheckBoxToSellectAllOnCurrentPage(); }}
                />
              </th>
            );
          } else {
            return (
              <th className="ewdashboard-exceptiontable-th-header">
                <input
                  className="ewdashboard-exceptiontable-checkbox"
                  type="checkbox" onChange={(e) =>
                  { this.handleCheckBoxToSellectAllOnCurrentPage(); }}
                />
              </th>
            );
          }
        }
        else {
          let style = {
            backgroundColor: '#333'
          }
          if (this.state.checkedItemSearchBox[item.fieldName] != undefined) {
            style.backgroundColor = '#3399FF';
          }
          let filterPopUpDisplay;
          if (this.state.activeHeader === item.fieldName) {
            filterPopUpDisplay = <div className="ewdashboard-exceptiontable-filter-div-popup" style={filterPopupStyle}><FilterPopup
              handleonclose={this.handleOnClickFilterPopupClose.bind(this)}
              headerFieldName={item.fieldName}
              checkedItemSearchBoxList={this.state.checkedItemSearchBox[item.fieldName]}
            /></div>;
          }
          return (
            <th style={style} className="ewdashboard-exceptiontable-th-header">
              <div>
                <div className="ewdashboard-exceptiontable-Headers"> {item.displayName}</div>
                {/*<div className="ewdashboard-exceptiontable-icon-filter"
                  onClick={(e) => this.handleOnClickFilterPopupOpen(e, item.fieldName)}>
                  {filterPopUpDisplay}
                </div>*/}
              </div>
            </th>
          );
        }
      });
 
      let tempTableData = [];
      for (
        let i = (this.state.currentPage - 1) * this.state.rowPerPageLimit;
        i < this.state.exceptionTableData.length &&
        i < this.state.currentPage * this.state.rowPerPageLimit;
        ++i
      ) {
        tempTableData.push(this.state.exceptionTableData[i]);
      }
      let records = tempTableData.map((item, index) => {



        let colList = exceptionTableDataStore
          .getEtfTableHeaderList()
          .map(header => {

            let options = this.state.data.dropDownOptions.map(dropdownItem => {
              if (dropdownItem == item[header.fieldName]) {
                return (<option selected className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={dropdownItem}>{dropdownItem}</option>);
              }
              return (<option className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={dropdownItem}>{dropdownItem}</option>);
            });
            let assigneeOptions = item['assigneeList'].map(dropdownItem => {
              if (dropdownItem == item[header.fieldName]) {
                return (<option selected className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={dropdownItem}>{dropdownItem}</option>);
              }
              return (<option className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={dropdownItem}>{dropdownItem}</option>);
            });
            if (
              item[header.fieldName] == undefined &&
              header.fieldName == "checkBox"
            ) {
              if (fileDownloadStore.isAlreadyExist(item)
                || fileDownloadStore.checkedAllCurrentPage(this.state.currentPage)) {
                return (
                  <td className="ewdashboard-exceptiontable-td">
                    <input
                      className="ewdashboard-exceptiontable-checkbox"
                      value={item}
                      onChange={(e) => { this.handleCheckBoxOnChange(item); }}
                      type="checkbox" checked
                    />
                  </td>
                );
              }
              else {
                return (
                  <td className="ewdashboard-exceptiontable-td">
                    <input
                      className="ewdashboard-exceptiontable-checkbox"
                      value={item}
                      onChange={(e) => { this.handleCheckBoxOnChange(item); }}
                      type="checkbox"
                    />
                  </td>
                );
              }
            }
            else if (header.fieldName == 'status') {
              return (<td className='ewdashboard-exceptiontable-td'>
                <select className='ewdashboard-exceptiontable-status-dropdown'
                  onClick={(e) => this.handleOnFocusStatus(e)}
                  onChange={(e) => {
                    this.handleDropDownChange(e, {
                      exceptionId: item.exceptionId,
                      id: item._id, status: e.target.value
                    });
                  }}>
                  {options}
                </select>
              </td>);
            }

            else if (header.fieldName == 'comment') {
              return (<td className='ewdashboard-exceptiontable-td'>
                <TableTextArea key={item._id + item.exceptionId} item={item} />
              </td>);
            }
            else if (header.fieldName == 'allocationId') {
              if (this.state.activeItemId === item._id) {
                this.state.displayPopUp = true;
              }
              let popUpDisplay;
              if (this.state.displayPopUp) {
                this.state.displayPopUp = false;
                popUpDisplay = <DrillDownPopup handleonclose={this.handlePopupClose.bind(this)} item={item} />;
              }
              return (<td className='ewdashboard-exceptiontable-td-link'>
                <div className="ewdashboard-exceptiontable-popup"
                  onClick={(e) => this.handleOnClickOpenPopup(item._id)}>{item[header.fieldName]}</div>
                {popUpDisplay}
              </td>);
            }
            else if (header.fieldName == "assignee") {
              return (<td className='ewdashboard-exceptiontable-td'>
                <select className='ewdashboard-exceptiontable-status-dropdown'
                  onClick={(e) => this.handleOnFocusAssignee(e)}
                  onChange={(e) => {
                    this.handleAssigneeDropDownChange(e, {
                      exceptionId: item.exceptionId,
                      id: item._id, assignee: e.target.value
                    });
                  }}>
                  {assigneeOptions}
                </select>
              </td>);
            }
            else if (header.fieldName == "errorDescription") {
              let desc = item[header.fieldName];
              if (this.state.tableDescIndexSelected === index || desc.length <= 30) {
                return (
                  <td className="ewdashboard-exceptiontable-td-description"
                    onMouseEnter={(e) => { this.handleMouseEnterOverDescription(e, index) }} onMouseLeave={(e) => { this.handleMouseLeaveOverDescription(e, index) }}>
                    <div >{desc}</div>
                  </td>
                );
              }
              else {
                return (
                  <td className="ewdashboard-exceptiontable-td-description"
                    onMouseEnter={(e) => { this.handleMouseEnterOverDescription(e, index) }} onMouseLeave={(e) => { this.handleMouseLeaveOverDescription(e, index) }}>
                    <div >{desc.substr(0, 30) + ' ...'}</div>
                  </td>
                );
              }
            }
            else {
              return (
                <td className="ewdashboard-exceptiontable-td">
                  <div >{item[header.fieldName]}</div>
                </td>
              );
            }
          });
        return (
          <tr
            key={item._id + item.exceptionId + index}
            className={"ewdashboard-exceptiontable-tr-" + index % 2}
          >
            {colList}
          </tr>
        );
      });
      return (
        <div className="navupstream-exceptiontable-div" onClick={(e) => { this.handleOnClickFilterPopupClose() }}>
          <div className="ewdashboard-exceptiontable-table-div">
            <table
              className="ewdashboard-exceptiontable-table"
            >
              <thead className="ewdashboard-exceptiontable-table-thead">
                <tr
                  key="header"
                  className="ewdashboard-exceptiontable-tr-header"
                >
                  {header}
                </tr>
              </thead>
              <tbody className="ewdashboard-exceptiontable-table-tbody">
                {records}
              </tbody>
            </table>
          </div>
          <div className="ewdashboard-exceptiontable-pagination-div">
            <div className="ewdashboard-exceptiontable-pagination-pagediv">
              <div
                className="ewdashboard-exceptiontable-pagination-leftArrow"
                onClick={e => {
                  this.pageDecrement();
                }}
              />
              <div className="ewdashboard-exceptiontable-pagination-centertext">
                Page {this.state.currentPage} of {this.state.lastPage}
              </div>
              <div
                className="ewdashboard-exceptiontable-pagination-rightArrow"
                onClick={e => {
                  this.pageIncrement();
                }}
              />
            </div>
          </div>
        </div>
      );
    } else {
      return <div className="ewdashboard-exceptiontable-div-loading" />;
    }
  }

  componentDidMount() {
    exceptionTableDataStore.on("TableDataRefreshed", () => {
      fileDownloadStore.clearFileDataStore();
      this.setState({
        exceptionTableData: exceptionTableDataStore.getTableData(),
        checkedItemSearchBox: exceptionTableDataStore.getCheckedItemSearchBox(),
        tableDataDisplay: true,
        currentPage: 1,
        lastPage: Math.ceil(exceptionTableDataStore.getTableData().length / 10)
      });
    });
    exceptionTableDataStore.on("FilterListChanged", () => {
      this.setState({
        checkedItemSearchBox: exceptionTableDataStore.getCheckedItemSearchBox()
      });
    });
    fileDownloadStore.on("FileDataRefreshed", () => {
      this.setState({});
    });
    Action.refreshExceptionTableData(
      activeExceptionCategoryListStore.getActiveCategory(),
      exceptionSummaryDataStore.getActiveCriticalityValue()
    );
  }

  componentWillUnmount() {
    exceptionTableDataStore.removeListener("TableDataRefreshed", () => { });
    exceptionTableDataStore.removeListener("FilterListChanged", () => { });
    fileDownloadStore.removeListener("FileDataRefreshed", () => { });
  }
}
