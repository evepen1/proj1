import React, { Component } from 'react';
import graphDataStore from '../../../../store/graphDataStore';
import * as Action from '../../../../action/Actions';

export default class GraphTypeSelector extends Component {

    constructor() {
        super();
        this.state = {
            grpahTypeSelected: graphDataStore.getGraphTypeSelected()
        };
    }

    handleGraphTypeOnChange(type) {
        Action.changeGraphType(type);
    }

    render() {
        let options = graphDataStore.getGraphTypeList().map((item) => {
            if (item == this.state.grpahTypeSelected) {
                return (
                    <option selected value={item} className='ewdashboard-summary-graph-type-dropdown-option'>{item}</option>
                );
            }
            return (
                <option value={item} className='ewdashboard-summary-graph-type-dropdown-option'>{item}</option>
            );
        });
        return (
            <div className='ewdashboard-summary-graph-type-dropdown-div'>
                <select className='ewdashboard-summary-graph-type-dropdown-select' onChange={(e) => { this.handleGraphTypeOnChange(e.target.value) }}>
                    {options}
                </select>
            </div>
        );
    }

    componentDidMount() {
        graphDataStore.on("GraphTypeSelectedChanged", () => {
            this.setState({
                grpahTypeSelected: graphDataStore.getGraphTypeSelected()
            });
        });
    }
    componentWillUnmount() {
        graphDataStore.removeListener("GraphTypeSelectedChanged", () => {
        });
    }

}