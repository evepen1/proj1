import React from 'react'
import __ from 'lodash';
import GenericChart from './GenericChart'
import highcharts3d from 'highcharts/highcharts-3d'
import Treemap from 'highcharts/modules/treemap.src'
import Highcharts from 'highcharts'

export default class GraphGenerate extends React.Component {

  constructor(props) {
    super(props);
    this.orderLookup = {
      'TRADE CAPTURE': 0, 'CONFIRMATION': 1, 'PRICING': 2,
      'ACCOUNTING': 3, 'SETTLEMENT': 4, 'DATA DELIVERY': 5
    };
  }


  createLargeTree() {
    var points = [];
    var count = 1;
    var data, tempData;
    var critical, medium, high, low;

    for (data in this.props.chartData) {
      data = this.props.chartData[data];
      // console.log('DATA');
      // console.log(data);
      count = count + 1;
      tempData = {
        id: data.name,
        name: data.name,
        color: Highcharts.getOptions().colors[count]
      };
      points.push(tempData);
      critical = data.criticality.critical;
      tempData = {
        id: 'CRITICAL',
        name: 'Critical',
        parent: data.name,
        value: data.criticality.critical.value
      };
      points.push(tempData);
      medium = data.criticality.medium;
      tempData = {
        id: 'MEDIUM',
        name: 'Medium',
        parent: data.name,
        value: data.criticality.medium.value
      };
      points.push(tempData);
      high = data.criticality.high;
      tempData = {
        id: 'HIGH',
        name: 'High',
        parent: data.name,
        value: data.criticality.high.value
      };
      points.push(tempData);
      low = data.criticality.low;
      tempData = {
        id: 'LOW',
        name: 'Low',
        parent: data.name,
        value: data.criticality.low.value
      };
      points.push(tempData);
    }

    var treeOpt = {
      chart: {
        backgroundColor: 'transparent',
        style: {
          fontFamily: '\'Unica One\', sans-serif'
        },
        plotBorderColor: '#FFF'
      },
      xAxis: {
        gridLineColor: '#707073',
        labels: {
          style: {
            color: '#E0E0E3',
            fontSize: '1em'
          }
        },
        lineColor: '#707073',
        minorGridLineColor: '#505053',
        tickColor: '#707073',
        title: {
          style: {
            color: '#A0A0A3'

          }
        }
      },
      yAxis: {
        gridLineColor: '#707073',
        labels: {
          style: {
            color: '#E0E0E3',
            fontSize: '1em'
          }
        },
        lineColor: '#707073',
        minorGridLineColor: '#505053',
        tickColor: '#707073',
        tickWidth: 1,
        title: {
          style: {
            color: '#A0A0A3'
          }
        }
      },
      series: [{
        type: 'treemap',
        layoutAlgorithm: 'squarified',
        allowDrillToNode: true,
        animationLimit: 1000,
        dataLabels: {
          enabled: false
        },
        levelIsConstant: false,
        levels: [{
          level: 1,
          dataLabels: {
            enabled: true,
            style: {
              fontSize: '1.5em'
            }
          },
          borderWidth: 2,
          borderColor: '#FFF'
        }],
        data: points
      }],
      subtitle: {
        text: null
      },
      title: {
        text: null
      }
    };
    // console.log('POINTS');
    // console.log(points);
    return treeOpt;
  }

  createStackedOption() {
    var stackOpt = {
      chart: {
        type: 'bar',
        backgroundColor: 'transparent',
        borderColor: '#999',
        borderWidth: 0,
        style: {
          fontFamily: '\'Unica One\', sans-serif'
        },
        plotBorderColor: null
      },
      title: {
        text: null,
        style: {
          color: '#A0A0A3'
        }
      },
      xAxis: {
        gridLineColor: '#707073',
        labels: {
          style: {
            color: '#EFFFF3',
            fontSize: '1.1em'
          }
        },
        lineColor: '#EFFFF3',
        minorGridLineColor: '#EFFFF3',
        tickColor: '#707073',
        title: {
          style: {
            color: '#A0A0A3',
          }
        },
        categories: ['Trade Capture', 'Confirmation', 'Pricing', 'Accounting', 'Settlement', 'Data Delivery']
      },
      yAxis: {
        gridLineColor: '#EFFFF3',
        labels: {
          style: {
            color: '#EFFFF3'
          }
        },
        lineColor: '#EFFFF3',
        minorGridLineColor: '#EFFFF3',
        tickColor: '#EFFFF3',
        tickWidth: 1,
        min: 0,
        title: {
          text: null,
          style: {
            color: '#A0A0A3'
          }
        },
        stackLabels: {
          enabled: true,
          style: {
            fontWeight: 'bold',
            color: 'white',
            border: null,
            fontSize: '1.1em'
          }
        }
      },
      tooltip: {
        headerFormat: '<b>{point.x}</b><br/>',
        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}',
        backgroundColor: 'rgba(240,240,240, 0.9)',
        style: {
          fontSize: '1.1em'
        }
      },
      legend: {
        reversed: true,
        itemStyle: {
          color: '#EFFFF3',
          fontSize: '1.1em'
        },
        itemHoverStyle: {
          color: '#FFF'
        },
        itemHiddenStyle: {
          color: '#222'
        }
      },
      plotOptions: {
        series: {
          stacking: 'normal',
          dataLabels: {
            enabled: true,
            color: 'white',
            border: null,
            fontSize: '1em'
          }
        }
      },
      series: [{
        name: 'low',
        data: [5, 3, 1, 2, 4, 1],
        color: '#008BE6'
      }, {
        name: 'medium',
        data: [2, 2, 3, 5, 1, 3],
        color: '#FFC000'
      }, {
        name: 'high',
        data: [2, 4, 1, 3, 1, 5],
        color: '#FF8029'
      }, {
        name: 'critical',
        data: [2, 1, 5, 3, 3, 1],
        color: '#FE0000'
      }
      ]
    };
    if (this.props.selectedGraph == 'Client Volume Status') {
      __.map(this.props.chartData, (itemCD) => {
        __.map(stackOpt.series, (itemSeries) => {
          itemSeries.data[this.orderLookup[itemCD.name]] = itemCD.criticality[itemSeries.name].value;
        });
      });
    }
    // console.log(stackOpt.series);
    return stackOpt;
  }

  createStackedColumnOption() {
    var stackedColOpt = {
      chart: {
        type: 'column',
        backgroundColor: 'transparent',
        borderColor: '#999',
        borderWidth: 0,
        style: {
          fontFamily: '\'Unica One\', sans-serif'
        },
        plotBorderColor: null
      },
      title: {
        text: null
      },
      xAxis: {
        gridLineColor: '#EFFFF3',
        labels: {
          style: {
            color: 'white',
            fontSize: '1.1em'
          }
        },
        lineColor: '#EFFFF3',
        minorGridLineColor: '#EFFFF3',
        tickColor: '#EFFFF3',
        categories: ['Trade Capture', 'Confirmation', 'Pricing', 'Accounting', 'Settlement', 'Data Delivery']
      },
      yAxis: {
        min: 0,
        title: {
          text: null
        },
        labels: {
          style: {
            fontWeight: 'bold',
            color: 'white',
            border: null,
            fontSize: '1.1em'
          }
        },
        stackLabels: {
          enabled: true,
          style: {
            fontWeight: 'bold',
            color: 'white',
            border: null,
            fontSize: '1.1em'
          }
        }
      },
      legend: {
        align: 'right',
        x: -30,
        verticalAlign: 'top',
        y: 25,
        floating: true,
        backgroundColor: 'rgba(240,240,240, 0.9)',
        borderColor: '#CCC',
        borderWidth: 0,
        shadow: false,
        reversed: false
      },
      tooltip: {
        headerFormat: '<b>{point.x}</b><br/>',
        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}',
        backgroundColor: 'rgba(240,240,240, 0.9)',
        style: {
          fontSize: '1.1em'
        }
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          dataLabels: {
            enabled: true,
            color: 'white',
            border: null,
            fontSize: '1em'
          }
        }
      },
      series: [{
        name: 'critical',
        data: [2, 1, 5, 3, 3, 1],
        color: '#FE0000'
      }, {
        name: 'high',
        data: [2, 4, 1, 3, 1, 5],
        color: '#FF8029'
      }, {
        name: 'medium',
        data: [2, 2, 3, 5, 1, 3],
        color: '#FFC000'
      }, {
        name: 'low',
        data: [5, 3, 1, 2, 4, 1],
        color: '#008BE6'
      }
      ]
    };
    if (this.props.selectedGraph == 'Client Volume Status') {
      __.map(this.props.chartData, (itemCD) => {
        __.map(stackedColOpt.series, (itemSeries) => {
          itemSeries.data[this.orderLookup[itemCD.name]] =
            itemCD.criticality[itemSeries.name].value;
        });
      });
    }
    // console.log(stackedColOpt.series);
    return stackedColOpt;
  }

  createPieOption() {
    var opt = {
      chart: {
        type: 'pie',
        options3d: {
          enabled: true,
          alpha: 35,
          depth: 20
        },
        backgroundColor: 'transparent',
        borderColor: '#999',
        borderWidth: 0,
        style: {
          fontFamily: '\'Unica One\', sans-serif'
        }
      },
      title: {
        text: null
      },
      tooltip: {
        pointFormat: '<b>{point.y:.0f}</b>',
        backgroundColor: 'rgba(240,240,240, 0.9)',
        style: {
          fontSize: '1.1em'
        }
      },
      legend: {
        align: 'right',
        verticalAlign: 'center',
        layout: 'vertical',
        backgroundColor: 'transparent',
        labelFormat: '{name} - {y}',
        symbolHeight: 12,
        symbolWidth: 12,
        symbolRadius: 0,
        itemStyle: {
          color: '#fff',
          fontWeight: 'bold',
          fontSize: '1.2em'
        }
      },
      plotOptions: {
        series: {
          animation: false
        },
        pie: {
          cursor: 'pointer',
          depth: 35,
          innerSize: 40,
          borderWidth: 0,
          dataLabels: {
            enabled: false,
            format: '{point.name}'
          }
        }
      },
      series: [{
        name: 'Exception Sum',
        showInLegend: true,
      }],
      drilldown: {
        series: []
      }
    };
    // console.log('CREATE PIE DATA');
    var tepmData = [];
    var tempDrilldown;
    __.map(this.props.chartData, (item) => {
      var newRec = {};
      newRec.name = item.name;
      newRec.y = item.value;
      newRec.drilldown = item.name;
      tepmData.push(newRec);
      // tempDrilldown={
      //   name: item.name,
      //   id: item.name,
      //   data: [
      //     ['Critical', item.criticality.critical],
      //     ['Medium', item.criticality.medium],
      //     ['High', item.criticality.high],
      //     ['Low', item.criticality.low]
      //   ]
      // };
      // opt.drilldown.series.push(tempDrilldown);
    });
    opt.series[0].data = tepmData;
    // console.log('CREATE PIE DATA END ');
    // console.log(opt);
    // console.log(JSON.stringify(opt))
    return opt;
  }

  createData() {
    //  console.log('CREATE DATA ');
    var sdv = this.props.selectedGraphType;
    //  console.log(sdv);
    //if (sdv == 'Pie Chart') {
    return this.createPieOption();
    //}
    // else if (sdv == 'Stacked Bar Chart') {
    //   return this.createStackedOption();
    // }
    // else if (sdv == 'Tree Map Chart') {
    //   return this.createLargeTree();
    // }
    // else if (sdv == 'Stacked Column Chart') {
    //   return this.createStackedColumnOption();
    // }
  }


  shouldComponentUpdate(nextProps, nextState) {
    if (this.props.chartData === nextProps.chartData &&
      this.props.selectedGraphType === nextProps.selectedGraphType &&
      this.props.selectedGraph === nextProps.selectedGraph)
    { return false; }
    return true;
  }

  render() {
    if (!this.props.display) {
      return (<div className='graph-area-div-loading'></div>);
    }
    return (
      <GenericChart container={this.props.container} options={this.createData()} modules={[highcharts3d, Treemap]} />
    );
  }

}
