import React, { Component } from 'react';
import { hashHistory } from 'react-router';
import CriticalityBox from './CriticalityBox';
import CategoryList from './CategoryList';
import exceptionSummaryDataStore from '../../../store/exceptionSummaryDataStore';
import activeExceptionCategoryListStore from '../../../store/actveExceptionCategoryStore';
import * as Action from '../../../action/Actions';

export default class SummaryDetail extends Component {

    render() {

        return (
            <div className='etf-summary-left-div'>
                <div className='navupstream-summary-left-table-container-div'>
                    <table className='navupstream-summary-left-table'>
                        <tbody>
                            <tr>
                                <td></td>
                                <td>Order Activity</td>
                                <td>Custody Trade Processing</td>
                                <td>Corporate Action</td>
                                <td>FxRate</td>
                                <td>Pricing</td>
                                <td>Order Rebalance</td>
                                <td>Auto Trigger</td>
                                <td>Trigger Accounting</td>
                            </tr>
                            <tr>
                                <td>ETF 1</td>
                                <td className='navupstream-summary-left-td-no'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td>
                                    <input type='checkbox' checked />
                                </td>
                                <td>
                                    <input type='button' disabled value='Submit' className='navupstream-summary-left-submit-disable' />
                                </td>
                            </tr>
                            <tr>
                                <td>ETF 2</td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-no'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td>
                                    <input type='checkbox' />
                                </td>
                                <td>
                                    <input type='button' disabled value='Submit' className='navupstream-summary-left-submit-disable' />
                                </td>
                            </tr>
                            {/*<tr>
                                <td>ETF 3</td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-no'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td>
                                    <input type='checkbox' />
                                </td>                                <td>
                                    <input type='button' disabled value='Submit' className='navupstream-summary-left-submit-disable' />
                                </td>
                            </tr>*/}
                            <tr>
                                <td>ETF 3</td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td>
                                    <input type='checkbox' />
                                </td>                                <td>
                                    <input type='button' value='Submit' className='navupstream-summary-left-submit-enable' />
                                </td>
                            </tr>
                            <tr>
                                <td>ETF 4</td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td className='navupstream-summary-left-td-yes'></td>
                                <td>
                                    <input type='checkbox' checked />
                                </td>
                                <td>
                                    <input type='button' value='Submited' className='navupstream-summary-left-submited' />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }

    componentDidMount() {

    }

    componentWillUnmount() {

    }

}