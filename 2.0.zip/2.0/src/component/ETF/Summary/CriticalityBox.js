import React, { Component } from 'react';
import * as Action from '../../../action/Actions';
import exceptionTableDataStore from '../../../store/exceptionTableDataStore';

export default class CriticalityBox extends Component {

    handleCriticalityBoxClick(name) {
        exceptionTableDataStore.clearData();
        Action.changeActiveCriticality(name);
    }
    render() {

        return (
            <div className='ewdashboard-summary-detail-criticality-box' onClick={(e) => { this.handleCriticalityBoxClick(this.props.name) }}>
                <div style={this.props.style} className='ewdashboard-summary-detail-criticality-box-detail'>
                    <div className='ewdashboard-summary-detail-criticality-box-detail-name'>
                        {this.props.name}
                    </div>
                    <div className='ewdashboard-summary-detail-criticality-box-detail-count'>
                        {this.props.countValue}
                    </div>
                </div>
                <div className='ewdashboard-summary-detail-criticality-box-arrow'>
                    <div style={this.props.arrowStyle} className={this.props.arrowCssClassName}></div>
                </div>
            </div>
        );
    }
}