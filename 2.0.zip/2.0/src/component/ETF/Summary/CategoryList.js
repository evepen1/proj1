import React, { Component } from 'react';
import exceptionSummaryDataStore from '../../../store/exceptionSummaryDataStore';
import ExceptionTableDataStore from '../../../store/exceptionTableDataStore';
import CategoryListPopUp from './CategoryListPopUp';
import * as Action from '../../../action/Actions';

export default class CategoryList extends Component {

  constructor(props) {
    super(props);
    this.state = {
      activeListPopUpIndex: exceptionSummaryDataStore.getActiveListPopUpIndex(),
    };
    this.popup = { xposition: 0, yposition: 0 };
    this.clicked = false;
    this.activeCategoryIndex = this.props.initialIndex;
  }

  handleCategoryListPopUpClick(e, index) {
    if (this.clicked) {
      Action.changeActiveListPopUpIndex(index);
      if (this.state.activeListPopUpIndex === index) {
        this.clicked = false;
      }
    }
    else {
      this.clicked = true;
    }
  }

  handleCategoryListPopUpMouseEnter(e, index) {
    this.popup.xposition = e.target.getBoundingClientRect().right - 15;
    this.popup.yposition = e.target.getBoundingClientRect().bottom - 15;
    if (!this.clicked) {
      Action.changeActiveListPopUpIndex(index);
    }
  }

  handleCategoryListPopUpMouseLeave(e, index) {
    this.popup.xposition = e.target.getBoundingClientRect().right - 15;
    this.popup.yposition = e.target.getBoundingClientRect().bottom - 15;
    if (!this.clicked) {
      Action.changeActiveListPopUpIndex(-1);
    }
  }
  handleCategoryListDataTableClick(e, index, category) {
    if (this.state.activeCategoryIndex === index) {
      this.setState({ activeCategoryIndex: -1 });
      Action.changeActiveCategoryExceptionTable(null);
    } else {
      this.setState({ activeCategoryIndex: index });
      Action.changeActiveCategoryExceptionTable(category);
    }
  }
  render() {
    let popupStyle = {
      'position': 'absolute',
      'top': this.popup.yposition,
      'left': this.popup.xposition
    };
    var records = this.props.activeSummaryException.map((item, index) => {
      let displayCssClass = 'display-none';
      let tdCssClass = 'ewdashboard-summary-detail-category-list-tbody-td-status-' + this.props.value;
      if (this.state.activeListPopUpIndex == index) {
        tdCssClass = tdCssClass + '-clicked';
        displayCssClass = 'display-block';
      }

      let tdActiveCategoryCssClass = 'ewdashboard-summary-detail-category-list-tbody-td-label';
      if (this.state.activeCategoryIndex === index) {
        tdActiveCategoryCssClass = 'ewdashboard-summary-detail-category-list-clicked';
      }

      return (
        <tr className='ewdashboard-summary-detail-category-list-tbody-tr'>
          <td className={tdActiveCategoryCssClass}
            onClick={(e) => { this.handleCategoryListDataTableClick(e, index, item.name) }}>{item.name}</td>
          <td className={tdCssClass} onClick={(e) => { this.handleCategoryListPopUpClick(e, index) }}
            onMouseEnter={(e) => { this.handleCategoryListPopUpMouseEnter(e, index) }}
            onMouseLeave={(e) => { this.handleCategoryListPopUpMouseLeave(e, index) }}>
            <div className='ewdashboard-summary-detail-category-list-tbody-td-div'>
              {item.value}
              <div style={popupStyle} className={'ewdashboard-summary-detail-category-list-status-popup-div ' + displayCssClass}>
                <CategoryListPopUp status={item.status} name={item.name} />
              </div>
            </div>
            <div className='ewdashboard-summary-detail-category-list-tbody-td-right-arrow'></div>
          </td></tr>
      );
    });
    return (
      <table className='ewdashboard-summary-detail-category-list-table'>
        <tbody className='ewdashboard-summary-detail-category-list-tbody'>
          {records}
        </tbody>
      </table>
    );
  }

  componentDidMount() {
    exceptionSummaryDataStore.on("ResetIndexOfChossenExceptionCategory", () => {
      this.state.activeCategoryIndex = this.props.initialIndex;
    });
    exceptionSummaryDataStore.on("ActiveCategoryListPopUpIndexChanged", () => {
      this.setState({
        activeListPopUpIndex: exceptionSummaryDataStore.getActiveListPopUpIndex()
      });
    });
  }

  componentWillUnmount() {
    exceptionSummaryDataStore.removeListener("ActiveCategoryListPopUpIndexChanged", () => {
    });
    exceptionSummaryDataStore.removeListener("ResetIndexOfChossenExceptionCategory", () => {
    });
  }

}