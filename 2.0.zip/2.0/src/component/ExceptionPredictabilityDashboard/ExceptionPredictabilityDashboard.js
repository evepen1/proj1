import React, { Component } from 'react';
import GraphBlock from './GraphBlock/GraphBlock';
import userDetailDataStore from '../../store/userDetailDataStore';
import * as Action from '../../action/Actions';

export default class ExceptionPredictabilityDashboard extends Component {

    constructor() {
        super();
        this.state = {
            exceptionPredictionConf: userDetailDataStore.getExceptionPredictabilityConfUserDetail()
        };
    }

    handleAddGraphBlock() {
        Action.addExceptionPredictabilityUserConf();
    }

    render() {
        let graphBlockList = this.state.exceptionPredictionConf.map((item, index) => {
            return (
                <GraphBlock key={index + new Date().valueOf()} sequence={index}
                    addCssname={index + new Date().valueOf()}
                    typeSelected={item.typeSelected}
                    basisSelected={item.basisSelected}
                    checkedList={item.checkedList}
                    editEnabled={item.editEnabled}
                    typeOfGraph={item.typeOfGraph}
                />
            );
        });
        return (
            <div className='gfsmetricsdashboard-container'>
                {graphBlockList}
                <div className='gfsmetricsdashboard-graphblock-div gfsmetricsdashboard-graphblock-div-addnew' onClick={() => { this.handleAddGraphBlock() }}>

                </div>
            </div>
        );
    }

    componentDidMount() {
        userDetailDataStore.on("ExceptionPredictabilityUserConfUpdated", () => {
            this.setState({
                exceptionPredictionConf: userDetailDataStore.getExceptionPredictabilityConfUserDetail()
            });
        });
        userDetailDataStore.on("refreshAllDashboard", () => {
            this.setState({
                exceptionPredictionConf: userDetailDataStore.getExceptionPredictabilityConfUserDetail()
            });
        });
    }

    componentWillUnmount() {
        userDetailDataStore.removeListener("ExceptionPredictabilityUserConfUpdated", () => {
        });
        userDetailDataStore.removeListener("refreshAllDashboard", () => {
        });
    }
}