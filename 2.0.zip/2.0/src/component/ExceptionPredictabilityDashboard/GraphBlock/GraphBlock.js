import React, { Component } from 'react';
import GfsGraphContainer from './GfsGraphContainer';
import GfsGraphOption from './GfsGraphOption';
import exceptionPredictabilityDataStore from '../../../store/exceptionPredictabilityDataStore';
import * as Action from '../../../action/Actions';

export default class GraphBlock extends Component {

    constructor(props) {
        super(props);
        this.state = {
            exceptionPredictabilityData: exceptionPredictabilityDataStore.getExceptionPredictabilityData(),
            typeSelected: this.props.typeSelected,
            basisSelected: this.props.basisSelected,
            checkedList: this.props.checkedList,
            editEnabled: this.props.editEnabled,
            typeOfGraph: this.props.typeOfGraph
        };
    }

    changeTypeSelected(newTypeSelected) {
        Action.changeExceptionPredictabilityUserConfig('typeSelected', newTypeSelected, this.props.sequence, this.props.dynamicDashName);
    }

    changeBasisSelected(newBasisSelected) {
        Action.changeExceptionPredictabilityUserConfig('basisSelected', newBasisSelected, this.props.sequence, this.props.dynamicDashName);
    }

    toggleEditEnabled() {
        Action.changeExceptionPredictabilityUserConfig('editEnabled', !this.state.editEnabled, this.props.sequence, this.props.dynamicDashName);
    }

    changeTypeOfGraph(newGraphType) {
        Action.changeExceptionPredictabilityUserConfig('typeOfGraph', newGraphType, this.props.sequence, this.props.dynamicDashName);
    }

    updateCheckList(newValue) {
        if (this.state.checkedList.indexOf(newValue) > -1) {
            this.state.checkedList.splice(this.state.checkedList.indexOf(newValue), 1);
        }
        else {
            this.state.checkedList.push(newValue);
        }
        Action.changeExceptionPredictabilityUserConfig('checkedList', this.state.checkedList, this.props.sequence, this.props.dynamicDashName);
    }


    render() {
        return (
            <div className='gfsmetricsdashboard-graphblock-div'>
                <GfsGraphOption exceptionPredictabilityData={this.state.exceptionPredictabilityData}
                    typeSelected={this.state.typeSelected}
                    basisSelected={this.state.basisSelected}
                    changeTypeSelected={this.changeTypeSelected.bind(this)}
                    changeBasisSelected={this.changeBasisSelected.bind(this)}
                    updateCheckList={this.updateCheckList.bind(this)}
                    changeTypeOfGraph={this.changeTypeOfGraph.bind(this)}
                    checkedChecklist={this.state.checkedList}
                    editEnabled={this.state.editEnabled}
                    typeOfGraph={this.state.typeOfGraph}
                />
                <GfsGraphContainer container={'gfs-chart' + this.props.addCssname}
                    exceptionPredictabilityData={this.state.exceptionPredictabilityData}
                    typeSelected={this.state.typeSelected}
                    basisSelected={this.state.basisSelected}
                    checkedChecklist={this.state.checkedList}
                    sequence={this.props.sequence}
                    dynamicDashName={this.props.dynamicDashName}
                    typeOfGraph={this.state.typeOfGraph}
                    editEnabled={this.state.editEnabled}
                    toggleEditEnabled={this.toggleEditEnabled.bind(this)}
                />
            </div>
        );
    }

}