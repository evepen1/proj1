var webpack = require('webpack');
module.exports = {
  entry: __dirname + '/src/main.js',
  output: {
    path: __dirname,
    filename: 'bundle.js'
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env': {
       'EXCEPTION_API_URL': JSON.stringify('http://sd-59c8-fab6'),
       'EXCEPTION_API_PORT': JSON.stringify('8001')
      //  'EXCEPTION_API_URL': JSON.stringify('http://GCOTDVMMW795456'),
      //  'EXCEPTION_API_PORT': JSON.stringify('8001')
      // 'EXCEPTION_API_URL': JSON.stringify('http://GCOTVMSW784259'),
      //  'EXCEPTION_API_PORT': JSON.stringify('8001')
      }
    })
  ],
  devServer: {
    inline: true,
    port: 8002
  },
  node: {
    fs: "empty"
  },
  module: {
    loaders: [{
      test: /\.js$/,
      exclude: /node_modules/,
      loader: 'babel-loader',
      query: {
        presets: ['es2015', 'react']
      }
    }
    ]
  }
}
