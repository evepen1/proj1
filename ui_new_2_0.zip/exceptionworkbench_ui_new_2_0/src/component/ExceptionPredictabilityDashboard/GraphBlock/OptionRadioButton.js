import React, { Component } from 'react';

export default class OptionRadioButton extends Component {

    handleRadioOnchange() {
        this.props.chnage
    }

    render() {
        let radioButtons = Object.keys(this.props.parentObj).map((item) => {
            if (item.toLowerCase() === this.props.selectedvalue.toLowerCase()) {
                return (
                    <label className='gfsmetricsdashboard-graphblock-option-radiobutton-label'>
                        <input type="radio"
                            value={item.toLowerCase()}
                            checked
                            onChange={(e) => { this.props.dropdownChange(e.target.value) }}
                        />
                        {item.toCapitalise()}
                    </label>
                );
            }
            else {
                return (
                    <label className='gfsmetricsdashboard-graphblock-option-radiobutton-label'>
                        <input type="radio"
                            value={item.toLowerCase()}
                            onChange={(e) => { this.props.dropdownChange(e.target.value) }}
                        />
                        {item.toCapitalise()}
                    </label>
                );
            }
        });
        return (
            <div className='gfsmetricsdashboard-graphblock-option-radiobutton-div'>
                {radioButtons}
            </div>
        );
    }
}