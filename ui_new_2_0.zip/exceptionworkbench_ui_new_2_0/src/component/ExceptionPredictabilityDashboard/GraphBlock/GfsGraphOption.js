import React, { Component } from 'react';
import OptionDropdown from './OptionDropdown';
import gfsMetricsDataStore from '../../../store/gfsMetricsDataStore';
import userDetailDataStore from '../../../store/userDetailDataStore';
import OptionChecklist from './OptionChecklist';
import OptionRadioButton from './OptionRadioButton';
import GraphTypeIcon from '../../Utilities/GraphTypeIcon';

export default class GfsGraphOption extends Component {

    constructor() {
        super();
    }

    handleChangeTypeSelected(newTypeSelected) {
        this.props.changeTypeSelected(newTypeSelected);
    }

    handleChangeBasisSelected(newBasisSelected) {
        this.props.changeBasisSelected(newBasisSelected);
    }

    render() {
        let checklist = [];
        let typeSelectedObject = {};
        let typesSelectedValue = this.props.typeSelected;
        if (this.props.typeSelected === null) {
            typeSelectedObject = this.props.exceptionPredictabilityData[Object.keys(this.props.exceptionPredictabilityData)[0]];
            typesSelectedValue = Object.keys(this.props.exceptionPredictabilityData)[0];
        }
        else {
            typeSelectedObject = this.props.exceptionPredictabilityData[this.props.typeSelected];
        }
        let basisSelectedObject = {};
        let nextOption = function () {
            let basisSelectedValue = this.props.basisSelected;
            if (this.props.basisSelected === null) {
                basisSelectedObject = typeSelectedObject[Object.keys(typeSelectedObject)[0]];
            }
            else {
                basisSelectedObject = typeSelectedObject[this.props.basisSelected];
            }
            if (basisSelectedValue.toLowerCase() == 'firm' || basisSelectedValue.toLowerCase() == 'client') {
                Object.keys(basisSelectedObject).forEach((firmName) => {
                    let clientList = userDetailDataStore.getWorkflowConf().clients.indexOf('ALL') > -1 ? userDetailDataStore.getClientList() : userDetailDataStore.getWorkflowConf().clients;
                    if (clientList.indexOf(firmName.toUpperCase()) > -1) {
                        checklist[firmName] = basisSelectedObject[firmName];
                    }
                });
            }
            else if (basisSelectedValue.toLowerCase() == 'exceptioncategory') {
                Object.keys(basisSelectedObject).forEach((ecName) => {
                    if (userDetailDataStore.getStagesMapped().indexOf(ecName.toUpperCase()) > -1) {
                        checklist[ecName] = basisSelectedObject[ecName];
                    }
                });
            }
            else {
                checklist = basisSelectedObject;
            }
            return (
                <OptionDropdown selectedvalue={basisSelectedValue} dropdownChange={(newBasisSelected) => { this.handleChangeBasisSelected(newBasisSelected) }} parentObj={typeSelectedObject} />
            );
        }.call(this);

        let style = {};
        if (!this.props.editEnabled) {
            style.width = '0%';
            style.display = 'none';
        }
        let typeOfGraphList = [
            <GraphTypeIcon active={this.props.typeOfGraph} onclickaction={this.props.changeTypeOfGraph} type='line' detail='Line' />,
            <GraphTypeIcon active={this.props.typeOfGraph} onclickaction={this.props.changeTypeOfGraph} type='bar' detail='Bar' />
        ];
        return (
            <div style={style} className='gfsmetricsdashboard-graphblock-option-div'>
                <OptionDropdown selectedvalue={typesSelectedValue} dropdownChange={(newTypeselected) => { this.handleChangeTypeSelected(newTypeselected) }} parentObj={this.props.exceptionPredictabilityData} />
                {nextOption}
                <OptionChecklist checkedChecklist={this.props.checkedChecklist} updateCheckList={this.props.updateCheckList} checklist={checklist} />
                <div style={{ margin: '2px 0px 0px 0px', height: '30%', overflow: 'auto' }}>
                    {typeOfGraphList}
                </div>
            </div>
        );
    }

}