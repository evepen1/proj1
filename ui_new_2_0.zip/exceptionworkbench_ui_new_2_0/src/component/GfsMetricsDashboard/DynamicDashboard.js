import React, { Component } from 'react';
import GraphBlock from './GraphBlock/GraphBlock';
import userDetailDataStore from '../../store/userDetailDataStore';
import * as Action from '../../action/Actions';

export default class DynamicDashboard extends Component {

    constructor(props) {
        super(props);
        this.state = {
            userTabConfig: userDetailDataStore.getUserTabConfig(this.props.name)
        };
    }

    handleAddGraphBlock(name) {
        Action.addDynamicDashBoardTab(name);
    }

    render() {
        cnsole.log(this.state.userTabConfig);
        let graphBlockList = this.state.userTabConfig.map((item, index) => {
            return (
                <GraphBlock key={index + new Date().valueOf()}
                    dynamicDashName={this.props.name} sequence={index}
                    addCssname={index + new Date().valueOf()}
                    typeSelected={item.typeSelected}
                    basisSelected={item.basisSelected}
                    criticalitySelected={item.criticalitySelected}
                    checkedList={item.checkedList}
                    durationSelected={item.durationSelected}
                    editEnabled={item.editEnabled}
                    typeOfGraph={item.typeOfGraph}
                />
            );
        });
        return (
            <div className='gfsmetricsdashboard-container'>
                {graphBlockList}
                <div className='gfsmetricsdashboard-graphblock-div gfsmetricsdashboard-graphblock-div-addnew' onClick={() => { this.handleAddGraphBlock(this.props.name) }}>

                </div>
            </div>
        );
    }

    componentDidMount() {
        userDetailDataStore.on("DynamicDashboardUserConfUpdated" + this.props.name, () => {
            this.setState({
                userTabConfig: userDetailDataStore.getUserTabConfig(this.props.name)
            });
        });
    }

    componentWillUnmount() {
        userDetailDataStore.removeListener("DynamicDashboardUserConfUpdated" + this.props.name, () => {
        });
    }
}