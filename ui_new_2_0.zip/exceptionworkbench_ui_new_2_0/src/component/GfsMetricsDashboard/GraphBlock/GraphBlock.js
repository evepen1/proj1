import React, { Component } from 'react';
import GfsGraphContainer from './GfsGraphContainer';
import GfsGraphOption from './GfsGraphOption';
import gfsMetricsDataStore from '../../../store/gfsMetricsDataStore';
import * as Action from '../../../action/Actions';

export default class GraphBlock extends Component {

    constructor(props) {
        super(props);
        this.state = {
            gfsMetricsData: gfsMetricsDataStore.getGfsMetricsData(),
            typeSelected: this.props.typeSelected,
            basisSelected: this.props.basisSelected,
            criticalitySelected: this.props.criticalitySelected,
            checkedList: this.props.checkedList,
            durationSelected: this.props.durationSelected,
            editEnabled: this.props.editEnabled,
            typeOfGraph: this.props.typeOfGraph
        };
    }

    changeTypeSelected(newTypeSelected) {
        Action.changeGfsMetricsUserConfig('typeSelected', newTypeSelected, this.props.sequence, this.props.dynamicDashName);
    }

    changeBasisSelected(newBasisSelected) {
        Action.changeGfsMetricsUserConfig('basisSelected', newBasisSelected, this.props.sequence, this.props.dynamicDashName);
    }

    changeCriticalitySelected(newCriticalitySelected) {
        Action.changeGfsMetricsUserConfig('criticalitySelected', newCriticalitySelected, this.props.sequence, this.props.dynamicDashName);
    }

    toggleEditEnabled() {
        Action.changeGfsMetricsUserConfig('editEnabled', !this.state.editEnabled, this.props.sequence, this.props.dynamicDashName);
    }

    updateCheckList(newValue) {
        if (this.state.checkedList.indexOf(newValue) > -1) {
            this.state.checkedList.splice(this.state.checkedList.indexOf(newValue), 1);
        }
        else {
            this.state.checkedList.push(newValue);
        }
        Action.changeGfsMetricsUserConfig('checkedList', this.state.checkedList, this.props.sequence, this.props.dynamicDashName);
    }

    // changeTypeSelected(newTypeSelected) {
    //     this.setState({
    //         typeSelected: newTypeSelected,
    //         basisSelected: null,
    //         checkedList: []
    //     });
    // }

    // changeBasisSelected(newBasisSelected) {
    //     this.setState({
    //         basisSelected: newBasisSelected,
    //         checkedList: []
    //     });
    // }

    // changeCriticalitySelected(newCriticalitySelected) {
    //     this.setState({
    //         criticalitySelected: newCriticalitySelected
    //     });
    // }

    // updateCheckList(newValue) {
    //     if (this.state.checkedList.indexOf(newValue) > -1) {
    //         this.state.checkedList.splice(this.state.checkedList.indexOf(newValue), 1);
    //     }
    //     else {
    //         this.state.checkedList.push(newValue);
    //     }
    //     this.setState();
    // }

    updateDuration(newDurationSelected) {
        if (this.state.durationSelected !== newDurationSelected) {
            this.setState({ durationSelected: newDurationSelected });
            Action.changeGfsMetricsUserConfig('durationSelected', newDurationSelected, this.props.sequence, this.props.dynamicDashName);
        }
    }

    changeTypeOfGraph(newGraphType) {
        Action.changeGfsMetricsUserConfig('typeOfGraph', newGraphType, this.props.sequence, this.props.dynamicDashName);
    }

    render() {
        return (
            <div className='gfsmetricsdashboard-graphblock-div'>
                <GfsGraphOption gfsMetricsData={this.state.gfsMetricsData} typeSelected={this.state.typeSelected} basisSelected={this.state.basisSelected}
                    criticalitySelected={this.state.criticalitySelected}
                    changeTypeSelected={this.changeTypeSelected.bind(this)}
                    changeBasisSelected={this.changeBasisSelected.bind(this)}
                    changeCriticalitySelected={this.changeCriticalitySelected.bind(this)}
                    updateCheckList={this.updateCheckList.bind(this)}
                    changeTypeOfGraph={this.changeTypeOfGraph.bind(this)}
                    checkedChecklist={this.state.checkedList}
                    editEnabled={this.state.editEnabled}
                    typeOfGraph={this.state.typeOfGraph}
                />
                <GfsGraphContainer durationSelected={this.state.durationSelected} container={'gfs-chart' + this.props.addCssname}
                    gfsMetricsData={this.state.gfsMetricsData}
                    typeSelected={this.state.typeSelected}
                    basisSelected={this.state.basisSelected}
                    criticalitySelected={this.state.criticalitySelected}
                    checkedChecklist={this.state.checkedList}
                    updateDuration={this.updateDuration.bind(this)}
                    sequence={this.props.sequence}
                    dynamicDashName={this.props.dynamicDashName}
                    editEnabled={this.state.editEnabled}
                    typeOfGraph={this.state.typeOfGraph}
                    toggleEditEnabled={this.toggleEditEnabled.bind(this)}
                />
            </div>
        );
    }

}