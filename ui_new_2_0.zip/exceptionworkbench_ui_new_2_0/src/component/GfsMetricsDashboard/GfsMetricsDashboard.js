import React, { Component } from 'react';
import GraphBlock from './GraphBlock/GraphBlock';
import userDetailDataStore from '../../store/userDetailDataStore';
import * as Action from '../../action/Actions';

export default class GfsMetricsDashboard extends Component {

    constructor() {
        super();
        this.state = {
            gfsMetricsUserConf: userDetailDataStore.getGfsMetricsConfUserDetail()
        };
    }

    handleAddGraphBlock() {
        Action.addGfsMetricsUserConf();
    }

    render() {
        let graphBlockList = this.state.gfsMetricsUserConf.map((item, index) => {
            return (
                <GraphBlock key={index + new Date().valueOf()} sequence={index} addCssname={index + new Date().valueOf()}
                    typeSelected={item.typeSelected}
                    basisSelected={item.basisSelected}
                    criticalitySelected={item.criticalitySelected}
                    checkedList={item.checkedList}
                    durationSelected={item.durationSelected}
                    editEnabled={item.editEnabled}
                    typeOfGraph={item.typeOfGraph}
                />
            );
        });
        return (
            <div className='gfsmetricsdashboard-container'>
                {graphBlockList}
                <div className='gfsmetricsdashboard-graphblock-div gfsmetricsdashboard-graphblock-div-addnew' onClick={() => { this.handleAddGraphBlock() }}>

                </div>
            </div>
        );
    }

    componentDidMount() {
        userDetailDataStore.on("GfsMetricsUserConfUpdated", () => {
            this.setState({
                gfsMetricsUserConf: userDetailDataStore.getGfsMetricsConfUserDetail()
            });
        });
        userDetailDataStore.on("refreshAllDashboard", () => {
            this.setState({
                gfsMetricsUserConf: userDetailDataStore.getGfsMetricsConfUserDetail()
            });
        });
    }

    componentWillUnmount() {
        userDetailDataStore.removeListener("GfsMetricsUserConfUpdated", () => {
        });
        userDetailDataStore.removeListener("refreshAllDashboard", () => {
        });
    }
}