import React, { Component } from 'react';
import * as Action from '../../action/Actions';
import FeedbackDetail from './FeedbackDetail';
import FeedbackCategory from './FeedbackCategory';
import FeedbackForm from './FeedbackForm';
import helpCenterDataStore from '../../store/helpCenterDataStore';

export default class Feedback extends Component {

    render() {
        return (
            <div>
                <div className='feedback-container-div-white-overlay'>
                    <div className='feedback-top-div-container'>
                        <div className='feedback-top-top-div'>
                            <div className='feedback-top-top-feedback-icon-div'></div>
                            <div className='feedback-top-top-feedback-text-div'><i>Feedback</i></div>
                            <div className='feedback-top-top-close-div' onClick={(e) => { this.props.closeFeedbackCenterPopup(); }}>X</div>
                            <div className='feedback-top-top-help-div' onClick={(e) => { this.props.openHelpPopup(); }}></div>
                        </div>
                    </div>
                    <div className='feedback-bottom-div-container'>
                        <FeedbackDetail />
                        <FeedbackCategory />
                        <FeedbackForm />
                    </div>
                </div>
                <div className='feedback-container-div-dark-overlay' onClick={(e) => { this.props.closeFeedbackCenterPopup(); }}>

                </div>
            </div>
        );
    }

}