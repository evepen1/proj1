import React, { Component } from 'react';
import * as Action from '../../action/Actions';

export default class FeedbackDetail extends Component {

    render() {
        return (
            <div className='feedback-bottom-div-detail-div'>
                <p className='feedback-bottom-div-detail-p'> Feedback will be submited to Exception workbench team.</p>
            </div>
        );
    }

}