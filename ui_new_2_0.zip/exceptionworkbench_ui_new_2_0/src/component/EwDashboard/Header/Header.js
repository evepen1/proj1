import React, { Component } from 'react';
import HeaderTab from './HeaderTab';
import activeExceptionCategoryListStore from '../../../store/actveExceptionCategoryStore';
import exceptionSummaryDataStore from '../../../store/exceptionSummaryDataStore';
import userDetailDataStore from '../../../store/userDetailDataStore';
import graphDataStore from '../../../store/graphDataStore';
import * as Action from '../../../action/Actions';

export default class HeaderBar extends Component {

    constructor() {
        super();
        this.state = {
            exceptionCountSummary: activeExceptionCategoryListStore.getExceptionCountSummary(),
            activeCategory: activeExceptionCategoryListStore.getActiveCategory(),
            lastUpdate: activeExceptionCategoryListStore.getLastUpdateTime(),
            clientFilterSelected: userDetailDataStore.getClientFilterActive(),
            slaFilterSelected: userDetailDataStore.getSLAFilterActive()
        };
    }

    handleClientFilterChange(e) {
        Action.changeClientFilter(e.target.value);
    }

    handleSLAtFilterChange(e) {
        Action.changeSLAFilter(e.target.value);
    }

    render() {
        let sizeOfHeaderLookup = activeExceptionCategoryListStore.getHeaderLookup().length;
        let headertab = activeExceptionCategoryListStore.getHeaderLookup().map((item, index) => {
            let cssClass = 'ewdashboard-header-' + item.cssTag;
            if (this.state.activeCategory === item.value) {
                cssClass = cssClass + ' ewdashboard-header-active';
            }
            if (sizeOfHeaderLookup === index + 1) {
                cssClass = cssClass + ' ewdashboard-header-lasttab';
            }
            let count = undefined;
            if (this.state.exceptionCountSummary[item.name.toUpperCase()] !== undefined) {
                count = this.state.exceptionCountSummary[item.name.toUpperCase()].count;
            }
            return (
                <HeaderTab key={item.value} count={count || ' 0 '} cssClass={cssClass} name={item.name} value={item.value} />
            );
        });
        let clientList = userDetailDataStore.getWorkflowConf().clients.indexOf('ALL') > -1 ? userDetailDataStore.getClientList() : userDetailDataStore.getWorkflowConf().clients;
        let options = clientList.map((clientName) => {
            if (this.state.clientFilterSelected === clientName) {
                return (
                    <option selected className='ewdashboard-header-container-option-dropdown' value={clientName}>{clientName}</option>
                );
            }
            else {
                return (<option className='ewdashboard-header-container-option-dropdown' value={clientName}>{clientName}</option>
                );
            }
        });
        let slaOptions = userDetailDataStore.getSLAList().map((slaName) => {
            if (this.state.slaFilterSelected === slaName) {
                return (
                    <option selected className='ewdashboard-header-container-option-dropdown' value={slaName}>{slaName}</option>
                );
            }
            else {
                return (<option className='ewdashboard-header-container-option-dropdown' value={slaName}>{slaName}</option>
                );
            }
        });

        return (
            <div className='ewdashboard-header-container'>
                <div className='ewdashboard-header-dropdown-div'>
                    <div className='ewdashboard-header-dropdown-content-div'>
                        Client
                    </div>
                    <select onChange={(e) => { this.handleClientFilterChange(e) }} className='ewdashboard-header-container-select-dropdown'>
                        <option className='ewdashboard-header-container-option-dropdown' value='All'>All</option>
                        {options}
                    </select>
                </div>

                <div className='ewdashboard-header-dropdown-sla-div'>
                    <div className='ewdashboard-header-dropdown-content-div'>
                        SLA
                    </div>
                    <select onChange={(e) => { this.handleSLAtFilterChange(e) }} className='ewdashboard-header-container-select-dropdown'>
                        <option className='ewdashboard-header-container-option-dropdown' value='All'>All</option>
                        {slaOptions}
                    </select>
                </div>

                <div className='ewdashboard-header-div'>
                    {headertab}
                </div>

                <div className='ewdashboard-header-div-lastupdate'>
                    <span className='ewdashboard-header-div-lastupdate-span'>
                        Last updated -
                        {this.state.lastUpdate.getHours() + ":" + this.state.lastUpdate.getMinutes() + ":" + this.state.lastUpdate.getSeconds()}
                    </span>

                </div>
            </div>
        );
    }

    componentDidMount() {
        activeExceptionCategoryListStore.on("ActiveCategoryChanged", () => {
            this.setState({
                activeCategory: activeExceptionCategoryListStore.getActiveCategory()
            });
            Action.refereshCriticalitySummaryData(activeExceptionCategoryListStore.getActiveCategory());
            Action.refreshExceptionTableData(activeExceptionCategoryListStore.getActiveCategory(), exceptionSummaryDataStore.getActiveCriticalityValue());
        });
        activeExceptionCategoryListStore.on("ExceptionCountSummaryRefreshed", () => {
            this.setState({
                exceptionCountSummary: activeExceptionCategoryListStore.getExceptionCountSummary(),
                lastUpdate: activeExceptionCategoryListStore.getLastUpdateTime()
            });
        });
        userDetailDataStore.on("ClientFilterChnaged", () => {
            this.setState({
                clientFilterSelected: userDetailDataStore.getClientFilterActive()
            });
            Action.refereshCriticalitySummaryData(activeExceptionCategoryListStore.getActiveCategory());
            Action.refreshChartData(graphDataStore.getGraphNameSelected());
            Action.refreshExceptionTableData(activeExceptionCategoryListStore.getActiveCategory(), exceptionSummaryDataStore.getActiveCriticalityValue());
            Action.refreshExceptionCountSummaryData(exceptionSummaryDataStore.getActiveCriticality());
        });
        userDetailDataStore.on("SLAFilterChnaged", () => {
            this.setState({
                slaFilterSelected: userDetailDataStore.getSLAFilterActive()
            });
            Action.refereshCriticalitySummaryData(activeExceptionCategoryListStore.getActiveCategory());
            Action.refreshChartData(graphDataStore.getGraphNameSelected());
            Action.refreshExceptionTableData(activeExceptionCategoryListStore.getActiveCategory(), exceptionSummaryDataStore.getActiveCriticalityValue());
            Action.refreshExceptionCountSummaryData(exceptionSummaryDataStore.getActiveCriticality());
        });
        Action.refreshExceptionCountSummaryData(exceptionSummaryDataStore.getActiveCriticality());
    }

    componentWillUnmount() {
        activeExceptionCategoryListStore.removeListener("ActiveCategoryChanged", () => {
        });
        activeExceptionCategoryListStore.removeListener("ExceptionCountSummaryRefreshed", () => {
        });
        userDetailDataStore.removeListener("ClientFilterChnaged", () => {
        });
        userDetailDataStore.removeListener("SLAFilterChnaged", () => {
        });
    }

}