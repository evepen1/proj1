import React, { Component } from 'react';
import HeaderBar from './Header/Header';
import Summary from './Summary/Summary';
import ExceptionTable from './ExceptionTable/ExceptionTable';
import * as Action from '../../action/Actions';
import activeExceptionCategoryListStore from '../../store/actveExceptionCategoryStore';
import exceptionSummaryDataStore from '../../store/exceptionSummaryDataStore';
import graphDataStore from '../../store/graphDataStore';

export default class EwDashboard extends Component {
    constructor() {
        super();
        this.state = {
            autoRefreshOn: true
        };
    }

    toggleAutoRefresh() {
        this.setState({
            autoRefreshOn: !this.state.autoRefreshOn
        });
    }

    initiateAutoRefresh() {
        if (this.autoRefresh == undefined) {
            this.autoRefresh = setInterval(function () {
                Action.refereshCriticalitySummaryData(activeExceptionCategoryListStore.getActiveCategory());
                Action.refreshChartData(graphDataStore.getGraphNameSelected());
                Action.refreshExceptionTableData(activeExceptionCategoryListStore.getActiveCategory(), exceptionSummaryDataStore.getActiveCriticalityValue());
                Action.refreshExceptionCountSummaryData(exceptionSummaryDataStore.getActiveCriticality());
            }, 10000);
        }
    }

    removeAutoRefresh() {
        clearInterval(this.autoRefresh);
        this.autoRefresh = undefined;
    }

    render() {
        if (this.state.autoRefreshOn) {
            this.initiateAutoRefresh();
        }
        else {
            this.removeAutoRefresh();
        }
        return (
            <div className='ewdashboard-container'>
                <HeaderBar />
                <Summary />
                <ExceptionTable autoRefreshOn={this.state.autoRefreshOn} toggleAutoRefresh={this.toggleAutoRefresh.bind(this)}  />
            </div>
        );
    }

    componentDidMount() {
    }

    componentWillUnmount() {
        this.removeAutoRefresh();
    }
}