import React from 'react'
import * as Action from "../../../action/Actions";
import PopupStore from "../../../store/PopupStore";
import exceptionTableDataStore from "../../../store/exceptionTableDataStore";
import CommentHistoryPopUp from "./CommentHistoryPopUp";
import SimilarExceptionsView from "./SimilarExceptionsView";

import FileUpload from "./FileUpload";
export default class DrillDownPopup extends React.Component {

    constructor() {
        super();
        this.data = {
            headerList: [
                { displayName: 'Exception Category', fieldName: 'exceptionCategory' },
                { displayName: 'Error Category', fieldName: 'errorCategory' },
                { displayName: 'Error Description', fieldName: 'errorDescription' },
                { displayName: 'Quantity', fieldName: 'quantity' },
                { displayName: 'Assignee', fieldName: 'assignee' },
                { displayName: 'Status', fieldName: 'status' },
                { displayName: 'Criticality', fieldName: 'criticality' },
                { displayName: 'Source', fieldName: 'source' }
            ]
        }
        this.state = {
            clickedRow: 0,
            clickedRowItem: {},
            selectedSecurityId: 'AxySID : GLB1.EB, Ticker : GLB1, Sector : (Consumer, Non-cyclical), Exchange : EB',
            collapseRemediation: true,
            collapseCommentary: true
        };
        this.clicked = false;
        this.securityIdOptions = ['AxySID : GLB1.EB, Ticker : GLB1, Sector : (Consumer, Non-cyclical), Exchange : EB',
            'AxySID : SMWC.P, Ticker : SMWC, Sector : (Consumer, Cyclical), Exchange : XLON',
            'AxySID : FN.MBS.827591, Ticker : FN, Sector : Financial, Exchange : OTCNY',
            'AxySID : FN.MBS.935340, Ticker : FN, Sector : Financial, Exchange : OTCUS'];
        this.missingValue = '';
    }

    handleOnClickClose(e) {
        exceptionTableDataStore.clearSelectedSimExList();
        this.props.handleonclose();
    }

    handleClickRow(e, index, item) {
        if (this.index != 0 && this.state.clickedRow == index) {
            this.setState({ clickedRow: 0, clickedRowItem: {} })
        } else if (index == 0) {
            this.setState({ clickedRow: 0, clickedRowItem: item })
        } else {
            this.setState({ clickedRow: index, clickedRowItem: item })
        }
        console.log(index);
    }

    handleImClick() {
        Action.handleDrillDownHeaderIconClick("chat");
    }

    handleHelpClick() {
        this.handleOnClickClose();
        Action.handleDrillDownHeaderIconClick("help");
    }

    handleRemediationArrowToggle() {
        if (this.state.collapseRemediation) {
            this.setState({ collapseRemediation: false });
        } else {
            this.setState({ collapseRemediation: true });
        }
    }

    handleCommentaryArrowToggle() {
        if (this.state.collapseCommentary) {
            this.setState({ collapseCommentary: false });
        } else {
            this.setState({ collapseCommentary: true });
        }
    }

    handleTradeFileClick() {
        if (this.props.item.filePath === undefined) {
            alert('No file found!');
        }
        else {
            Action.openFile(this.props.item.filePath);
        }
    }

    handleChangeValue(e) {
        this.missingValue = e.target.value;
    }

    handleMissingField() {
        let updatedList = [{exceptionId:this.props.item.exceptionId, allocationId: this.props.item.allocationId, firmCode: this.props.item.firmCode, errorDescription: this.props.item.errorDescription, transactionId: this.props.item.transactionId, batchId: this.props.item.batchId }]
        exceptionTableDataStore.getSimilarExceptionSelectedList().forEach((item) => {
            updatedList.push(item);
        });
        let data = { 'time': Date().toString(), 'field': 'CUSTODIAN_ACCOUNT', 'value': this.missingValue, "updatedList": updatedList };
        Action.updateMomtableField(data);
        confirm('Request Submitted Successfully');
    }

    showAlertMessage() {
        confirm('Request Submitted Successfully');
    }

    render() {

        let style = { display: 'block' };

        let toggleRemediationStyle = {
            arrowStyle: {},
            container: {}
        }

        let toggleCommentaryStyle = {
            arrowStyle: {},
            container: {}
        }

        if (this.state.collapseRemediation) {
            toggleRemediationStyle.arrowStyle.borderTop = '8px solid transparent';
            toggleRemediationStyle.arrowStyle.borderLeft = '13px solid #999';
            toggleRemediationStyle.container.display = 'none';
        }

        if (this.state.collapseCommentary) {
            toggleCommentaryStyle.arrowStyle.borderTop = '8px solid transparent';
            toggleCommentaryStyle.arrowStyle.borderLeft = '13px solid #999';
            toggleCommentaryStyle.container.display = 'none';
        }

        let header = this.data.headerList.map(item => {
            return (
                <th className="ewdashboard-exceptiontable-th-header">
                    {item.displayName}
                </th>
            );

        });


        let records = exceptionTableDataStore.getDetailedData(this.props.item.allocationId)
            .map((item, index) => {
                var tddCSS = 'ewdashboard-exceptiontable-tr-';
                if (index == 0) {
                    this.state.clickedRowItem = item;
                }
                if (index === this.state.clickedRow) {
                    tddCSS = tddCSS + 'clicked-';
                }
                let colList = this.data.headerList
                    .map(header => {
                        return (
                            <td className="ewdashboard-exceptiontable-td">
                                <div >{item[header.fieldName]}</div>
                            </td>
                        );
                    });
                return (
                    <tr
                        key={item._id + item.exceptionId + index}
                        className={tddCSS + index % 2}
                        onClick={(e) => { this.handleClickRow(e, index, item) }}
                    >
                        {colList}
                    </tr>
                );
            });

        let selectedRemediationSteps;
        let link;
        if (this.state.clickedRowItem.source === "MOM") {
            link = "http://ugfs.alps.nam.nsroot.net/MOM/CitiAI.MiddleOfficeMonitor.Client.application";
        } else if (this.state.clickedRowItem.source === "MOTO") {
            link = "http://sd-ddff-3d8c.nam.nsroot.net:3070/ngmuiapp2web/";
        }
        if (this.state.clickedRowItem.errorDescription === "Multiple securities found hence throwing exception") {
            let listRadio = this.securityIdOptions.map((item) => {
                if (item === this.state.selectedSecurityId) {
                    return (
                        <label className="ewdashboard-exceptiontable-detailed-remediation-label">
                            <input type="radio"
                                value={item}
                                checked
                                onChange={(e) => {
                                    this.setState({
                                        selectedSecurityId: e.target.value
                                    });
                                }}
                            />
                            {item}
                        </label>
                    );
                }
                else {
                    return (
                        <label className="ewdashboard-exceptiontable-detailed-remediation-label">
                            <input type="radio"
                                value={item}
                                onChange={(e) => {
                                    this.setState({
                                        selectedSecurityId: e.target.value
                                    });
                                }}
                            />
                            {item}
                        </label>
                    );
                }
            });
            selectedRemediationSteps = <div>
                <span>Please Choose one Security Identifier to Resolve the Exception: </span><br></br><br></br>
                {listRadio}

                <span style={{ color: '#f38e8e', fontSize: '1.1em' }}>** Similar exceptions are found on other trades as well. Please select the exceptions in the Related Exceptions section on which you would like to apply the same fix.!!</span>
                <br></br>
                <input style={{ backgroundColor: '#0080FF' }} type="button" className='ewdashboard-exceptiontable-drilldown-commentary-clear-button'
                    value='Submit' onClick={() => this.showAlertMessage()} />
            </div>;
        } else if (this.state.clickedRowItem.errorDescription.includes("Failure resolving Counter Party")) {
            selectedRemediationSteps = <div>
                <div style={{ fontSize: '1.2em' }}> Create New Broker : </div>
                <table className="ewdashboard-exceptiontable-popup-summary-table">
                    <tbody>
                        <tr>
                            <td>Code : </td>
                            <td>
                                <input type="text" />
                            </td>
                            <td>Name : </td>
                            <td>
                                <input type="text" />
                            </td>
                        </tr>
                        <tr>
                            <td>Type : </td>
                            <td>
                                <input type="text" />
                            </td>
                            <td>GFC ID : </td>
                            <td>
                                <input type="text" />
                            </td>
                        </tr>
                        <tr>
                            <td>Parent Counterparty : </td>
                            <td>
                                <input type="text" />
                            </td>
                            <td>NSCC : </td>
                            <td>
                                <input type="text" />
                            </td>
                        </tr>
                        {/*<tr>
                            <td>Status : </td>
                            <td>
                                <input type="text" />
                            </td>
                        </tr>*/}
                    </tbody>
                </table>
                <span style={{ color: '#f38e8e', fontSize: '1.1em' }}>** Similar exceptions are found on other trades as well. Please select the exceptions in the Related Exceptions section on which you would like to apply the same fix.!!</span>
                <br />
                <input style={{ backgroundColor: '#0080FF' }} type="button" className='ewdashboard-exceptiontable-drilldown-commentary-clear-button'
                    value='Submit' onClick={() => this.showAlertMessage()} />
            </div>;

        } else if (this.state.clickedRowItem.errorDescription.includes("Missing Executing Broker")) {
            selectedRemediationSteps = <div>
                <div style={{ fontSize: '1.2em' }}> Create New Broker : </div>
                <table className="ewdashboard-exceptiontable-popup-summary-table">
                    <tbody>
                        <tr>
                            <td>Code : </td>
                            <td>
                                <input type="text" />
                            </td>
                            <td>Name : </td>
                            <td>
                                <input type="text" />
                            </td>
                        </tr>
                        <tr>
                            <td>Type : </td>
                            <td>
                                <input type="text" />
                            </td>
                            <td>GFC ID : </td>
                            <td>
                                <input type="text" />
                            </td>
                        </tr>
                        <tr>
                            <td>Parent Counterparty : </td>
                            <td>
                                <input type="text" />
                            </td>
                            <td>NSCC : </td>
                            <td>
                                <input type="text" />
                            </td>
                        </tr>
                        {/*<tr>
                            <td>Status : </td>
                            <td>
                                <input type="text" />
                            </td>
                        </tr>*/}
                    </tbody>
                </table>
                <span style={{ color: '#f38e8e', fontSize: '0.9em' }}>** Based on previous similar exceptions,  trend indicate that if a Broker setup is missing in MOM application, it also needs to be setup in following applications.
 Please select the applications in which you would like to apply the fix. It will  prevent chain of exceptions.!!</span>
                <br />
                <div className="ewdashboard-exceptiontable-drilldown-remediation-checkbox-div">
                    <input className="ewdashboard-exceptiontable-checkbox" type="checkbox"> MOTO </input>
                    <input className="ewdashboard-exceptiontable-checkbox" type="checkbox"> Saturn(MF) </input>
                </div>
                <input style={{ backgroundColor: '#0080FF' }} type="button" className='ewdashboard-exceptiontable-drilldown-commentary-clear-button'
                    value='Submit' onClick={() => this.showAlertMessage()} />
            </div>;

        } else if (this.state.clickedRowItem.errorDescription === "Could not resolve custodian account") {
            let font = { fontSize: '1.2em' }
            selectedRemediationSteps = <div>
                <span style={font}>Provide valid value of the given field : </span><br></br><br></br>
                <div>
                    <label style={font}> Custodian Account : </label>
                    <input type='text' className='setting-text' onChange={(e) => this.handleChangeValue(e)} />
                </div>
                <br />
                <span style={{ color: '#f38e8e', fontSize: '1.1em' }}>** Similar exceptions are found on other trades as well. Please select the exceptions in the Related Exceptions section on which you would like to apply the same fix.!!</span>
                <br />
                <input style={{ backgroundColor: '#0080FF', fontSize: '1.2em' }} type="button" className='ewdashboard-exceptiontable-drilldown-commentary-clear-button'
                    value='Submit' onClick={() => this.handleMissingField()} />

            </div>;
        } else {
            selectedRemediationSteps = exceptionTableDataStore.getRemediationStepData(this.state.clickedRowItem.errorDescription).map(step => {
                return (<div>
                    <br></br>
                    {step}
                </div>

                )
            })
        }

        return (
            <div>
                <div style={style} className="ewdashboard-exceptiontable-drilldown-popup-div">
                    <div className='ewdashboard-exceptiontable-popup-close'>
                        <div className='navigationpanel-icon navigationpanel-icon-im' onClick={(e) => { this.handleImClick() }}></div>
                        <div className='navigationpanel-icon navigationpanel-icon-help' onClick={(e) => { this.handleHelpClick() }}></div>
                        <input className='ewdashboard-exceptiontable-popup-x-close'
                            type='button' value='X'
                            onClick={(e) => { this.handleOnClickClose(e) }} />
                    </div>
                    <div className='ewdashboard-exceptiontable-drilldown-popup-content-div'>
                        <div style={style} className='ewdashboard-exceptiontable-popup-summary-div'>
                            <table className="ewdashboard-exceptiontable-popup-summary-table">
                                <tbody>
                                    <tr>
                                        <th style={{ color: '#999' }} scope="row">Allocation Id : </th>
                                        <td>{this.props.item.allocationId}</td>
                                        <th style={{ color: '#999' }} scope="row">Firm Code : </th>
                                        <td>{this.props.item.firmCode}</td>
                                    </tr>
                                    <tr>
                                        <th style={{ color: '#999' }} scope="row">Block Id : </th>
                                        <td>{this.props.item.blockExternalReferenceId}</td>
                                        <th style={{ color: '#999' }} scope="row">Asset Class : </th>
                                        <td>{this.props.item.assetClass}</td>
                                    </tr>
                                    <tr>
                                        <th style={{ color: '#999' }} scope="row">Source : </th>
                                        <td>{this.props.item.source}</td>
                                        <th style={{ color: '#999' }} scope="row">Client Trade File : </th>
                                        <td className="ewdashboard-exceptiontable-td-linktf" onClick={(e) => { this.handleTradeFileClick() }}>Trade file</td>
                                    </tr>
                                    <tr>
                                        <th style={{ color: '#999' }} scope="row">File Type : </th>
                                        <td>{this.props.item.fileType}</td>
                                    </tr>
                                </tbody>
                            </table>
                            <FileUpload trade={this.props.item} />
                        </div>
                        <div style={style} className="ewdashboard-exceptiontable-popup-detailed-div">
                            <div className="ewdashboard-exceptiontable-detailed-header-div">
                                <span style={{ color: '#999' }}> Exception Details : </span>
                            </div>
                            <div className="ewdashboard-exceptiontable-detailed-table-div">
                                <table className="ewdashboard-exceptiontable-detailed-table">
                                    <thead className="ewdashboard-exceptiontable-table-thead">
                                        <tr
                                            key="header"
                                            className="ewdashboard-exceptiontable-tr-header"
                                        >
                                            {header}
                                        </tr>
                                    </thead>
                                    <tbody className="ewdashboard-exceptiontable-table-tbody">
                                        {records}
                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <div className="ewdashboard-exceptiontable-popup-remediation-div">
                            <div className="ewdashboard-exceptiontable-popup-component-header" onClick={() => this.handleRemediationArrowToggle()}>
                                <div style={toggleRemediationStyle.arrowStyle} className="ewdashboard-exceptiontable-popup-arrow-toggle"></div>
                                <span style={{ color: '#999' }}> Remediation Steps : </span>
                                <a href={link} target="_blank" className="ewdashboard-exceptiontable-td-link">{this.state.clickedRowItem.source}</a>
                            </div>
                            <div style={toggleRemediationStyle.container} className="ewdashboard-exceptiontable-popup-remediation-data">
                                {selectedRemediationSteps}
                            </div>
                        </div>
                        <SimilarExceptionsView item={this.state.clickedRowItem} />

                        <div className="ewdashboard-exceptiontable-popup-commentary-div">
                            <div className="ewdashboard-exceptiontable-popup-component-header" onClick={() => this.handleCommentaryArrowToggle()}>
                                <div style={toggleCommentaryStyle.arrowStyle} className="ewdashboard-exceptiontable-popup-arrow-toggle"></div>
                                <span style={{ color: '#999' }}> Commentary : </span>
                            </div>
                            <CommentHistoryPopUp item={this.state.clickedRowItem} style={toggleCommentaryStyle.container} />
                        </div>

                    </div>
                </div>
                <div style={style} className="ewdashboard-exceptiontable-black_overlay"></div>
            </div>
        );
    }

}