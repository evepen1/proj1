import React, {Component} from 'react';
import * as Action from "../../../action/Actions";

export default class FileUpload extends Component {

    constructor(props) {
        super(props);
    }

    handleUploadTradeFile() {
        if (this.uploadFile.files[0] === undefined) {
            alert('Please Choose Trade File');
        } else {
            let filePath = this.props.trade.filePath;
            let fileName = filePath.substring(filePath.lastIndexOf('/') + 1);
            let data = new FormData();
            data.append('file', this.uploadFile.files[0]);
            data.append('fileName', this.uploadFile.files[0].name);
            data.append('fileType', this.props.trade.fileType);
            data.append('firm', this.props.trade.firmCode);
            Action.uploadTradeFile(data);
        }
    }

    render() {
        return (
            <div className="ewdashboard-exceptiontable-file-upload-div">
                <span style={{
                    color: '#999'
                }}>
                    Upload Trade File : </span>
                <input
                    ref={(ref) => this.uploadFile = ref}
                    className="ewdashboard-exceptiontable-file-upload"
                    type="file"/>
                <input
                    className="ewdashboard-exceptiontable-file-run-button"
                    type="button"
                    value="Run"
                    onClick={(e) => {
                    this.handleUploadTradeFile()
                }}/>
            </div>
        );
    }

}