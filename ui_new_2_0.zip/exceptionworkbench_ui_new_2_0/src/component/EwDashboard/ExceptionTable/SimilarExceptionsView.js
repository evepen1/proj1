import React, { Component } from 'react';
import * as Action from '../../../action/Actions';
import exceptionTableDataStore from "../../../store/exceptionTableDataStore";
export default class SimilarExceptionsView extends Component {

    constructor() {
        super();
        this.state = {
            collapseExceptionDiv: true,
            similarExceptionSelectedList: exceptionTableDataStore.getSimilarExceptionSelectedList()
        }

        this.data = {
            headerList: [
                {
                    displayName: 'checkBox',
                    fieldName: 'checkBox'
                }, {
                    displayName: 'Allocation Id',
                    fieldName: 'allocationId'
                }, {
                    displayName: 'Firm Code',
                    fieldName: 'firmCode'
                }, {
                    displayName: 'Source',
                    fieldName: 'source'
                }, {
                    displayName: 'Severity',
                    fieldName: 'criticality'
                }, {
                    displayName: 'Asset Class',
                    fieldName: 'assetClass'
                }, {
                    displayName: 'Assignee',
                    fieldName: 'assignee'
                }, {
                    displayName: 'Status',
                    fieldName: 'status'
                }
            ]
        }
    }

    handleSimExCheckBoxChange(item) {
        Action.refreshSelectedSimilarExceptionList(
            {
                transactionId: item.transactionId,
                batchId: item.batchId,
                allocationId: item.allocationId,
                firmCode: item.firmCode,
                errorDescription: item.errorDescription,
                exceptionId: item.exceptionId
            }
        );
    }

    handleSimilarExArrowToggle() {
        if (this.state.collapseExceptionDiv) {
            this.setState({ collapseExceptionDiv: false });
        } else {
            this.setState({ collapseExceptionDiv: true });
        }
    }

    handleSelectCheckBox(simExcList) {
        if (simExcList.length == this.state.similarExceptionSelectedList.length && simExcList.length != 0) {
            Action.refreshSelectedSimilarExceptionListAll(null);
        }
        else {
            Action.refreshSelectedSimilarExceptionListAll(
                simExcList.map((item) => {
                    return {
                        transactionId: item.transactionId,
                        batchId: item.batchId,
                        allocationId: item.allocationId,
                        firmCode: item.firmCode,
                        errorDescription: item.errorDescription,
                        exceptionId: item.exceptionId
                    }
                })
            );
        }
    }

    render() {

        let toggleExceptionDivStyle = {
            arrowStyle: {},
            container: {}
        }

        if (this.state.collapseExceptionDiv) {
            toggleExceptionDivStyle.arrowStyle.borderTop = '8px solid transparent';
            toggleExceptionDivStyle.arrowStyle.borderLeft = '13px solid #999';
            toggleExceptionDivStyle.container.display = 'none';
        }

        let simExcList = exceptionTableDataStore
            .getSimilarExceptionTradeData(this.props.item);

        let header = this
            .data
            .headerList
            .map(item => {
                if (item.displayName == "checkBox") {
                    if (simExcList.length == this.state.similarExceptionSelectedList.length && simExcList.length != 0) {
                        return (
                            <th className="ewdashboard-exceptiontable-th-header">
                                <input
                                    className="ewdashboard-exceptiontable-checkbox"
                                    type="checkbox"
                                    checked
                                    onChange={(e) => {
                                        this.handleSelectCheckBox(simExcList);
                                    }} />
                            </th>
                        );
                    }
                    else {
                        return (
                            <th className="ewdashboard-exceptiontable-th-header">
                                <input
                                    className="ewdashboard-exceptiontable-checkbox"
                                    type="checkbox"
                                    onChange={(e) => {
                                        this.handleSelectCheckBox(simExcList);
                                    }} />
                            </th>
                        );
                    }
                } else {
                    return (
                        <th className="ewdashboard-exceptiontable-th-header">
                            {item.displayName}
                        </th>
                    );
                }

            });

        let records = simExcList
            .map((item, index) => {
                console.log(this.state.similarExceptionSelectedList);
                var tddCSS = 'ewdashboard-exceptiontable-tr-';
                let colList = this
                    .data
                    .headerList
                    .map(header => {
                        if (item[header.fieldName] == undefined && header.fieldName == "checkBox") {
                            if (this.state.similarExceptionSelectedList.find((simExList) => {
                                return item.transactionId == simExList.transactionId
                            }) != undefined) {
                                return (< td className="ewdashboard-exceptiontable-td" > <input
                                    className="ewdashboard-exceptiontable-checkbox"
                                    type="checkbox" onChange={(e) => { this.handleSimExCheckBoxChange(item) }}
                                    checked /> </td>)
                            }
                            else {
                                return (< td className="ewdashboard-exceptiontable-td" > <input
                                    className="ewdashboard-exceptiontable-checkbox"
                                    type="checkbox" onChange={(e) => { this.handleSimExCheckBoxChange(item) }}
                                /> </td>);
                            }
                        } else {
                            return (
                                <td className="ewdashboard-exceptiontable-td">
                                    <div >{item[header.fieldName]}</div > </td>);
                        }
                    });
                return (
                    <tr
                        key={item._id + item.exceptionId + index}
                        className={tddCSS + index % 2}
                    >
                        {colList}
                    </tr>
                );
            });

        return (
            <div className="ewdashboard-exceptiontable-drilldown-similar-exception-div">
                <div
                    className="ewdashboard-exceptiontable-popup-component-header"
                    onClick={() => this.handleSimilarExArrowToggle()}>
                    <div
                        style={toggleExceptionDivStyle.arrowStyle}
                        className="ewdashboard-exceptiontable-popup-arrow-toggle"></div>
                    <span style={{ color: '#999' }}>
                        Related Exceptions :
                    </span>
                </div>
                <div
                    style={toggleExceptionDivStyle.container}
                    className='ewdashboard-exceptiontable-drilldown-similar-exception-data'>
                    <div className="ewdashboard-exceptiontable-drilldown-similar-table-div">
                        <table className="ewdashboard-exceptiontable-detailed-table">
                            <thead className="ewdashboard-exceptiontable-table-thead">
                                <tr key="header" className="ewdashboard-exceptiontable-tr-header">
                                    {header}
                                </tr>
                            </thead>
                            <tbody className="ewdashboard-exceptiontable-table-tbody"></tbody>
                            {records}
                        </table>
                    </div>
                </div>
            </div>

        );
    }
    componentDidMount() {
        exceptionTableDataStore.on("SimilarExceptionSelectedListRefreshed", () => {
            this.setState({
                similarExceptionSelectedList: exceptionTableDataStore.getSimilarExceptionSelectedList()
            });
        });
    }

    componentWillUnmount() {
        exceptionTableDataStore.removeListener("SimilarExceptionSelectedListRefreshed", () => { });
    }
}