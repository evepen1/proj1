import React, { Component } from 'react';
import * as Action from '../../action/Actions';

export default class ChatPopup extends Component {

    constructor() {
        super();
        this.state = {
            maximize: false,
            minimize: false
        };
    }

    handleCloseOnClick() {
        this.state.maximize = false;
        this.state.minimize = false;
        this.props.closeChat();
    }

    handleMaxOnClick() {
        this.setState({
            maximize: !this.state.maximize,
            minimize: false
        });
    }

    handleMinOnClick() {
        this.setState({
            minimize: !this.state.minimize,
            maximuze: false
        });
    }

    render() {
        let appendDivClassName = '';
        let style = { display: 'block' };
        let allStyle = { display: 'none' };
        let maxStyle = {};
        let minStyle = {};
        if (this.props.chatShow) {
            allStyle.display = 'block';
        }
        if (this.state.maximize) {
            appendDivClassName = '_max';
            maxStyle = {
                backgroundColor: '#dd4d4d'
            };
        }
        if (this.state.minimize) {
            appendDivClassName = '_min';
            style.display = 'none';
            minStyle = {
                backgroundColor: '#dd4d4d'
            };
        }
        return (
            <div style={allStyle} className={'navigationpanel-chat-div' + appendDivClassName}>
                <div className={'navigationpanel-chat-option-div' + appendDivClassName}>
                       <div className='navigationpanel-chat-option-each-chartroom-div'>
                       Exception Workbench Chart Room 
</div>
                    <div className='navigationpanel-chat-option-each-div' onClick={() => { this.handleCloseOnClick(); }}>
                        X
</div>
                    <div style={minStyle} className='navigationpanel-chat-option-each-div' onClick={() => { this.handleMinOnClick(); }}>
                        -
</div>
                    <div style={maxStyle} className='navigationpanel-chat-option-each-div' onClick={() => { this.handleMaxOnClick(); }}>
                        Max
</div>
                </div>
                <div style={style} className='navigationpanel-chat-iframe-div'>
                    <iframe className='navigationpanel-chat-iframe' src="https://uat.citivelocity.com/cvsym/html/popout.html?roomid=DfAVdGDAhjbMLBymsJA6e3///qPekB+jdA=="></iframe>
                </div>
            </div>
        );
    }

}