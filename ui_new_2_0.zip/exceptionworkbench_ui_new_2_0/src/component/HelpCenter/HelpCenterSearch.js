import React, { Component } from 'react';

export default class HelpCenterSearch extends Component {

    render() {
        return (
            <div className='helpcenter-top-bottom-div'>
                <div className='helpcenter-top-bottom-content-div'>How can we help you today?</div>
                <div className='helpcenter-top-bottom-search-div'>
                    <input type='text' placeholder='Find Answers (type your keywors to find)' className='helpcenter-top-bottom-search-text-input' />
                    <input type='button' value='Search' className='helpcenter-top-bottom-search-button-input' />
                </div>
            </div>
        );
    }

}