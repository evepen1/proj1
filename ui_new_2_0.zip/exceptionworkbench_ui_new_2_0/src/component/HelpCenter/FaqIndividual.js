import React, { Component } from 'react';

export default class FaqIndividual extends Component {

    render() {
        return (<div>
            <div className='helpcenter-bottom-faq-conten-each'>
                Q. {this.props.eachFaqQA.question}
            </div>
            <div className='helpcenter-bottom-faq-conten-each'>
                A. {this.props.eachFaqQA.answer}
            </div>
        </div>
        );
    }

}