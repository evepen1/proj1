import React, { Component } from 'react';
import FaqIndividual from './FaqIndividual';
import helpCenterDataStore from '../../store/helpCenterDataStore';


export default class Faqs extends Component {


    render() {
        let listOfFaq = helpCenterDataStore.getFaq().map((item) => {
            return (
                <li className='helpcenter-bottom-faq-content-li'><FaqIndividual eachFaqQA={item} /></li>
            );
        });

        return (
            <div className='helpcenter-bottom-faq-div'>
                <div className='helpcenter-bottom-faq-content-title-div'>FAQ</div>
                <div className='helpcenter-bottom-faq-content-div'>
                    <ol type="i" className='helpcenter-bottom-faq-content-ol'>
                        {listOfFaq}
                    </ol>
                </div>
            </div>
        );
    }
}