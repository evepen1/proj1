import React, { Component } from 'react';

export default class Product extends Component {

    constructor(props) {
        super(props);
    }
    render() {
        let style={
            backgroundColor:this.props.bgcolor
        };
        return (
            <div style={style} className='helpcenter-product-container-inside'>
                <div className='helpcenter-product-title-div'>
                    {this.props.title}
                </div>
                <div className='helpcenter-product-content-div'>
                    <div className='helpcenter-product-content-detail-div'>
                        {this.props.detail}
                    </div>
                    <div className='helpcenter-product-content-number-div'>
                        {this.props.number}

                    </div>
                    <div className='helpcenter-product-content-mail-div'>
                        {this.props.mail}

                    </div>
                </div>
            </div>
        );
    }
}