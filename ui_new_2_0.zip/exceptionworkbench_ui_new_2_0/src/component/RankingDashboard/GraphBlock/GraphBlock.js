import React, { Component } from 'react';
import RankingGraphContainer from './RankingGraphContainer';
import RankingGraphOption from './RankingGraphOption';
import rankingMetricsDataStore from '../../../store/rankingMetricsDataStore';
import * as Action from '../../../action/Actions';

export default class GraphBlock extends Component {

    constructor(props) {
        super(props);
        this.state = {
            rankingMetricsData: rankingMetricsDataStore.getRankingMetricsData(),
            typeSelected: this.props.typeSelected,
            basisSelected: this.props.basisSelected,
            topNumberSelected: this.props.topNumberSelected,
            durationSelected: this.props.durationSelected,
            editEnabled: this.props.editEnabled,
            typeOfGraph: this.props.typeOfGraph
        };
    }

    changeTypeSelected(newTypeSelected) {
        // this.setState({
        //     typeSelected: newTypeSelected,
        // });
        Action.changeRankingDashboardUserConfig('typeSelected', newTypeSelected, this.props.sequence, this.props.dynamicDashName);
    }

    changeBasisSelected(newBasisSelected) {
        this.setState({
            basisSelected: newBasisSelected,
        });
        Action.changeRankingDashboardUserConfig('basisSelected', newBasisSelected, this.props.sequence, this.props.dynamicDashName);
    }

    changeTopNumberSelected(newTopNumberSelected) {
        // this.setState({
        //     topNumberSelected: newTopNumberSelected
        // });
        Action.changeRankingDashboardUserConfig('topNumberSelected', newTopNumberSelected, this.props.sequence, this.props.dynamicDashName);
    }

    toggleEditEnabled() {
        Action.changeRankingDashboardUserConfig('editEnabled', !this.state.editEnabled, this.props.sequence, this.props.dynamicDashName);
    }

    changeTypeOfGraph(newGraphType) {
        Action.changeRankingDashboardUserConfig('typeOfGraph', newGraphType, this.props.sequence, this.props.dynamicDashName);
    }

    updateDuration(newDurationSelected) {
        if (this.state.durationSelected !== newDurationSelected) {
            this.setState({ durationSelected: newDurationSelected });
        }
        Action.changeRankingDashboardUserConfig('durationSelected', newDurationSelected, this.props.sequence, this.props.dynamicDashName);
    }

    render() {
        return (
            <div className='gfsmetricsdashboard-graphblock-div'>
                <RankingGraphOption rankingMetricsData={this.state.rankingMetricsData} typeSelected={this.state.typeSelected} basisSelected={this.state.basisSelected}
                    topNumberSelected={this.state.topNumberSelected}
                    changeTypeSelected={this.changeTypeSelected.bind(this)}
                    changeBasisSelected={this.changeBasisSelected.bind(this)}
                    changeTopNumberSelected={this.changeTopNumberSelected.bind(this)}
                    changeTypeOfGraph={this.changeTypeOfGraph.bind(this)}
                    editEnabled={this.state.editEnabled}
                    typeOfGraph={this.state.typeOfGraph}
                />
                <RankingGraphContainer durationSelected={this.state.durationSelected} container={'gfs-chart' + this.props.addCssname}
                    rankingMetricsData={this.state.rankingMetricsData}
                    typeSelected={this.state.typeSelected}
                    basisSelected={this.state.basisSelected}
                    topNumberSelected={this.state.topNumberSelected}
                    updateDuration={this.updateDuration.bind(this)}
                    sequence={this.props.sequence}
                    editEnabled={this.state.editEnabled}
                    typeOfGraph={this.state.typeOfGraph}
                    dynamicDashName={this.props.dynamicDashName}
                    toggleEditEnabled={this.toggleEditEnabled.bind(this)}
                />
            </div>
        );
    }

}