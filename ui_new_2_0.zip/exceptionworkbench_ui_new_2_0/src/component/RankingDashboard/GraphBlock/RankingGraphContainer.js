import React, { Component } from 'react';
import GenericChart from './GenericChart'
import highcharts3d from 'highcharts/highcharts-3d'
import Treemap from 'highcharts/modules/treemap.src'
import Highcharts from 'highcharts'
import * as Action from '../../../action/Actions';
import userDetailDataStore from '../../../store/userDetailDataStore';

export default class GfsGraphContainer extends Component {
    constructor() {
        super();
        this.duration = {
            lookup: ['Yearly', 'Monthly', 'Weekly']
        }
    }

    createBarOption() {
        let option = {
            colors: ['#5DA5DA', '#60BD68', '#8e41f4', '#FECF3F', '#F15854', '#5DA5DA', '#eeaaee',
                '#55BF3B', '#DF5353', '#7798BF', '#aaeeee'],
            chart: {
                type: 'column',
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 0, x2: 1, y2: 1 },
                    stops: [
                        [0, '#333'],
                        [1, '#333']
                    ]
                },
                style: {
                    fontFamily: '\'Unica One\', sans-serif'
                },
                plotBorderColor: '#606063'
            },
            title: {
                text: null,
                style: {
                    color: '#E0E0E3',
                    fontSize: '16px'
                }
            },

            subtitle: {
                text: null,
                style: {
                    color: '#E0E0E3',
                    textTransform: 'uppercase'
                }
            },
            xAxis: {
                categories: [
                    'Mar',
                    'Apr',
                    'May',
                    'Jun'
                ],
                crosshair: true,
                gridLineColor: '#707073',
                labels: {
                    style: {
                        color: '#E0E0E3'
                    }
                },
                lineColor: '#707073',
                minorGridLineColor: '#505053',
                tickColor: '#707073'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                itemStyle: {
                    color: '#E0E0E3'
                },
                itemHoverStyle: {
                    color: '#FFF'
                },
                itemHiddenStyle: {
                    color: '#606063'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                    style: {
                        color: '#A0A0A3'

                    }
                },
                gridLineColor: '#707073',
                labels: {
                    style: {
                        color: '#E0E0E3'
                    }
                },
                lineColor: '#707073',
                minorGridLineColor: '#505053',
                tickColor: '#707073',
                tickWidth: 1
            },
            tooltip: {
                headerFormat: '<span style="font-size:12px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.z}  </b></td><td style="padding:0"><b>{point.y}</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true,
                backgroundColor: 'rgba(0, 0, 0, 0.85)',
                style: {
                    color: '#F0F0F0'
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                },
                series: {
                    animation: false,
                    dataLabels: {
                        enabled: true,
                        color: 'white',
                        border: null,
                        fontSize: '1.2em',
                        format: '<tr>' +
                        '<td style="padding:0"><b>{point.z}  </b> - </td><td style="padding:0"><b>{point.y}</b></td></tr>'
                    }
                }
            },
            series: [{}, {}, {}, {}, {}, {}]
        };
        // ----------------------  Find selected Parameter -----------
        let typeSelectedObject = null;
        let typesSelectedValue = this.props.typeSelected;
        if (this.props.typeSelected === null) {
            typeSelectedObject = this.props.rankingMetricsData[Object.keys(this.props.rankingMetricsData)[0]];
            typesSelectedValue = Object.keys(this.props.rankingMetricsData)[0];
        }
        else {
            typeSelectedObject = this.props.rankingMetricsData[this.props.typeSelected];
        }
        let basisSelectedObject = null;
        let basisSelectedValue = this.props.basisSelected;
        if (this.props.basisSelected === null) {
            basisSelectedObject = typeSelectedObject[Object.keys(typeSelectedObject)[0]];
            basisSelectedValue = Object.keys(typeSelectedObject)[0];
        }
        else {
            basisSelectedObject = typeSelectedObject[this.props.basisSelected];
        }

        // -------------------------------------------------------
        let r = '';
        if (this.props.topNumberSelected > 0) {
            r = 'Top';
        }
        else {
            r = 'Bottom';
        }

        let typeSelectedValyeTemp = userDetailDataStore.getNameValueLookupRanking(typesSelectedValue.toLowerCase()) || typesSelectedValue.toCapitalise();
        let basisSelectedValueTemp = userDetailDataStore.getNameValueLookupRanking(basisSelectedValue.toLowerCase()) || basisSelectedValue.toCapitalise();

        let titleText = r + ' ' + Math.abs(this.props.topNumberSelected) + ' ' + basisSelectedValueTemp + ' by ' + typeSelectedValyeTemp;

        option.title.text = titleText;
        if (typesSelectedValue.toLowerCase().contains('time')) {
            option.yAxis.title.text = 'Time in seconds'
        }
        else if (typesSelectedValue.toLowerCase().contains('value')) {
            option.yAxis.title.text = 'in Thousand dollars($K)'
        }
        else if (typesSelectedValue.toLowerCase().contains('volume')) {
            option.yAxis.title.text = 'in Thousands (K)'
        }
        option.xAxis.categories = this.props.rankingMetricsData[typesSelectedValue][basisSelectedValue][this.props.durationSelected.toLowerCase()].categories;
        let tempSeries = this.props.rankingMetricsData[typesSelectedValue][basisSelectedValue][this.props.durationSelected.toLowerCase()].values;
        if (this.props.topNumberSelected < 0 && tempSeries.length > 0) {
            option.series = [];
            for (let i = tempSeries.length - 1; i >= tempSeries.length - Math.abs(this.props.topNumberSelected); --i) {
                option.series.push(tempSeries[i]);
            }
        }
        if (this.props.topNumberSelected >= 0 && tempSeries.length > 0) {
            option.series = [];
            for (let i = 0; i < Math.abs(this.props.topNumberSelected); ++i) {
                option.series.push(tempSeries[i]);
            }
        }
        return option;
    }

    createLineOption() {
        let option = {
            colors: ['#2b908f', '#90ee7e', '#f45b5b', '#7798BF', '#aaeeee', '#ff0066', '#eeaaee',
                '#55BF3B', '#DF5353', '#7798BF', '#aaeeee'],
            chart: {
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 0, x2: 1, y2: 1 },
                    stops: [
                        [0, '#333'],
                        [1, '#333']
                    ]
                },
                style: {
                    fontFamily: '\'Unica One\', sans-serif'
                },
                plotBorderColor: '#606063'
            },
            title: {
                text: null,
                style: {
                    color: '#E0E0E3',
                    fontSize: '16px'
                }
            },

            subtitle: {
                text: null,
                style: {
                    color: '#E0E0E3',
                    textTransform: 'uppercase'
                }
            },
            xAxis: {
                gridLineColor: '#707073',
                labels: {
                    style: {
                        color: '#E0E0E3'
                    }
                },
                lineColor: '#707073',
                minorGridLineColor: '#505053',
                tickColor: '#707073',
                title: {
                    style: {
                        color: '#A0A0A3'

                    }
                }
            },
            yAxis: {
                title: {
                    text: null,
                    style: {
                        color: '#A0A0A3'
                    }
                },
                gridLineColor: '#707073',
                labels: {
                    style: {
                        color: '#E0E0E3'
                    }
                },
                lineColor: '#707073',
                minorGridLineColor: '#505053',
                tickColor: '#707073',
                tickWidth: 1
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                itemStyle: {
                    color: '#E0E0E3'
                },
                itemHoverStyle: {
                    color: '#FFF'
                },
                itemHiddenStyle: {
                    color: '#606063'
                }
            },
            tooltip: {
                backgroundColor: 'rgba(0, 0, 0, 0.85)',
                style: {
                    color: '#F0F0F0'
                }
            },
            credits: {
                style: {
                    color: '#666'
                }
            },
            labels: {
                style: {
                    color: '#707073'
                }
            },

            drilldown: {
                activeAxisLabelStyle: {
                    color: '#F0F0F3'
                },
                activeDataLabelStyle: {
                    color: '#F0F0F3'
                }
            },

            navigation: {
                buttonOptions: {
                    symbolStroke: '#DDDDDD',
                    theme: {
                        fill: '#505053'
                    }
                }
            },
            plotOptions: {
                series: {
                    dataLabels: {
                        enabled: true,
                        color: '#B0B0B3',
                        border: null,
                        fontSize: '1.3em',
                        format: '<tr>' +
                        '<td style="padding:0"><b>{point.z}  </b> - </td><td style="padding:0"><b>{point.y}</b></td></tr>'
                    },
                    marker: {
                        lineColor: '#333'
                    },
                    animation: false
                },
                boxplot: {
                    fillColor: '#505053'
                },
                candlestick: {
                    lineColor: 'white'
                },
                errorbar: {
                    color: 'white'
                }
            },

            series: [{
                name: 'INDIGO',
                data: [43934, 52503, 57177, 69658, 97031, 119931, 137133, 154175]
            },
            {
                name: 'FSTP',
                data: [24916, 24064, 29742, 29851, 32490, 30282, 38121, 40434]

            },
            {
                name: 'OMGI',
                data: [11744, 17722, 16005, 19771, 20185, 24377, 32147, 39387]

            },
            {
                name: 'SLI',
                data: [null, null, 7988, 12169, 15112, 22452, 34400, 34227]

            },
            {
                name: 'DFA',
                data: [12908, 5948, 8105, 11248, 8989, 11816, 18274, 18111]

            }
            ]

        };
        let typeSelectedObject = null;
        let typesSelectedValue = this.props.typeSelected;
        if (this.props.typeSelected === null) {
            typeSelectedObject = this.props.rankingMetricsData[Object.keys(this.props.rankingMetricsData)[0]];
            typesSelectedValue = Object.keys(this.props.rankingMetricsData)[0];
        }
        else {
            typeSelectedObject = this.props.rankingMetricsData[this.props.typeSelected];
        }
        let basisSelectedObject = null;
        let basisSelectedValue = this.props.basisSelected;
        if (this.props.basisSelected === null) {
            basisSelectedObject = typeSelectedObject[Object.keys(typeSelectedObject)[0]];
            basisSelectedValue = Object.keys(typeSelectedObject)[0];
        }
        else {
            basisSelectedObject = typeSelectedObject[this.props.basisSelected];
        }

        // -------------------------------------------------------
        let r = '';
        if (this.props.topNumberSelected > 0) {
            r = 'Top';
        }
        else {
            r = 'Bottom';
        }

        let typeSelectedValyeTemp = userDetailDataStore.getNameValueLookupRanking(typesSelectedValue.toLowerCase()) || typesSelectedValue.toCapitalise();
        let basisSelectedValueTemp = userDetailDataStore.getNameValueLookupRanking(basisSelectedValue.toLowerCase()) || basisSelectedValue.toCapitalise();

        let titleText = r + ' ' + Math.abs(this.props.topNumberSelected) + ' ' + basisSelectedValueTemp + ' by ' + typeSelectedValyeTemp;

        option.title.text = titleText;
        if (typesSelectedValue.toLowerCase().contains('time')) {
            option.yAxis.title.text = 'Time in seconds'
        }
        else if (typesSelectedValue.toLowerCase().contains('Value')) {
            option.yAxis.title.text = 'in Thousand dollars($K)'
        }
        else if (typesSelectedValue.toLowerCase().contains('volume')) {
            option.yAxis.title.text = 'in Thousands (K)'
        }
        option.xAxis.categories = this.props.rankingMetricsData[typesSelectedValue][basisSelectedValue][this.props.durationSelected.toLowerCase()].categories;
        let tempSeries = this.props.rankingMetricsData[typesSelectedValue][basisSelectedValue][this.props.durationSelected.toLowerCase()].values;
        if (this.props.topNumberSelected < 0 && tempSeries.length > 0) {
            option.series = [];
            for (let i = tempSeries.length - 1; i >= tempSeries.length - Math.abs(this.props.topNumberSelected); --i) {
                option.series.push(tempSeries[i]);
            }
        }
        if (this.props.topNumberSelected >= 0 && tempSeries.length > 0) {
            option.series = [];
            for (let i = 0; i < Math.abs(this.props.topNumberSelected); ++i) {
                option.series.push(tempSeries[i]);
            }
        }
        return option;
    }

    createOption() {
        if (this.props.typeOfGraph === 'bar') {
            return this.createBarOption();
        }
        else {
            return this.createLineOption();
        }
    }

    handleDurationOnClick(newDurationSelected) {
        this.props.updateDuration(newDurationSelected);
    }

    handleDeleteRankingMetricsUerTab(deleteIndex, dynamicDashName) {
        Action.deleteRankingMetricsUserConf({ deleteIndex: deleteIndex, dynamicDashName: dynamicDashName });
    }

    handleEditToggleClick() {
        this.props.toggleEditEnabled();
    }

    render() {

        let durationList = this.duration.lookup.map((item, index) => {
            let cssClass = 'gfsmetricsdashboard-graphblock-container-div-duration-each-borderleft';
            if (index === this.duration.lookup.length - 1) {
                cssClass = 'gfsmetricsdashboard-graphblock-container-div-duration-each-noborder';
            }
            if (item.toLowerCase() === this.props.durationSelected.toLowerCase()) {
                cssClass = cssClass + '-active';
            }
            return (
                <div className={cssClass} onClick={(e) => { this.handleDurationOnClick(item.toLowerCase()) }}>{item}</div>
            );
        });

        let style = {
            container: {},
            optionArrowStyle: {}
        };
        if (!this.props.editEnabled) {
            style.container.width = '100%'
            style.optionArrowStyle.borderLeft = '15px solid #42b0e5';
            style.optionArrowStyle.borderRight = '10px solid transparent';
        }

        return (
            <div style={style.container} className='gfsmetricsdashboard-graphblock-container-div'>
                <div className='gfsmetricsdashboard-graphblock-container-div-duration'>
                    <div style={style.optionArrowStyle} className='gfsmetricsdashboard-graphblock-container-div-edit-toggle' onClick={() => { this.handleEditToggleClick() }}>

                    </div>
                    <div className='gfsmetricsdashboard-graphblock-container-div-deletetab' onClick={() => { this.handleDeleteRankingMetricsUerTab(this.props.sequence, this.props.dynamicDashName) }}>

                    </div>
                    {durationList}
                </div>
                <div className='gfsmetricsdashboard-graphblock-container-div-graphdiv'>
                    <GenericChart container={this.props.container} options={this.createOption()} modules={[highcharts3d, Treemap]} />
                </div>
            </div>
        );
    }
}