import React, { Component } from 'react';
import userDetailDataStore from '../../../store/userDetailDataStore';

export default class OptionDropdown extends Component {

    render() {
        let options = Object.keys(this.props.parentObj).map((item) => {
            if(item===this.props.selectedvalue){
            return (
                <option selected className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={item.toCapitalise()}>{userDetailDataStore.getNameValueLookupRanking(item.toLowerCase()) || item.toCapitalise()}</option>
            );
        }
        else{
              return (
                <option className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={item.toCapitalise()}>{userDetailDataStore.getNameValueLookupRanking(item.toLowerCase()) || item.toCapitalise()}</option>
            );
        }
        });
        return (
            <div className='gfsmetricsdashboard-graphblock-option-dropdown-div'>
                <select className='gfsmetricsdashboard-graphblock-option-dropdown-select' onChange={(e)=>{this.props.dropdownChange(e.target.value.toLowerCase())}}>{options}</select>
            </div>
        );
    }
}