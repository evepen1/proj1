import React, { Component } from 'react';
import GraphBlock from './GraphBlock/GraphBlock';
import userDetailDataStore from '../../store/userDetailDataStore';
import * as Action from '../../action/Actions';

export default class RankingMetricsDashboard extends Component {

    constructor() {
        super();
        this.state = {
            rankingMetricsUserConf: userDetailDataStore.getRankingMetricsConfUserDetail()
        };
    }

    handleAddGraphBlock() {
        Action.addRankingMetricsUserConf();
    }

    render() {
        let graphBlockList = this.state.rankingMetricsUserConf.map((item, index) => {
            return (
                <GraphBlock key={index +'_'+ new Date().valueOf()} sequence={index} 
                addCssname={index +'_'+ new Date().valueOf()} 
                typeSelected={item.typeSelected} 
                basisSelected={item.basisSelected} 
                topNumberSelected={item.topNumberSelected} 
                durationSelected={item.durationSelected}
                editEnabled={item.editEnabled}
                typeOfGraph={item.typeOfGraph}
                 />
            );
        });
        return (
            <div className='gfsmetricsdashboard-container'>
                {graphBlockList}
                <div className='gfsmetricsdashboard-graphblock-div gfsmetricsdashboard-graphblock-div-addnew' onClick={() => { this.handleAddGraphBlock() }}>

                </div>
            </div>
        );
    }

    componentDidMount() {
        userDetailDataStore.on("RankingMetricsUserConfUpdated", () => {
            this.setState({
                rankingMetricsUserConf: userDetailDataStore.getRankingMetricsConfUserDetail()
            });
        });
        userDetailDataStore.on("refreshAllDashboard", () => {
            this.setState({
                rankingMetricsUserConf: userDetailDataStore.getRankingMetricsConfUserDetail()
            });
        });
    }

    componentWillUnmount() {
        userDetailDataStore.removeListener("RankingMetricsUserConfUpdated", () => {
        });
         userDetailDataStore.removeListener("refreshAllDashboard", () => {
        });
    }
}