import React, { Component } from 'react';
import GraphBlock from './GraphBlock/GraphBlock';
import userDetailDataStore from '../../store/userDetailDataStore';
import * as Action from '../../action/Actions';

export default class RankingDynamicDashboard extends Component {

    constructor(props) {
        super(props);
        this.state = {
            rankingMetricsUserConf: userDetailDataStore.getUserTabConfig(this.props.name)
        };
    }

    handleAddGraphBlock(name) {
        Action.addDynamicDashBoardTab(name);
    }

    render() {
        let graphBlockList = this.state.rankingMetricsUserConf.map((item, index) => {
            return (
                <GraphBlock key={index + '_' + new Date().valueOf()} sequence={index}
                    addCssname={index + '_' + new Date().valueOf()}
                    typeSelected={item.typeSelected} basisSelected={item.basisSelected}
                    topNumberSelected={item.topNumberSelected}
                    durationSelected={item.durationSelected}
                    dynamicDashName={this.props.name}
                    editEnabled={item.editEnabled}
                    typeOfGraph={item.typeOfGraph}
                />
            );
        });
        return (
            <div className='gfsmetricsdashboard-container'>
                {graphBlockList}
                <div className='gfsmetricsdashboard-graphblock-div gfsmetricsdashboard-graphblock-div-addnew' onClick={() => { this.handleAddGraphBlock(this.props.name) }}>

                </div>
            </div>
        );
    }

    componentDidMount() {
        userDetailDataStore.on("DynamicDashboardUserConfUpdated" + this.props.name, () => {
            this.setState({
                rankingMetricsUserConf: userDetailDataStore.getUserTabConfig(this.props.name)
            });
        });
    }

    componentWillUnmount() {
        userDetailDataStore.removeListener("DynamicDashboardUserConfUpdated" + this.props.name, () => {
        });
    }
}