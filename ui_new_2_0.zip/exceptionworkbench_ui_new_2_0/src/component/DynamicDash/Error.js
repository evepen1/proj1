import React, { Component } from 'react';
import { hashHistory } from 'react-router';

export default class Error extends Component {

    render() {
        return (<div> Page not found redirecting to home page </div>);

    }
    componentDidMount() {
        hashHistory.push('/');
    }

}