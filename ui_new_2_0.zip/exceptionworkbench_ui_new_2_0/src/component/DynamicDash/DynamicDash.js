import React, { Component } from 'react';
import GeneralDynamicDashboard from '../GeneralDynamicDashboard/GeneralDynamicDashboard';
import DynamicDashboard from '../GfsMetricsDashboard/DynamicDashboard';
import RankingDynamicDashboard from '../RankingDashboard/RankingDynamicDashboard';
import ExceptionPredictabilityDynamicDashboard from '../ExceptionPredictabilityDashboard/ExceptionPredictabilityDynamicDashboard';
import userDetailDataStore from '../../store/userDetailDataStore';
import { hashHistory } from 'react-router';
import Error from './Error';


export default class DynamicDash extends Component {

    constructor() {
        super();
        this.state = {
            data: userDetailDataStore.getDynamicTabData()
        };
    }

    render() {
        const url = this.props.routeParams.page;
        let PageComponent, PageComponentProperty;
        try {
            PageComponentProperty = userDetailDataStore.getDynamicTabData().find((page) => { return page.link === url }).property;
        }
        catch (err) {
            console.log(err);
            return (
                <Error />
            );
        }

        if (PageComponentProperty === 'DynamicDashboard') {
            PageComponent = DynamicDashboard;
        }
        else if (PageComponentProperty === 'RankingDynamicDashboard') {
            PageComponent = RankingDynamicDashboard;
        }
        else if (PageComponentProperty === 'ExceptionPredictabilityDynamicDashboard') {
            PageComponent = ExceptionPredictabilityDynamicDashboard;
        }
         else if (PageComponentProperty === 'GeneralDynamicDashboard') {
            PageComponent = GeneralDynamicDashboard;
        }

        return <PageComponent key={userDetailDataStore.getDynamicTabData().find(page => page.link === url).name} name={userDetailDataStore.getDynamicTabData().find(page => page.link === url).name} />;
    }
}