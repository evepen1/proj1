import React, { Component } from 'react';
import * as Action from '../../../action/Actions';
import exceptionTableDataStore from '../../../store/exceptionTableDataStore';

export default class HeaderTab extends Component {


    handleHeaderOnClick(name) {
        exceptionTableDataStore.clearData();
        Action.changeActiveCategory(name);
    }

    render() {
        return (
            <div className={'ewdashboard-header-tab ' + this.props.cssClass} onClick={(e) => { this.handleHeaderOnClick(this.props.value) }}>
                <span className='ewdashboard-headerbar-span-name'>
                    {this.props.name}
                </span>
                <span className='ewdashboard-headerbar-span-count'>
                    {this.props.count}
                </span>
            </div>
        );
    }

}