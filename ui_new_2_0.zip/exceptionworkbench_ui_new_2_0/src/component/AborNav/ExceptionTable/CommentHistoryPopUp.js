import React, {
    Component
} from 'react';
import * as Action from '../../../action/Actions';
export default class CommentHistoryView extends Component {

    constructor() {
        super();
        this.state= {
            textValue : ''
        }
    }

    handleCommentChange(e) {
        this.setState({textValue : e.target.value});
    }

    handleAddComment(addComment) {
        if(this.state.textValue) { 
            this.setState({textValue : ''});
            Action.updateAborNavComment(addComment);
        }
    }

    handleClearComment() {
        this.setState({textValue : ''});
    }

    render() {
        var records;
        if(this.props.item.commentDetail != undefined) {
            records = this.props.item.commentDetail.map((item, index) => {
                return (<tr className="ewdashboard-exceptiontable-detailed-comment-popup-table-tr">
                    <td className="ewdashboard-exceptiontable-detailed-comment-popup-table-td-user">
                        <figure>
                            <img src="../../../../assets/img/userProfilePic.jpg"/>
                            <figcaption>{item.userId}</figcaption>
                            </figure>
                    </td>
                    <td className="ewdashboard-exceptiontable-detailed-comment-popup-table-td-comment">
                        <div className="ewdashboard-exceptiontable-detailed-comment-popup-table-td-box-arrow-div">
                            <div className="ewdashboard-exceptiontable-detailed-comment-popup-table-td-box-arrow">
                            </div>
                         </div>   
                        <div className="ewdashboard-exceptiontable-detailed-comment-popup-table-td-comment-box">
                            <div className="ewdashboard-exceptiontable-detailed-comment-popup-table-td-comment-time">{item.time}</div>
                            <div className="ewdashboard-exceptiontable-detailed-comment-popup-table-td-comment-data">
                                {item.comment}
                            </div>
                        </div>
                    </td>
                </tr>
                );
            });
        }

        return (
         <div style={this.props.style} className="ewdashboard-exceptiontable-drilldown-commentary-div">
             <div className="ewdashboard-exceptiontable-drilldown-commentary-add-div">
                 <textarea value={this.state.textValue} className='ewdashboard-exceptiontable-drilldown-commentary-add-textarea' onChange={(e) => {this.handleCommentChange(e)}}/>
                <div className="ewdashboard-exceptiontable-drilldown-commentary-button-div">
                 <input style={{backgroundColor: '#0080FF'}} type="button" value="Add" className="ewdashboard-exceptiontable-drilldown-commentary-clear-button"
                    onClick={(e) => { this.handleAddComment({id: this.props.item.validationKey, comment: this.state.textValue})}}/>
                 <input type="button" value="Clear" className="ewdashboard-exceptiontable-drilldown-commentary-clear-button"
                   onClick={(e) => { this.handleClearComment()}}/>
                </div>
             </div>
             <div className="ewdashboard-exceptiontable-drilldown-commentary-table-div">
                <table className="ewdashboard-exceptiontable-drilldown-commentary-table">
                    <tbody>
                        {records}
                    </tbody>
                </table>
             </div>
         </div>
        );
    }

}