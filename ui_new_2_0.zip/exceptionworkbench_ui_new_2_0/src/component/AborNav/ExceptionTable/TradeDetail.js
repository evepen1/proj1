import React, { Component } from 'react';

export default class TradeDetail extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        let tradeDetail = [];
        let tradeDetailsKeys = Object.keys(this.props.tradeDetail);
        for (let itr = 0; itr < tradeDetailsKeys.length; itr += 2) {
            tradeDetail.push(
                <tr>
                    <th>{tradeDetailsKeys[itr]}</th>
                    <td>{this.props.tradeDetail[tradeDetailsKeys[itr]]}</td>
                    <th>{tradeDetailsKeys[itr+1]}</th>
                    <td>{this.props.tradeDetail[tradeDetailsKeys[itr+1]]}</td>
                </tr>
            );
        }

        console.log(tradeDetail);
        let style = { display: 'none' };
        if(this.props.displayDetail){
            style.display='block';
        }

        return (
            <div>

                <div style={style} className="ewdashboard-exceptiontable-tradedetail-white_overlay">
                    <div className='ewdashboard-exceptiontable-tradedetail-popup-close'>
                        <input className='ewdashboard-exceptiontable-tradedetail-popup-x-close'
                            type='button' value='X'
                            onClick={(e) => { this.props.clickClose() }} />
                    </div>
                    <div style={style} className='ewdashboard-exceptiontable-tradedetail-content-div'>
                        <table className="ewdashboard-exceptiontable-tradedetail-content-table">
                            <tbody>
                                {tradeDetail}
                            </tbody>
                        </table>
                    </div>

                </div>
                <div style={style} className="ewdashboard-exceptiontable-tradedetail-content-black_overlay" onClick={(e) => { this.props.clickClose() }}></div>
            </div>
        );
    }

}