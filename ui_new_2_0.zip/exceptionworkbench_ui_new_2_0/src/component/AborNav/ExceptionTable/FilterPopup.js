import React from 'react'
import * as Action from "../../../action/Actions";
import exceptionTableDataStore from "../../../store/exceptionTableDataStore";

export default class FilterPopup extends React.Component {
    constructor() {
        super();
        this.filterPopupData = [];
    }
    handleOnClickClose(e) {
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();
        this.props.handleonclose();
    }

    handleOnClickClear() {
        Action.clearFilterSelected(this.props.headerFieldName);
    }

    handleOnClickClearAll() {
        Action.clearFilterSelected();
    }

    handleOnClickFilterPopupStop(e) {
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();
    }

    handleCheckBoxOnChange(headerFieldName, headerFieldValue) {
        Action.handleSearchBoxFilter({
            headerFieldName: headerFieldName,
            headerFieldValue: headerFieldValue
        });
    }
    handleOnClickFilterPopupSave(e) {
        console.log("On clicked save");
        Action.refreshFilterExceptionTableData();
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();
        this.props.handleonclose();
    }

    handleSelectAll() {
        Action.selectAllFilterPopupChange(this.props.headerFieldName);
    }

    render() {

        let headerSet = exceptionTableDataStore.getFilterHeaderData(this.props.headerFieldName);
        let headerList = Array.from(headerSet);
        let allChecked = false;
        if (this.props.checkedItemSearchBoxList != undefined) {
            allChecked = headerList.length == this.props.checkedItemSearchBoxList.length;
        }
        let records = headerList.map((item, index) => {
            if (this.props.checkedItemSearchBoxList != undefined && this.props.checkedItemSearchBoxList.indexOf(item) > -1) {
                return (<tr>
                    <td><input type="checkbox"
                        value={item} className="ewdashboard-exceptiontable-checkbox"
                        checked
                        onChange={e => this.handleCheckBoxOnChange(this.props.headerFieldName, item)} /></td>
                    <td>{item}</td>
                </tr>);
            }
            else {
                return (<tr>
                    <td><input type="checkbox"
                        value={item} className="ewdashboard-exceptiontable-checkbox"
                        onChange={e => this.handleCheckBoxOnChange(this.props.headerFieldName, item)} /></td>
                    <td>{item}</td>
                </tr>);
            }
        });
        return (

            <div onClick={e => this.handleOnClickFilterPopupStop(e)}
                className="ewdashboard-exceptiontable-filter-popup-white_content">
                <div className="ewdashboard-exceptiontable-filter-popup-search-div">
                    <input type="text" className="ewdashboard-exceptiontable-filter-popup-search-div-input" placeholder='Search' /></div>
                <div className="ewdashboard-exceptiontable-filter-popup-table-div">
                    <table className="ewdashboard-exceptiontable-filter-popup-table">
                        <thead className="ewdashboard-exceptiontable-filter-popup-select-header">
                            <tr>
                                <td> <input className="ewdashboard-exceptiontable-checkbox"
                                    type="checkbox" checked={allChecked} onChange={(e) => { this.handleSelectAll(); }} /></td>
                                <td>
                                    Select All
                               </td>
                            </tr>
                        </thead>
                        <tbody>

                            {records}

                        </tbody>
                    </table>
                </div>
                <div className="ewdashboard-exceptiontable-filter-popup-cancel-div">
                    {/*<input type='button' value='Done' onClick={(e) => { this.handleOnClickFilterPopupSave(e) }} />*/}
                    <input type='button' value='Clear' className="ewdashboard-exceptiontable-filter-popup-cancel-div-input" onClick={(e) => { this.handleOnClickClear(e) }} />
                    <input type='button' value='Clear All' className="ewdashboard-exceptiontable-filter-popup-cancel-div-input" onClick={(e) => { this.handleOnClickClearAll(e) }} />
                    <input type='button' value='Cancel' className="ewdashboard-exceptiontable-filter-popup-cancel-div-input" onClick={(e) => { this.handleOnClickClose(e) }} />
                </div>
            </div>

        );
    }
}