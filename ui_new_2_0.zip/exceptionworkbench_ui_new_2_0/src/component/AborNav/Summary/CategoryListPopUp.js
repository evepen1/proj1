import React, { Component } from 'react';
import * as Action from '../../../action/Actions';
export default class GenericCriticalStatusView extends Component {

    constructor() {
        super();
        this.state = {
            activeCategoryIndex: -1
        };

    }
    handleCategoryListPopupDataTableClick(e, index, status, category) {

        if (this.state.activeCategoryIndex === index) {
            this.setState({ activeCategoryIndex: -1 });
            Action.changeActiveCategoryExceptionTableAborNav(null);
        } else {
            this.setState({ activeCategoryIndex: index });
            Action.changeActiveCategoryPopupAborNavExceptionTable({ categoryName: category, 
                currentStatus: status });
            e.stopPropagation();
            e.nativeEvent.stopImmediatePropagation();
        }
    }
    render() {
        var records = this.props.status.map((item, index) => {
            let tdActiveCategoryCssClass = 'ewdashboard-summary-detail-category-list-status-tr ewdashboard-summary-detail-category-list-status-tr-' + (index % 2);
            if (this.state.activeCategoryIndex === index) {
                tdActiveCategoryCssClass = 'ewdashboard-summary-detail-category-list-clicked';
            }
            return (
                <tr className={tdActiveCategoryCssClass} onClick={(e) => {
                    this.handleCategoryListPopupDataTableClick(e, index, item.name, this.props.name)
                }}>
                    <td className='ewdashboard-summary-detail-category-list-status-td'>{item.name}</td>
                    <td className='ewdashboard-summary-detail-category-list-status-td'>{item.value}</td></tr>
            );
        });

        return (
            <table className='ewdashboard-summary-detail-category-list-status-table'>
                <tbody className='ewdashboard-summary-detail-category-list-status-tbody'>
                    {records}
                </tbody>
            </table>
        );
    }

}
