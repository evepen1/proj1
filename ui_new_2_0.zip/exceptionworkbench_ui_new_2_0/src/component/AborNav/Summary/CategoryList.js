import React, { Component } from 'react';
import exceptionSummaryAborNavDataStore from '../../../store/exceptionSummaryAborNavDataStore';
import CategoryListPopUp from './CategoryListPopUp';
import * as Action from '../../../action/Actions';

export default class CategoryList extends Component {

  constructor(props) {
    super(props);
    this.state = {
      activeListPopUpIndex: exceptionSummaryAborNavDataStore.getActiveListPopUpIndex(),
    };
    this.popup = { xposition: 0, yposition: 0 };
    this.clicked = false;
    this.activeCategoryIndex = this.props.initialIndex;
  }

  handleCategoryListPopUpClick(e, index) {
    if (this.clicked) {
      Action.changeActiveListAborNavPopUpIndex(index);
      if (this.state.activeListPopUpIndex === index) {
        this.clicked = false;
      }
    }
    else {
      this.clicked = true;
    }
  }

  handleCategoryListPopUpMouseEnter(e, index) {
    let rect = e.target.getBoundingClientRect();
    this.popup.xposition = rect.right - 15;
    this.popup.yposition = rect.bottom - 25;
    if (!this.clicked) {
      Action.changeActiveListAborNavPopUpIndex(index);
    }
  }

  handleCategoryListPopUpMouseLeave(e, index) {
    let rect = e.target.getBoundingClientRect();
     this.popup.xposition = rect.right - 15;
    this.popup.yposition = rect.bottom - 25;
    if (!this.clicked) {
      Action.changeActiveListAborNavPopUpIndex(-1);
    }
  }
  handleCategoryListDataTableClick(e, index, category) {
    if (this.state.activeCategoryIndex === index) {
      this.setState({ activeCategoryIndex: -1 });
      Action.changeActiveCategoryExceptionTableAborNav(null);
    } else {
      this.setState({ activeCategoryIndex: index });
      Action.changeActiveCategoryExceptionTableAborNav(category);
    }
  }
  render() {
    let popupStyle = {
      'position': 'absolute',
      'top': this.popup.yposition,
      'left': this.popup.xposition
    };
    var records = this.props.activeSummaryException.map((item, index) => {
      let displayCssClass = 'display-none';
      let tdCssClass = 'ewdashboard-summary-detail-category-list-tbody-td-status-' + this.props.value;
      if (this.state.activeListPopUpIndex == index) {
        tdCssClass = tdCssClass + '-clicked';
        displayCssClass = 'display-block';
      }

      let tdActiveCategoryCssClass = 'ewdashboard-summary-detail-category-list-tbody-td-label';
      if (this.state.activeCategoryIndex === index) {
        tdActiveCategoryCssClass = 'ewdashboard-summary-detail-category-list-clicked';
      }

      return (
        <tr className='ewdashboard-summary-detail-category-list-tbody-tr'>
          <td className={tdActiveCategoryCssClass}
            onClick={(e) => { this.handleCategoryListDataTableClick(e, index, item.name) }}>{item.name}</td>
          <td className={tdCssClass} onClick={(e) => { this.handleCategoryListPopUpClick(e, index) }}
            onMouseEnter={(e) => { this.handleCategoryListPopUpMouseEnter(e, index) }}
            onMouseLeave={(e) => { this.handleCategoryListPopUpMouseLeave(e, index) }}>
            <div className='ewdashboard-summary-detail-category-list-tbody-td-div'>
              {item.value}

            </div>
            <div style={popupStyle} className={'ewdashboard-summary-detail-category-list-status-popup-div ' + displayCssClass}>
                <CategoryListPopUp status={item.status} name={item.name} />
            </div>
            <div className='ewdashboard-summary-detail-category-list-tbody-td-right-arrow'></div>
          </td></tr>
      );
    });
    return (
      <table className='ewdashboard-summary-detail-category-list-table'>
        <tbody className='ewdashboard-summary-detail-category-list-tbody'>
          {records}
        </tbody>
      </table>
    );
  }

  componentDidMount() {
    exceptionSummaryAborNavDataStore.on("ResetAborNavIndexOfChossenExceptionCategory", () => {
      this.state.activeCategoryIndex = this.props.initialIndex;
    });
    exceptionSummaryAborNavDataStore.on("ActiveCategoryListAborNavPopUpIndexChanged", () => {
      this.setState({
        activeListPopUpIndex: exceptionSummaryAborNavDataStore.getActiveListPopUpIndex()
      });
    });
  }

  componentWillUnmount() {
    exceptionSummaryAborNavDataStore.removeListener("ActiveCategoryListAborNavPopUpIndexChanged", () => {
    });
    exceptionSummaryAborNavDataStore.removeListener("ResetAborNavIndexOfChossenExceptionCategory", () => {
    });
  }

}