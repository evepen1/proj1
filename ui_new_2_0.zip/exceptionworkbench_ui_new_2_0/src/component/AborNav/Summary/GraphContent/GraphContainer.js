import React, { Component } from 'react';
import GraphGenerate from './GraphGenerate';
import graphAborNavDataStore from '../../../../store/graphAborNavDataStore'

export default class GraphContainer extends Component {

    constructor() {
        super();
        this.state = {
            chartData: graphAborNavDataStore.getChartData(),
            graphType: graphAborNavDataStore.getGraphTypeSelected(),
            graphUpdated: false
        }
    }

    render() {
        return (
            <div className='ewdashboard-summary-graph-container-div'>
                <GraphGenerate container='chart-s' display={this.state.graphUpdated} 
                selectedGraphType={this.state.graphType} 
                selectedGraph={graphAborNavDataStore.getGraphNameSelected()}
                 chartData={this.state.chartData} />
            </div>
        );
    }

    componentDidMount() {
        graphAborNavDataStore.on("ChartAborNavDataRefreshed", () => {
            this.setState({
                chartData: graphAborNavDataStore.getChartData(),
                graphUpdated: true
            });
        });
        graphAborNavDataStore.on("GraphTypeSelectedChangedAborNav", () => {
            this.setState({
                graphType: graphAborNavDataStore.getGraphTypeSelected(),
                graphUpdated: true
            });
        });
    }

    componentWillUnmount() {
        graphAborNavDataStore.removeListener("ChartAborNavDataRefreshed", () => {
        });
        graphAborNavDataStore.removeListener("GraphTypeSelectedChangedAborNav", () => {
        });
    }

}