import React, { Component } from 'react';
import graphAborNavDataStore from '../../../../store/graphAborNavDataStore';
import * as Action from '../../../../action/Actions';

export default class GraphDataSelector extends Component {

    constructor() {
        super();
        this.state = {
            graphNameSelected: graphAborNavDataStore.getGraphNameSelected()
        };
    }

    handleGraphNameTabClick(name) {
        Action.changeGraphNameAborNav(name);
    }
    render() {
        let graphNamelist = graphAborNavDataStore.getGraphNamelist().map((item) => {
            let cssClass = 'ewdashboard-summary-graph-data-selector-tab';
            if (item === this.state.graphNameSelected) {
                cssClass = cssClass + '-active';
            }
            return (
                <div className={cssClass} onClick={(e) => { this.handleGraphNameTabClick(item) }}>
                    {item}
                </div>
            );
        });
        let options = graphAborNavDataStore.getGraphNamelist().map(dropdownItem => {
            if (dropdownItem === this.state.graphNameSelected) {
                return (<option selected className='ewdashboard-summary-graph-container-option-dropdown'
                    value={dropdownItem}>{dropdownItem}</option>);
            }
            return (<option className='ewdashboard-summary-graph-container-option-dropdown'
                value={dropdownItem}>{dropdownItem}</option>);
        });
        //  graphAborNavDataStore.getGraphNamelist().map((item) => {
        return (
            <div className='ewdashboard-summary-graph-data-selector-div'>
                <select className='ewdashboard-summary-graph-container-select-dropdown'
                    onChange={(e) => { this.handleGraphNameTabClick(e.target.value) }}
                >
                    {options}
                </select>
            </div>
        );
        // });
    }

    componentDidMount() {
        graphAborNavDataStore.on("GraphNameSelectedChangedAborNav", () => {
            this.setState({
                graphNameSelected: graphAborNavDataStore.getGraphNameSelected()
            });
            Action.refreshChartAborNavData(graphAborNavDataStore.getGraphNameSelected());
        });
        Action.refreshChartAborNavData(graphAborNavDataStore.getGraphNameSelected());
    }

    componentWillUnmount() {
        graphAborNavDataStore.removeListener("GraphNameSelectedChangedAborNav", () => {
        });
    }
}