import React, { Component } from 'react';
import CitiHeader from './CitiHeader.js';
import CitiFooter from './CitiFooter.js';
import * as Action from '../../action/Actions';

export default class Login extends Component {

    constructor() {
        super();
        this.state = {
            userId: 'admin',
            password: 'pass123'
        }

    }

    handleUserIdChange(e) {
        this.setState({ userId: e.target.value });
    }

    handlePasswordChange(e) {
        this.setState({ password: e.target.value });
    }

    authenticateUser() {
        let credentials = {
            'user': this.state.userId,
            'password': this.state.password
        };
        Action.authenticateUser(credentials);
    }

    handleKeyPress(e) {
        if (e.charCode == '13') {
            this.authenticateUser();
        }
    }

    render() {
        return (
            <div className='login-container' onKeyPress={(e) => { this.handleKeyPress(e) }}>
                <CitiHeader citiLogoURL="http://www.citigroup.net/ti/csduserexperience/bootstrap/assets/img/logos/citilogo_header.png"
                    siteTitle="Exception WorkBench" />
                <div className='login-form-div'>
                    <table className='login-table'>
                        <tr className='login-user-tr'>
                            <td>  <label className='login-label'>User : </label></td>
                            <td>  <input className='login-input' type='text' spellCheck='false' required autoFocus value={this.state.userId}
                                onChange={(e) => { this.handleUserIdChange(e) }} /></td>
                        </tr>
                        <tr className='login-password-tr'>
                            <td>  <label className='login-label'>Password : </label></td>
                            <td>  <input className='login-input' type='password' required value={this.state.password}
                                onChange={(e) => { this.handlePasswordChange(e) }} /></td>
                        </tr>
                        <tr className='login-submit-tr'>
                            <td className='login-submit-td' colSpan="2">
                                <button className='login-submit-button' onClick={this.authenticateUser.bind(this)} >Log in</button>
                            </td>
                        </tr>
                    </table>
                </div>
                <CitiFooter />

            </div>
        );
    }

}