import React, { Component } from 'react';
import HeaderBar from './Header/Header';
import Summary from './Summary/Summary';
import TradeStateTable from './TradeStateTable/TradeStateTable';
import * as Action from '../../action/Actions';
import tradeStateDataStore from '../../store/tradeStateDataStore';

export default class TradeState extends Component {
 
    render() {
        return (
            <div className='ewdashboard-container'>
                {/*<HeaderBar />*/}
                <Summary />
                <TradeStateTable />
            </div>
        );
    }

    componentDidMount() {
        this.autoRefresh = setInterval(function () {
            Action.refreshTradeStateData();
            Action.refreshTradeStateSummaryData();
        }, 10000);
    }

    componentWillUnmount() {
        clearInterval(this.autoRefresh);
    }
}