import React, { Component } from 'react';
import { hashHistory } from 'react-router';
import activeExceptionCategoryListStore from '../../store/actveExceptionCategoryStore';
import * as Action from '../../action/Actions';

export default class ProgressBar extends Component {

    constructor(props) {
        super(props);
    }

    handleClickException(){
        Action.changeActiveCriticalityOnly('All');
        Action.changeActiveCategoryOnly(activeExceptionCategoryListStore.getActiveCategoryValue(this.props.stageName));
        Action.changeClientFilterOnly(this.props.clientName);
        hashHistory.push('app/ewdashboard');
    }

    getGreenWidth() {
        return (this.props.green / this.getSum()) * 100;
    }

    getOrangeWidth() {
        return (this.props.orange / this.getSum()) * 100;
    }

    getRedWidth() {
        return (this.props.red / this.getSum()) * 100;
    }

    getSum() {
        return this.props.green + this.props.orange + this.props.red;
    }

    render() {
        let startIndex = -1;
        let lastIndex = -1;
        if (this.props.green > 0) {
            startIndex = 0;
        }
        else if (this.props.orange > 0) {
            startIndex = 1;
        }
        else if (this.props.red > 0) {
            startIndex = 2;
        }
        if (this.props.red > 0) {
            lastIndex = 2;
        }
        else if (this.props.orange > 0) {
            lastIndex = 1;
        }
        else if (this.props.green > 0) {
            lastIndex = 0;
        }
        let style_green = {
            width: this.getGreenWidth() + '%'
        };
        let style_orange = {
            width: this.getOrangeWidth() + '%'
        };
        let style_red = {
            width: this.getRedWidth() + '%'
        };
        switch (startIndex) {
            case 0: {
                style_green.borderTopLeftRadius = '10px';
                style_green.borderBottomLeftRadius = '10px';
                break;
            }
            case 1: {
                style_orange.borderTopLeftRadius = '10px';
                style_orange.borderBottomLeftRadius = '10px';
                break;
            }
            case 2: {
                style_red.borderTopLeftRadius = '10px';
                style_red.borderBottomLeftRadius = '10px';
                break;
            }
        }
        switch (lastIndex) {
            case 0: {
                style_green.borderTopRightRadius = '10px';
                style_green.borderBottomRightRadius = '10px';
                break;
            }
            case 1: {
                style_orange.borderTopRightRadius = '10px';
                style_orange.borderBottomRightRadius = '10px';
                break;
            }
            case 2: {
                style_red.borderTopRightRadius = '10px';
                style_red.borderBottomRightRadius = '10px';
                break;
            }
        }
        return (
            <div className='probar-container'>
                <div style={style_green} className='probar-green'>
                    {this.props.green == 0 ? '' : this.props.green}
                </div>
                <div style={style_orange} className='probar-orange'>
                    {this.props.orange == 0 ? '' : this.props.orange}
                </div>
                <div style={style_red} className='probar-red' onClick={(e)=>{this.handleClickException()}}>
                    {this.props.red == 0 ? '' : this.props.red}
                </div>
            </div>
        );
    }

}