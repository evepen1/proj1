import React, { Component } from 'react';
import { hashHistory } from 'react-router';
import * as Action from '../../action/Actions';
import userDetailDataStore from '../../store/userDetailDataStore';
import CitiHeader from '../Login/CitiHeader.js';
import HomeTab from './HomeTabNew';
export default class HomePage extends Component {

    render() {
        if (!userDetailDataStore.getLoggedInStatus()) {
            hashHistory.push('login');
            return (<div></div>);
        }
        return (
            <div className='home-page'>
                <CitiHeader citiLogoURL="http://www.citigroup.net/ti/csduserexperience/bootstrap/assets/img/logos/citilogo_header.png"
                    siteTitle="Exception WorkBench" />
                <div className='home-container'>
                    {/*   <div className='home-content-container'>
                    </div>
                    <div className='home-tab-container'>
                        <HomeTab cssAddon='tp' text='Trade Processing' link='app' />
                        <HomeTab cssAddon='price' text='Pricing' link='pr' />
                        <HomeTab cssAddon='recon' text='Frontier (RECON)' link='fr' />
                        <HomeTab cssAddon='nav' text='NAV Process (ABOR)' link='nav' />
                        <HomeTab cssAddon='etf' text='Exchange Traded Fund' link='etf' />
                        <HomeTab cssAddon='ts' text='Trade Life Cycle' link='ts' />
                    </div>
                    <div className='home-tab-footer'>
                    </div>*/}
                    <HomeTab cssAddon='tp' text='Trade Workflow Process' link='app' />
                    <HomeTab cssAddon='nav' text='NAV Workflow Process' link='nav' />
                    <HomeTab cssAddon='etf' text='ETF Workflow Process' link='etf' />
                    {/*<HomeTab cssAddon='ts' text='Trade Life Cycle' link='ts' />*/}
                </div>
            </div>
        );
    }

}