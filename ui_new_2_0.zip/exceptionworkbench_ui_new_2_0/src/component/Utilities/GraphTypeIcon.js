import React, { Component } from 'react';
import * as Action from '../../action/Actions';

export default class GraphTypeIcon extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        let style = {};
        if (this.props.active === this.props.type) {
            style.background = '#0a6b9b';
        }
        return (
            <div style={style} className='utilities-graphtypeicon-div-container' onClick={(e) => { this.props.onclickaction(this.props.type) }}>
                <div className={'utilities-graphtypeicon-div-icon ' + 'utilities-graphtypeicon-div-icon-' + this.props.type}>
                </div>
                <div className='utilities-graphtypeicon-div-content'>
                    {this.props.detail}
                </div>
            </div>
        );
    }

}