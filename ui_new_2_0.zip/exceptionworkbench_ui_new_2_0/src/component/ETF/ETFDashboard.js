import React, { Component } from 'react';
import HeaderBar from './Header/Header';
import Summary from './Summary/Summary';
import ExceptionTable from './ExceptionTable/ExceptionTable';

export default class ETFDashboard extends Component {
    render() {
        return (
            <div className='ewdashboard-container'>
                {/*<HeaderBar />*/}
                <Summary />
                <ExceptionTable />
            </div>
        );
    }
}