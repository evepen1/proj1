import React, { Component } from 'react';
import GraphDataSelector from './GraphContent/GraphDataSelector';
import GraphAndTypeContent from './GraphContent/GraphAndTypeContent';

export default class SummaryGraph extends Component {

    render(){
        return (
            <div className='etf-summary-graph-div'>
                <GraphDataSelector />
                <GraphAndTypeContent />
            </div>
        );
    }

}