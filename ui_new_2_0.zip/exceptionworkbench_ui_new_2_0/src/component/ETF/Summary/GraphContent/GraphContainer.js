import React, { Component } from 'react';
import GraphGenerate from './GraphGenerate';
import graphDataStore from '../../../../store/graphDataStore'

export default class GraphContainer extends Component {

    constructor() {
        super();
        this.state = {
            chartData: graphDataStore.getChartData(),
            graphType: graphDataStore.getGraphTypeSelected(),
            graphUpdated: false
        }
    }

    render() {
        return (
            <div className='ewdashboard-summary-graph-container-div'>
                <GraphGenerate container='chart-s' display={this.state.graphUpdated} 
                selectedGraphType={this.state.graphType} 
                selectedGraph={graphDataStore.getGraphNameSelected()}
                 chartData={this.state.chartData} />
            </div>
        );
    }

    componentDidMount() {
        graphDataStore.on("ChartDataRefreshed", () => {
            this.setState({
                chartData: graphDataStore.getChartData(),
                graphUpdated: true
            });
        });
        graphDataStore.on("GraphTypeSelectedChanged", () => {
            this.setState({
                graphType: graphDataStore.getGraphTypeSelected(),
                graphUpdated: true
            });
        });
    }

    componentWillUnmount() {
        graphDataStore.removeListener("ChartDataRefreshed", () => {
        });
        graphDataStore.removeListener("GraphTypeSelectedChanged", () => {
        });
    }

}