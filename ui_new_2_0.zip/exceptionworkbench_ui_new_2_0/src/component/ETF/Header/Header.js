import React, { Component } from 'react';
import HeaderTab from './HeaderTab';
import activeExceptionCategoryListStore from '../../../store/ActiveNavUpstreamExceptionCategoryStore';
import exceptionSummaryDataStore from '../../../store/exceptionSummaryDataStore';
import userDetailDataStore from '../../../store/userDetailDataStore';
import * as Action from '../../../action/Actions';

export default class HeaderBar extends Component {

    constructor() {
        super();
        this.state = {
            exceptionCountSummary: activeExceptionCategoryListStore.getExceptionCountSummary(),
            activeCategory: activeExceptionCategoryListStore.getActiveCategory(),
        };
    }

    render() {

        let sizeOfHeaderLookup = activeExceptionCategoryListStore.getHeaderLookup().length;
        let headertab = activeExceptionCategoryListStore.getHeaderLookup().map((item, index) => {
            let cssClass = 'ewdashboard-header-' + item.cssTag;
            if (this.state.activeCategory === item.value) {
                cssClass = cssClass + ' ewdashboard-header-active';
            }
            if (sizeOfHeaderLookup === index + 1) {
                cssClass = cssClass + ' ewdashboard-header-lasttab';
            }


            let count = undefined;
            if (this.state.exceptionCountSummary[item.name.toUpperCase()] !== undefined) {
                count = this.state.exceptionCountSummary[item.name.toUpperCase()].count;
            }
            // console.log(item.name)
            // console.log(count)
            let tempName = undefined;
            if (item.name == 'TRADE CAPTURE') {
                tempName = "Trade";
            }else if (item.name == 'Confirmation') {
                tempName = "Transfer Agency";
            }
            else if (item.name == 'Accounting') {
                tempName = "Corporate Action";
            }
            else if (item.name == 'Settlement') {
                tempName = "Fx Rates";
            }
            else {
                tempName = item.name;
            }
            return (
                <HeaderTab key={item.value} count={count || ' 0 '} cssClass={cssClass} name={tempName} value={item.value} />
            );
        });

        return (
            <div className='ewdashboard-header-container'>
                <div className='ewdashboard-header-div'>
                    {headertab}
                </div>
            </div>
        );
    }

    componentDidMount() {
        activeExceptionCategoryListStore.on("ActiveCategoryChanged", () => {
            this.setState({
                activeCategory: activeExceptionCategoryListStore.getActiveCategory()
            });
            Action.refereshCriticalitySummaryData(activeExceptionCategoryListStore.getActiveCategory());
            Action.refreshExceptionTableData(activeExceptionCategoryListStore.getActiveCategory(), exceptionSummaryDataStore.getActiveCriticalityValue());
        });
        activeExceptionCategoryListStore.on("ExceptionCountSummaryRefreshed", () => {
            this.setState({
                exceptionCountSummary: activeExceptionCategoryListStore.getExceptionCountSummary(),
            });
        });
        Action.refreshExceptionCountSummaryData(exceptionSummaryDataStore.getActiveCriticality());
    }

    componentWillUnmount() {
        activeExceptionCategoryListStore.removeListener("ActiveCategoryChanged", () => {
        });
        activeExceptionCategoryListStore.removeListener("ExceptionCountSummaryRefreshed", () => {
        });
    }

}