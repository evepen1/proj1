import React, { Component } from 'react';
import * as Action from '../../action/Actions';
import HelpCenterSearch from '../HelpCenter/HelpCenterSearch';
import ProductLines from '../HelpCenter/ProductLines';
import Faqs from '../HelpCenter/Faqs';
import WorkflowConfigration from './WorkflowConfigration';
import RolesConfigration from './RolesConfigration';
import userDetailDataStore from '../../store/userDetailDataStore';

export default class Setting extends Component {

    constructor() {
        super();
        this.state = {
            myAccessDisplay: false,
            workflowConfDisplay: false,
            rolesConfDisplay: false
        };
    }

    handleMyAccessClick() {
        this.setState({
            myAccessDisplay: !this.state.myAccessDisplay
        });
    }

    handleWorkflowConfClick() {
        this.setState({
            workflowConfDisplay: !this.state.workflowConfDisplay
        });
    }

    handleRolesConfClick() {
        this.setState({
            rolesConfDisplay: !this.state.rolesConfDisplay
        });
    }

    render() {
        let adminEnabledStyle = {
            display: 'none'
        };
        if (userDetailDataStore.getWorkflowConf().roles.indexOf('ADMIN_ROLE') > -1) {
            adminEnabledStyle.display = 'block';
        }
        let clientList = ' ';
        if (userDetailDataStore.getWorkflowConf().clients.indexOf('ALL') > -1) {
            userDetailDataStore.getClientList().forEach((item) => {
                clientList = ' ' + clientList + item + ', ';
            });
        }
        else {
            userDetailDataStore.getWorkflowConf().clients.forEach((item) => {
                clientList = ' ' + clientList + item + ', ';
            });
        }
        let roleList = ' ';
        userDetailDataStore.getWorkflowConf().roles.forEach((item) => {
            roleList = ' ' + roleList + item + ', ';
        });
        let stageList = ' ';
        userDetailDataStore.getWorkflowConf().stages.forEach((item, index) => {
            if (index > 0) {
                stageList = ' ' + stageList + item + ', ';
            }
        });
        if (roleList.length > 1) {
            roleList = roleList.substr(0, roleList.length - 2);
        }
        if (clientList.length > 1) {
            clientList = clientList.substr(0, clientList.length - 2);
        }
        if (stageList.length > 1) {
            stageList = stageList.substr(0, stageList.length - 2);
        }
        let myAccessStyle = {
            display: 'none',
            arrowStyle: {
                borderTop: '8px solid transparent',
                borderLeft: '13px solid #999'
            }
        };

        if (this.state.myAccessDisplay) {
            myAccessStyle.display = 'block';
            myAccessStyle.arrowStyle.borderLeft = '8px solid transparent';
            myAccessStyle.arrowStyle.borderTop = '13px solid #999';
        }
        let workflowConfStyle = {
            display: 'none',
            arrowStyle: {
                borderTop: '8px solid transparent',
                borderLeft: '13px solid #999'
            }
        };

        if (this.state.workflowConfDisplay && userDetailDataStore.getRoleList().indexOf('ADMIN_ROLE') > -1) {
            workflowConfStyle.display = 'block';
            workflowConfStyle.arrowStyle.borderLeft = '8px solid transparent';
            workflowConfStyle.arrowStyle.borderTop = '13px solid #999';
        }
        let rolesConfStyle = {
            display: 'none',
            arrowStyle: {
                borderTop: '8px solid transparent',
                borderLeft: '13px solid #999'
            }
        };

        if (this.state.rolesConfDisplay && userDetailDataStore.getRoleList().indexOf('ADMIN_ROLE') > -1) {
            rolesConfStyle.display = 'block';
            rolesConfStyle.arrowStyle.borderLeft = '8px solid transparent';
            rolesConfStyle.arrowStyle.borderTop = '13px solid #999';
        }
        return (
            <div>
                <div className='setting-container-div-white-overlay'>
                    <div className='setting-top-div-container'>
                        <div className='setting-top-top-div'>
                            <div className='setting-top-top-help-text-div'><i>Settings</i></div>
                            <div className='helpcenter-top-top-close-div' onClick={(e) => { this.props.closeSettingPopup(); }}>X</div>
                        </div>
                    </div>
                    <div className='setting-bottom-div-container'>
                        <div style={adminEnabledStyle} className='setting-detail-div-container'>
                            <div className='setting-detail-title-div-container' onClick={(e) => { this.handleWorkflowConfClick() }}>
                                <div style={workflowConfStyle.arrowStyle} className='setting-detail-arrow'>
                                </div>
                                User Configuration
                            </div>
                            <div style={workflowConfStyle} className='setting-detail-content-div-container'>
                                <WorkflowConfigration />
                            </div>
                        </div>
                        <div style={adminEnabledStyle} className='setting-detail-div-container'>
                            <div className='setting-detail-title-div-container' onClick={(e) => { this.handleRolesConfClick() }}>
                                <div style={rolesConfStyle.arrowStyle} className='setting-detail-arrow'>
                                </div>
                                Roles Configuration
                            </div>
                            <div style={rolesConfStyle} className='setting-detail-content-div-container'>
                                <RolesConfigration />
                            </div>
                        </div>
                        <div className='setting-detail-div-container'>
                            <div className='setting-detail-title-div-container' onClick={(e) => { this.handleMyAccessClick() }}>
                                <div style={myAccessStyle.arrowStyle} className='setting-detail-arrow'>
                                </div>
                                My Access
                            </div>
                            <div style={myAccessStyle} className='setting-detail-content-div-container'>
                                <table className='setting-myaccess-table'>
                                    <tbody>
                                        <tr className='setting-myaccess-table-tr'>
                                            <td>Client</td>
                                            <td>{clientList}</td>
                                        </tr>
                                        <tr className='setting-myaccess-table-tr'>
                                            <td>Stage</td>
                                            <td>{stageList}</td>
                                        </tr>
                                        <tr>
                                            <td>Roles</td>
                                            <td>{roleList}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='helpcenter-container-div-dark-overlay' onClick={(e) => { this.props.closeSettingPopup(); }}>

                </div>
            </div>
        );
    }

    componentDidMount() {
        Action.getRoleList();
        Action.getClientList();
    }

}