import React, { Component } from 'react';
import * as Action from '../../action/Actions';
import userDetailDataStore from '../../store/userDetailDataStore';

export default class WorkflowConfigration extends Component {
    constructor() {
        super();
        this.state = {
            roleOptions: ['SLI_OPS_USER', 'FSTP_OPS_USER', 'OMGI_OPS_USER'],
            clientOptions: userDetailDataStore.getClientList(),
            applicaitonOptions: ['TRADE CAPTURE', 'CONFIRMATION', 'ACCOUNTING', 'SETTLEMENT', 'DATA DELIVERY'],
            selectedClient: userDetailDataStore.getActiveClients(),
            selectedStage: userDetailDataStore.getActiveStagess(),
            selectedRole: 'SLI_OPS_USER',
        }
    }

    hadleClientSelectOnChange(e) {
        if (this.state.selectedClient.indexOf(e.target.value) > -1) {
            this.state.selectedClient.splice(this.state.selectedClient.indexOf(e.target.value), 1);
        }
        else {
            this.state.selectedClient.push(e.target.value);
        }
        this.setState({
            selectedClient: this.state.selectedClient
        });
    }
    hadleRoleSelectOnChange(e) {
        this.setState({
            selectedRole: e.target.value
        });
        Action.getClientAndStageForRole(e.target.value);
    }
    hadleStageSelectOnChange(e) {
        if (this.state.selectedStage.indexOf(e.target.value) > -1) {
            this.state.selectedStage.splice(this.state.selectedStage.indexOf(e.target.value), 1);
        }
        else {
            this.state.selectedStage.push(e.target.value);
        }
        this.setState({
            selectedStage: this.state.selectedStage
        });
    }

    handleRoleAddSaveClick() {
        Action.updateRoleConfiguration({
            selectedRole: this.state.selectedRole,
            selectedClients: this.state.selectedClient,
            selectedStages: this.state.selectedStage
        });
    }

    render() {
        let clientOptions = this.state.clientOptions.map((dropdownItem) => {
            if (this.state.selectedClient.indexOf(dropdownItem) > -1 || this.state.selectedClient.indexOf("ALL") > -1) {
                return (<div className='setting-clientoption-div'><input type='checkbox' key={dropdownItem} className='gfsmetricsdashboard-graphblock-option-dropdown-option'
                    onChange={(e) => { this.hadleClientSelectOnChange(e) }} checked value={dropdownItem} />{dropdownItem}</div>);
            }
            return (<div className='setting-clientoption-div'><input type='checkbox' key={dropdownItem} className='gfsmetricsdashboard-graphblock-option-dropdown-option'
                onChange={(e) => { this.hadleClientSelectOnChange(e) }} value={dropdownItem} />{dropdownItem}</div>);
        });
        let applicaitonOptions = this.state.applicaitonOptions.map(dropdownItem => {
            if (this.state.selectedStage.indexOf(dropdownItem) > -1) {
                return (<div className='setting-stageoption-div'><input type='checkbox' className='gfsmetricsdashboard-graphblock-option-dropdown-option'
                    onChange={(e) => { this.hadleStageSelectOnChange(e) }} checked value={dropdownItem} />{dropdownItem}</div>);
            }
            return (<div className='setting-stageoption-div'><input type='checkbox' className='gfsmetricsdashboard-graphblock-option-dropdown-option'
                onChange={(e) => { this.hadleStageSelectOnChange(e) }} value={dropdownItem} />{dropdownItem}</div>);
        });

        let roleOptions = this.state.roleOptions.map(dropdownItem => {
            if (dropdownItem === this.state.selectedStage) {
                return (<option className='gfsmetricsdashboard-graphblock-option-dropdown-option' selected value={dropdownItem}>{dropdownItem}</option>);
            }
            return (<option className='gfsmetricsdashboard-graphblock-option-dropdown-option' value={dropdownItem}>{dropdownItem}</option>);
        });

        return (
            <div className='workfloW-configration-top-div'>
                <div className='workfloW-configration-bottom-content-div'>
                    <table>
                        <tbody>
                            <tr>
                                <td className='setting-table-td' colSpan='1'>Roles</td>
                                <td className='setting-table-td'>
                                    <select className='settin-status-dropdown' onChange={(e) => { this.hadleRoleSelectOnChange(e) }}>
                                        {roleOptions}
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td className='setting-table-td' colSpan='1'>Client</td>
                                <td className='setting-table-td'>
                                    <div className='setting-checkbox-container'>
                                        {clientOptions}
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td className='setting-table-td' colSpan='1'>Application</td>
                                <td className='setting-table-td'>
                                    <div className='setting-checkbox-container'>
                                        {applicaitonOptions}
                                    </div>
                                </td>
                            </tr>
                            <td className='setting-table-td' colSpan='2' ><input type="button" className='setting-td-button'
                                value='Save' onClick={(e) => { this.handleRoleAddSaveClick() }} /></td>
                        </tbody>
                    </table>
                </div>
            </div >
        );
    }

    componentDidMount() {
        userDetailDataStore.on("RolelistRefreshed", () => {
            this.setState({
                roleOptions: userDetailDataStore.getRoleList()
            });
            Action.getClientAndStageForRole(userDetailDataStore.getRoleList()[0]);
        });
        userDetailDataStore.on("ClientStageListRefreshed", () => {
            this.setState({
                selectedClient: userDetailDataStore.getActiveClients(),
                selectedStage: userDetailDataStore.getActiveStagess()
            });
        });
        userDetailDataStore.on("ClientListRefreshed", () => {
            this.setState({
                clientOptions: userDetailDataStore.getClientList()
            });
        });
    }

    componentWillUnmount() {
        userDetailDataStore.removeListener("RolelistRefreshed", () => {
        });
        userDetailDataStore.removeListener("ClientStageListRefreshed", () => {
        });
        userDetailDataStore.removeListener("ClientListRefreshed", () => {
        });
    }
}