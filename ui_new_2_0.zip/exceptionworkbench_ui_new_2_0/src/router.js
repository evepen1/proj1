import React, { Component } from 'react';
import { Router, Route, IndexRoute, hashHistory } from 'react-router';
import NavigationPanel from './navigationPanel';
import NAVNavigationPanel from './navNavigationPanel';
import ETFNavigationPanel from './etfNavigationPanel';
import TSNavigationPanel from './tsNavigationPanel';
import LoginPanel from './loginPanel.js';
import LoginScreen from './component/Login/Login.js';
import EwDashboard from './component/EwDashboard/EwDashboard.js';
import HomePage from './component/Home/HomePage.js';
import AborNav from './component/AborNav/AborNav';
import NavUpstream from './component/NavUpstream/NavUpstream';
import ETFDashboard from './component/ETF/ETFDashboard';
import TradeState from './component/TradeState/TradeState';
import GfsMetricsDashboard from './component/GfsMetricsDashboard/GfsMetricsDashboard.js';
import RankingMetricsDashboard from './component/RankingDashboard/RankingDashboard.js';
import ExceptionPredictabilityDashboard from './component/ExceptionPredictabilityDashboard/ExceptionPredictabilityDashboard';
import DynamicDash from './component/DynamicDash/DynamicDash.js';

export default class Routing extends Component {

  render() {
    return (
      <Router history={hashHistory}>
        <Route path='/' component={LoginPanel}>
          <IndexRoute component={LoginScreen}></IndexRoute>
          <Route path='login' component={LoginScreen} ></Route>
        </Route>
        <Route path='/home' component={LoginPanel}>
          <IndexRoute component={HomePage}></IndexRoute>
        </Route>
        <Route path='/app' component={NavigationPanel}>
          <IndexRoute component={EwDashboard}></IndexRoute>
          <Route path='ewdashboard' component={EwDashboard} ></Route>
                    <Route path='tradestate' component={TradeState} ></Route>
          <Route path='gfsMetricsDashboard' component={GfsMetricsDashboard} ></Route>
          <Route path='rankingMetricsDashboard' component={RankingMetricsDashboard} ></Route>
          <Route path='exceptionAnalyticsDashboard' component={ExceptionPredictabilityDashboard} ></Route>
          <Route path="dynamic/:page" component={DynamicDash} />
        </Route>
        <Route path='/nav' component={NAVNavigationPanel}>
          <IndexRoute component={NavUpstream}></IndexRoute>
          <Route path='navupstream' component={NavUpstream} ></Route>
          <Route path='abornav' component={AborNav} ></Route>
        </Route>
          <Route path='/etf' component={ETFNavigationPanel}>
          <IndexRoute component={ETFDashboard}></IndexRoute>
          <Route path='etfdash' component={ETFDashboard} ></Route>
        </Route>
      </Router>
    );
  }
}
