import React, { Component } from 'react';

export default class LoginPanel extends Component {

    render() {
        return (
            <div className= 'app-login-div'>
                    {this.props.children}
            </div>
        );
    }
}