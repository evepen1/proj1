import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'
import DynamicDashboard from '../component//GfsMetricsDashboard/DynamicDashboard';

class DynamicDashboardTabDataStore extends EventEmitter {
    constructor() {
        super();
        this.data = {
            dynamicTab: [
                { name: 'Dash 1', property: DynamicDashboard, link: 'dash1' },
                { name: 'Dash 2', property: DynamicDashboard, link: 'dash2' },
                { name: 'Dash 3', property: DynamicDashboard, link: 'dash3' },
            ]
        };
    }

    changeTabData(action) {
        switch (action.type) {
            case "TEMP_D": {

            }
        }
    }

    getDynamicTabData() {
        return this.data.dynamicTab;
    }

}

const dynamicDashboardTabDataStore = new DynamicDashboardTabDataStore;
ActionDispatcher.register(dynamicDashboardTabDataStore.changeTabData.bind(dynamicDashboardTabDataStore));
export default dynamicDashboardTabDataStore;