import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'

class RankingMetricsDataStore extends EventEmitter {

    constructor() {
        super();
        this.data = {
            rankingMetricsData: {
                tradevolume: {
                    firm: {
                        weekly: {
                            categories: ['week 1', 'week 2', 'week 3', 'week 4'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'fstp' }, { y: 953, z: 'sli' }, { y: 901, z: 'fstp' }, { y: 784, z: 'dfa' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'sli' }, { y: 745, z: 'dfa' }, { y: 873, z: 'hsbc' }, { y: 707, z: 'sli' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'dfa' }, { y: 598, z: 'hsbc' }, { y: 635, z: 'dfa' }, { y: 699, z: 'hsbc' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'omgi' }, { y: 346, z: 'omgi' }, { y: 523, z: 'omgi' }, { y: 590, z: 'fstp' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'hsbc' }, { y: 242, z: 'fstp' }, { y: 489, z: 'sli' }, { y: 432, z: 'omgi' }]
                                }
                            ]
                        },
                        monthly: {
                            categories: ['MAR', 'APR', 'MAY', 'JUN'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'fstp' }, { y: 953, z: 'sli' }, { y: 901, z: 'fstp' }, { y: 784, z: 'dfa' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'sli' }, { y: 745, z: 'dfa' }, { y: 873, z: 'hsbc' }, { y: 707, z: 'sli' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'dfa' }, { y: 598, z: 'hsbc' }, { y: 635, z: 'dfa' }, { y: 699, z: 'hsbc' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'omgi' }, { y: 346, z: 'omgi' }, { y: 523, z: 'omgi' }, { y: 590, z: 'fstp' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'hsbc' }, { y: 242, z: 'fstp' }, { y: 489, z: 'sli' }, { y: 432, z: 'omgi' }]
                                }
                            ]
                        },
                        yearly: {
                            categories: ['2013', '2014', '2015', '2016'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'fstp' }, { y: 953, z: 'sli' }, { y: 901, z: 'fstp' }, { y: 784, z: 'dfa' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'sli' }, { y: 745, z: 'dfa' }, { y: 873, z: 'hsbc' }, { y: 707, z: 'sli' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'dfa' }, { y: 598, z: 'hsbc' }, { y: 635, z: 'dfa' }, { y: 699, z: 'hsbc' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'omgi' }, { y: 346, z: 'omgi' }, { y: 523, z: 'omgi' }, { y: 590, z: 'fstp' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'hsbc' }, { y: 242, z: 'fstp' }, { y: 489, z: 'sli' }, { y: 432, z: 'omgi' }]
                                }
                            ]
                        }
                    },
                    broker: {
                        weekly: {
                            categories: ['week 1', 'week 2', 'week 3', 'week 4'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'LIBER11' }, { y: 953, z: 'BOFAX' }, { y: 901, z: 'BROINK' }, { y: 784, z: 'MELFUT' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'BOFAX' }, { y: 745, z: 'MELFUT' }, { y: 873, z: 'LIBER11' }, { y: 707, z: 'TCSSLIC' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'MELFUT' }, { y: 598, z: 'LIBER11' }, { y: 635, z: 'TCSSLIC' }, { y: 699, z: 'BROINK' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'BROINK' }, { y: 346, z: 'TCSSLIC' }, { y: 523, z: 'BOFAX' }, { y: 590, z: 'BOFAX' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'TCSSLIC' }, { y: 242, z: 'BROINK' }, { y: 489, z: 'MELFUT' }, { y: 432, z: 'LIBER11' }]
                                }
                            ]
                        },
                        monthly: {
                            categories: ['MAR', 'APR', 'MAY', 'JUN'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'LIBER11' }, { y: 953, z: 'BOFAX' }, { y: 901, z: 'BROINK' }, { y: 784, z: 'MELFUT' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'BOFAX' }, { y: 745, z: 'MELFUT' }, { y: 873, z: 'LIBER11' }, { y: 707, z: 'TCSSLIC' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'MELFUT' }, { y: 598, z: 'LIBER11' }, { y: 635, z: 'TCSSLIC' }, { y: 699, z: 'BROINK' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'BROINK' }, { y: 346, z: 'TCSSLIC' }, { y: 523, z: 'BOFAX' }, { y: 590, z: 'BOFAX' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'TCSSLIC' }, { y: 242, z: 'BROINK' }, { y: 489, z: 'MELFUT' }, { y: 432, z: 'LIBER11' }]
                                }
                            ]
                        },
                        yearly: {
                            categories: ['2013', '2014', '2015', '2016'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'LIBER11' }, { y: 953, z: 'BOFAX' }, { y: 901, z: 'BROINK' }, { y: 784, z: 'MELFUT' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'BOFAX' }, { y: 745, z: 'MELFUT' }, { y: 873, z: 'LIBER11' }, { y: 707, z: 'TCSSLIC' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'MELFUT' }, { y: 598, z: 'LIBER11' }, { y: 635, z: 'TCSSLIC' }, { y: 699, z: 'BROINK' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'BROINK' }, { y: 346, z: 'TCSSLIC' }, { y: 523, z: 'BOFAX' }, { y: 590, z: 'BOFAX' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'TCSSLIC' }, { y: 242, z: 'BROINK' }, { y: 489, z: 'MELFUT' }, { y: 432, z: 'LIBER11' }]
                                }
                            ]
                        }
                    }
                },
                netassetvalue: {
                    firm: {
                        weekly: {
                            categories: ['week 1', 'week 2', 'week 3', 'week 4'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'fstp' }, { y: 953, z: 'sli' }, { y: 901, z: 'fstp' }, { y: 784, z: 'dfa' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'sli' }, { y: 745, z: 'dfa' }, { y: 873, z: 'hsbc' }, { y: 707, z: 'sli' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'dfa' }, { y: 598, z: 'hsbc' }, { y: 635, z: 'dfa' }, { y: 699, z: 'hsbc' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'omgi' }, { y: 346, z: 'omgi' }, { y: 523, z: 'omgi' }, { y: 590, z: 'fstp' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'hsbc' }, { y: 242, z: 'fstp' }, { y: 489, z: 'sli' }, { y: 432, z: 'omgi' }]
                                }
                            ]
                        },
                        monthly: {
                            categories: ['MAR', 'APR', 'MAY', 'JUN'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'fstp' }, { y: 953, z: 'sli' }, { y: 901, z: 'fstp' }, { y: 784, z: 'dfa' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'sli' }, { y: 745, z: 'dfa' }, { y: 873, z: 'hsbc' }, { y: 707, z: 'sli' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'dfa' }, { y: 598, z: 'hsbc' }, { y: 635, z: 'dfa' }, { y: 699, z: 'hsbc' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'omgi' }, { y: 346, z: 'omgi' }, { y: 523, z: 'omgi' }, { y: 590, z: 'fstp' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'hsbc' }, { y: 242, z: 'fstp' }, { y: 489, z: 'sli' }, { y: 432, z: 'omgi' }]
                                }
                            ]
                        },
                        yearly: {
                            categories: ['2013', '2014', '2015', '2016'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'fstp' }, { y: 953, z: 'sli' }, { y: 901, z: 'fstp' }, { y: 784, z: 'dfa' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'sli' }, { y: 745, z: 'dfa' }, { y: 873, z: 'hsbc' }, { y: 707, z: 'sli' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'dfa' }, { y: 598, z: 'hsbc' }, { y: 635, z: 'dfa' }, { y: 699, z: 'hsbc' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'omgi' }, { y: 346, z: 'omgi' }, { y: 523, z: 'omgi' }, { y: 590, z: 'fstp' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'hsbc' }, { y: 242, z: 'fstp' }, { y: 489, z: 'sli' }, { y: 432, z: 'omgi' }]
                                }
                            ]
                        }
                    },
                    broker: {
                        weekly: {
                            categories: ['week 1', 'week 2', 'week 3', 'week 4'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'LIBER11' }, { y: 953, z: 'BOFAX' }, { y: 901, z: 'BROINK' }, { y: 784, z: 'MELFUT' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'BOFAX' }, { y: 745, z: 'MELFUT' }, { y: 873, z: 'LIBER11' }, { y: 707, z: 'TCSSLIC' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'MELFUT' }, { y: 598, z: 'LIBER11' }, { y: 635, z: 'TCSSLIC' }, { y: 699, z: 'BROINK' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'BROINK' }, { y: 346, z: 'TCSSLIC' }, { y: 523, z: 'BOFAX' }, { y: 590, z: 'BOFAX' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'TCSSLIC' }, { y: 242, z: 'BROINK' }, { y: 489, z: 'MELFUT' }, { y: 432, z: 'LIBER11' }]
                                }
                            ]
                        },
                        monthly: {
                            categories: ['MAR', 'APR', 'MAY', 'JUN'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'LIBER11' }, { y: 953, z: 'BOFAX' }, { y: 901, z: 'BROINK' }, { y: 784, z: 'MELFUT' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'BOFAX' }, { y: 745, z: 'MELFUT' }, { y: 873, z: 'LIBER11' }, { y: 707, z: 'TCSSLIC' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'MELFUT' }, { y: 598, z: 'LIBER11' }, { y: 635, z: 'TCSSLIC' }, { y: 699, z: 'BROINK' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'BROINK' }, { y: 346, z: 'TCSSLIC' }, { y: 523, z: 'BOFAX' }, { y: 590, z: 'BOFAX' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'TCSSLIC' }, { y: 242, z: 'BROINK' }, { y: 489, z: 'MELFUT' }, { y: 432, z: 'LIBER11' }]
                                }
                            ]
                        },
                        yearly: {
                            categories: ['2013', '2014', '2015', '2016'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'LIBER11' }, { y: 953, z: 'BOFAX' }, { y: 901, z: 'BROINK' }, { y: 784, z: 'MELFUT' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'BOFAX' }, { y: 745, z: 'MELFUT' }, { y: 873, z: 'LIBER11' }, { y: 707, z: 'TCSSLIC' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'MELFUT' }, { y: 598, z: 'LIBER11' }, { y: 635, z: 'TCSSLIC' }, { y: 699, z: 'BROINK' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'BROINK' }, { y: 346, z: 'TCSSLIC' }, { y: 523, z: 'BOFAX' }, { y: 590, z: 'BOFAX' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'TCSSLIC' }, { y: 242, z: 'BROINK' }, { y: 489, z: 'MELFUT' }, { y: 432, z: 'LIBER11' }]
                                }
                            ]
                        }
                    }
                },
                percentagestp: {
                    firm: {
                        weekly: {
                            categories: ['week 1', 'week 2', 'week 3', 'week 4'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'fstp' }, { y: 953, z: 'sli' }, { y: 901, z: 'fstp' }, { y: 784, z: 'dfa' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'sli' }, { y: 745, z: 'dfa' }, { y: 873, z: 'hsbc' }, { y: 707, z: 'sli' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'dfa' }, { y: 598, z: 'hsbc' }, { y: 635, z: 'dfa' }, { y: 699, z: 'hsbc' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'omgi' }, { y: 346, z: 'omgi' }, { y: 523, z: 'omgi' }, { y: 590, z: 'fstp' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'hsbc' }, { y: 242, z: 'fstp' }, { y: 489, z: 'sli' }, { y: 432, z: 'omgi' }]
                                }
                            ]
                        },
                        monthly: {
                            categories: ['MAR', 'APR', 'MAY', 'JUN'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'fstp' }, { y: 953, z: 'sli' }, { y: 901, z: 'fstp' }, { y: 784, z: 'dfa' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'sli' }, { y: 745, z: 'dfa' }, { y: 873, z: 'hsbc' }, { y: 707, z: 'sli' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'dfa' }, { y: 598, z: 'hsbc' }, { y: 635, z: 'dfa' }, { y: 699, z: 'hsbc' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'omgi' }, { y: 346, z: 'omgi' }, { y: 523, z: 'omgi' }, { y: 590, z: 'fstp' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'hsbc' }, { y: 242, z: 'fstp' }, { y: 489, z: 'sli' }, { y: 432, z: 'omgi' }]
                                }
                            ]
                        },
                        yearly: {
                            categories: ['2013', '2014', '2015', '2016'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'LIBER11' }, { y: 953, z: 'BOFAX' }, { y: 901, z: 'BROINK' }, { y: 784, z: 'MELFUT' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'BOFAX' }, { y: 745, z: 'MELFUT' }, { y: 873, z: 'LIBER11' }, { y: 707, z: 'TCSSLIC' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'MELFUT' }, { y: 598, z: 'LIBER11' }, { y: 635, z: 'TCSSLIC' }, { y: 699, z: 'BROINK' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'BROINK' }, { y: 346, z: 'TCSSLIC' }, { y: 523, z: 'BOFAX' }, { y: 590, z: 'BOFAX' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'TCSSLIC' }, { y: 242, z: 'BROINK' }, { y: 489, z: 'MELFUT' }, { y: 432, z: 'LIBER11' }]
                                }
                            ]
                        }
                    },
                    broker: {
                        weekly: {
                            categories: ['week 1', 'week 2', 'week 3', 'week 4'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'LIBER11' }, { y: 953, z: 'BOFAX' }, { y: 901, z: 'BROINK' }, { y: 784, z: 'MELFUT' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'BOFAX' }, { y: 745, z: 'MELFUT' }, { y: 873, z: 'LIBER11' }, { y: 707, z: 'TCSSLIC' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'MELFUT' }, { y: 598, z: 'LIBER11' }, { y: 635, z: 'TCSSLIC' }, { y: 699, z: 'BROINK' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'BROINK' }, { y: 346, z: 'TCSSLIC' }, { y: 523, z: 'BOFAX' }, { y: 590, z: 'BOFAX' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'TCSSLIC' }, { y: 242, z: 'BROINK' }, { y: 489, z: 'MELFUT' }, { y: 432, z: 'LIBER11' }]
                                }
                            ]
                        },
                        monthly: {
                            categories: ['MAR', 'APR', 'MAY', 'JUN'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'LIBER11' }, { y: 953, z: 'BOFAX' }, { y: 901, z: 'BROINK' }, { y: 784, z: 'MELFUT' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'BOFAX' }, { y: 745, z: 'MELFUT' }, { y: 873, z: 'LIBER11' }, { y: 707, z: 'TCSSLIC' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'MELFUT' }, { y: 598, z: 'LIBER11' }, { y: 635, z: 'TCSSLIC' }, { y: 699, z: 'BROINK' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'BROINK' }, { y: 346, z: 'TCSSLIC' }, { y: 523, z: 'BOFAX' }, { y: 590, z: 'BOFAX' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'TCSSLIC' }, { y: 242, z: 'BROINK' }, { y: 489, z: 'MELFUT' }, { y: 432, z: 'LIBER11' }]
                                }
                            ]
                        },
                        yearly: {
                            categories: ['2013', '2014', '2015', '2016'],
                            values: [
                                {
                                    name: '1st',
                                    data: [{ y: 874, z: 'LIBER11' }, { y: 953, z: 'BOFAX' }, { y: 901, z: 'BROINK' }, { y: 784, z: 'MELFUT' }]

                                }, {
                                    name: '2nd',
                                    data: [{ y: 634, z: 'BOFAX' }, { y: 745, z: 'MELFUT' }, { y: 873, z: 'LIBER11' }, { y: 707, z: 'TCSSLIC' }]
                                }, {
                                    name: '3rd',
                                    data: [{ y: 621, z: 'MELFUT' }, { y: 598, z: 'LIBER11' }, { y: 635, z: 'TCSSLIC' }, { y: 699, z: 'BROINK' }]
                                }, {
                                    name: '4th',
                                    data: [{ y: 548, z: 'BROINK' }, { y: 346, z: 'TCSSLIC' }, { y: 523, z: 'BOFAX' }, { y: 590, z: 'BOFAX' }]
                                }, {
                                    name: '5th',
                                    data: [{ y: 490, z: 'TCSSLIC' }, { y: 242, z: 'BROINK' }, { y: 489, z: 'MELFUT' }, { y: 432, z: 'LIBER11' }]
                                }
                            ]
                        }
                    }
                 }
                // exceptionsresolved: {
                //     ops: {
                //         weekly: {
                //             categories: ['week 1', 'week 2', 'week 3', 'week 4'],
                //             values: [
                //                 {
                //                     name: '1st',
                //                     data: [{ y: 67, z: 'Barry Grist' }, { y: 76, z: 'Michelle Kennedy' }, { y: 78, z: 'Barry Grist' }, { y: 89, z: 'Radoslaw Wasilewski' }]

                //                 }, {
                //                     name: '2nd',
                //                     data: [{ y: 56, z: 'Michelle Kennedy' }, { y: 65, z: 'Radoslaw Wasilewski' }, { y: 76, z: 'Krzysztof Korecki' }, { y: 70, z: 'Michelle Kennedy' }]
                //                 }, {
                //                     name: '3rd',
                //                     data: [{ y: 54, z: 'Radoslaw Wasilewski' }, { y: 61, z: 'Krzysztof Korecki' }, { y: 75, z: 'Radoslaw Wasilewski' }, { y: 69, z: 'Krzysztof Korecki' }]
                //                 }, {
                //                     name: '4th',
                //                     data: [{ y: 43, z: 'Michal Wyrzykowski' }, { y: 56, z: 'Michal Wyrzykowski' }, { y: 65, z: 'Michal Wyrzykowski' }, { y: 59, z: 'Barry Grist' }]
                //                 }, {
                //                     name: '5th',
                //                     data: [{ y: 42, z: 'Krzysztof Korecki' }, { y: 46, z: 'Barry Grist' }, { y: 61, z: 'Michelle Kennedy' }, { y: 50, z: 'Michal Wyrzykowski' }]
                //                 }
                //             ]
                //         },
                //         monthly: {
                //             categories: ['MAR', 'APR', 'MAY', 'JUN'],
                //             values: [
                //                 {
                //                     name: '1st',
                //                     data: [{ y: 874, z: 'Barry Grist' }, { y: 953, z: 'Michelle Kennedy' }, { y: 901, z: 'Barry Grist' }, { y: 784, z: 'Radoslaw Wasilewski' }]

                //                 }, {
                //                     name: '2nd',
                //                     data: [{ y: 634, z: 'Michelle Kennedy' }, { y: 745, z: 'Radoslaw Wasilewski' }, { y: 873, z: 'Krzysztof Korecki' }, { y: 707, z: 'Michelle Kennedy' }]
                //                 }, {
                //                     name: '3rd',
                //                     data: [{ y: 621, z: 'Radoslaw Wasilewski' }, { y: 598, z: 'Krzysztof Korecki' }, { y: 635, z: 'Radoslaw Wasilewski' }, { y: 699, z: 'Krzysztof Korecki' }]
                //                 }, {
                //                     name: '4th',
                //                     data: [{ y: 548, z: 'Michal Wyrzykowski' }, { y: 346, z: 'Michal Wyrzykowski' }, { y: 523, z: 'Michal Wyrzykowski' }, { y: 590, z: 'Barry Grist' }]
                //                 }, {
                //                     name: '5th',
                //                     data: [{ y: 490, z: 'Krzysztof Korecki' }, { y: 242, z: 'Barry Grist' }, { y: 489, z: 'Michelle Kennedy' }, { y: 432, z: 'Michal Wyrzykowski' }]
                //                 }
                //             ]
                //         },
                //         yearly: {
                //             categories: ['2013', '2014', '2015', '2016'],
                //             values: [
                //                 {
                //                     name: '1st',
                //                     data: [{ y: 8704, z: 'Barry Grist' }, { y: 9553, z: 'Michelle Kennedy' }, { y: 9021, z: 'Barry Grist' }, { y: 7844, z: 'Radoslaw Wasilewski' }]

                //                 }, {
                //                     name: '2nd',
                //                     data: [{ y: 6374, z: 'Michelle Kennedy' }, { y: 7345, z: 'Radoslaw Wasilewski' }, { y: 8753, z: 'Krzysztof Korecki' }, { y: 7107, z: 'Michelle Kennedy' }]
                //                 }, {
                //                     name: '3rd',
                //                     data: [{ y: 6251, z: 'Radoslaw Wasilewski' }, { y: 5968, z: 'Krzysztof Korecki' }, { y: 6325, z: 'Radoslaw Wasilewski' }, { y: 6949, z: 'Krzysztof Korecki' }]
                //                 }, {
                //                     name: '4th',
                //                     data: [{ y: 5948, z: 'Michal Wyrzykowski' }, { y: 3436, z: 'Michal Wyrzykowski' }, { y: 5623, z: 'Michal Wyrzykowski' }, { y: 5910, z: 'Barry Grist' }]
                //                 }, {
                //                     name: '5th',
                //                     data: [{ y: 4950, z: 'Krzysztof Korecki' }, { y: 2542, z: 'Barry Grist' }, { y: 4839, z: 'Michelle Kennedy' }, { y: 4342, z: 'Michal Wyrzykowski' }]
                //                 }
                //             ]
                //         }
                //     }
                // },
                // avgexceptionresolutiontime: {
                //     ops: {
                //         weekly: {
                //             categories: ['week 1', 'week 2', 'week 3', 'week 4'],
                //             values: [
                //                 {
                //                     name: '1st',
                //                     data: [{ y: 874, z: 'Barry Grist' }, { y: 953, z: 'Michelle Kennedy' }, { y: 901, z: 'Barry Grist' }, { y: 784, z: 'Radoslaw Wasilewski' }]

                //                 }, {
                //                     name: '2nd',
                //                     data: [{ y: 634, z: 'Michelle Kennedy' }, { y: 745, z: 'Radoslaw Wasilewski' }, { y: 873, z: 'Krzysztof Korecki' }, { y: 707, z: 'Michelle Kennedy' }]
                //                 }, {
                //                     name: '3rd',
                //                     data: [{ y: 621, z: 'Radoslaw Wasilewski' }, { y: 598, z: 'Krzysztof Korecki' }, { y: 635, z: 'Radoslaw Wasilewski' }, { y: 699, z: 'Krzysztof Korecki' }]
                //                 }, {
                //                     name: '4th',
                //                     data: [{ y: 548, z: 'Michal Wyrzykowski' }, { y: 346, z: 'Michal Wyrzykowski' }, { y: 523, z: 'Michal Wyrzykowski' }, { y: 590, z: 'Barry Grist' }]
                //                 }, {
                //                     name: '5th',
                //                     data: [{ y: 490, z: 'Krzysztof Korecki' }, { y: 242, z: 'Barry Grist' }, { y: 489, z: 'Michelle Kennedy' }, { y: 432, z: 'Michal Wyrzykowski' }]
                //                 }
                //             ]
                //         },
                //         monthly: {
                //             categories: ['MAR', 'APR', 'MAY', 'JUN'],
                //             values: [
                //                 {
                //                     name: '1st',
                //                     data: [{ y: 874, z: 'Barry Grist' }, { y: 953, z: 'Michelle Kennedy' }, { y: 901, z: 'Barry Grist' }, { y: 784, z: 'Radoslaw Wasilewski' }]

                //                 }, {
                //                     name: '2nd',
                //                     data: [{ y: 634, z: 'Michelle Kennedy' }, { y: 745, z: 'Radoslaw Wasilewski' }, { y: 873, z: 'Krzysztof Korecki' }, { y: 707, z: 'Michelle Kennedy' }]
                //                 }, {
                //                     name: '3rd',
                //                     data: [{ y: 621, z: 'Radoslaw Wasilewski' }, { y: 598, z: 'Krzysztof Korecki' }, { y: 635, z: 'Radoslaw Wasilewski' }, { y: 699, z: 'Krzysztof Korecki' }]
                //                 }, {
                //                     name: '4th',
                //                     data: [{ y: 548, z: 'Michal Wyrzykowski' }, { y: 346, z: 'Michal Wyrzykowski' }, { y: 523, z: 'Michal Wyrzykowski' }, { y: 590, z: 'Barry Grist' }]
                //                 }, {
                //                     name: '5th',
                //                     data: [{ y: 490, z: 'Krzysztof Korecki' }, { y: 242, z: 'Barry Grist' }, { y: 489, z: 'Michelle Kennedy' }, { y: 432, z: 'Michal Wyrzykowski' }]
                //                 }
                //             ]
                //         },
                //         yearly: {
                //             categories: ['2013', '2014', '2015', '2016'],
                //             values: [
                //                 {
                //                     name: '1st',
                //                     data: [{ y: 874, z: 'Barry Grist' }, { y: 953, z: 'Michelle Kennedy' }, { y: 901, z: 'Barry Grist' }, { y: 784, z: 'Radoslaw Wasilewski' }]

                //                 }, {
                //                     name: '2nd',
                //                     data: [{ y: 634, z: 'Michelle Kennedy' }, { y: 745, z: 'Radoslaw Wasilewski' }, { y: 873, z: 'Krzysztof Korecki' }, { y: 707, z: 'Michelle Kennedy' }]
                //                 }, {
                //                     name: '3rd',
                //                     data: [{ y: 621, z: 'Radoslaw Wasilewski' }, { y: 598, z: 'Krzysztof Korecki' }, { y: 635, z: 'Radoslaw Wasilewski' }, { y: 699, z: 'Krzysztof Korecki' }]
                //                 }, {
                //                     name: '4th',
                //                     data: [{ y: 548, z: 'Michal Wyrzykowski' }, { y: 346, z: 'Michal Wyrzykowski' }, { y: 523, z: 'Michal Wyrzykowski' }, { y: 590, z: 'Barry Grist' }]
                //                 }, {
                //                     name: '5th',
                //                     data: [{ y: 490, z: 'Krzysztof Korecki' }, { y: 242, z: 'Barry Grist' }, { y: 489, z: 'Michelle Kennedy' }, { y: 432, z: 'Michal Wyrzykowski' }]
                //                 }
                //             ]
                //         }
                //     }
                // }
            }
        }
    }

    changeRankingMetricsData(action) {
        switch (action.type) {

        }
    }

    getRankingMetricsData() {
        return this.data.rankingMetricsData;
    }

}


const rankingMetricsDataStore = new RankingMetricsDataStore;
ActionDispatcher.register(rankingMetricsDataStore.changeRankingMetricsData.bind(rankingMetricsDataStore));
export default rankingMetricsDataStore;