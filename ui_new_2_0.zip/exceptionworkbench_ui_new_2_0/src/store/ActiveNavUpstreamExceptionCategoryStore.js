import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'
import userDetailDataStore from './userDetailDataStore'

class ActiveNavUpstreamExceptionCategoryStore extends EventEmitter {
  constructor() {
    super();
    this.data = {
      exceptionCountSummary: { "PRICING": { "type": "CRITICAL", "count": 0 }, 
      "CONFIRMATION": { "type": "CRITICAL", "count": 0 },
       "DATA DELIVERY": { "type": "CRITICAL", "count": 0 },
        "SETTLEMENT": { "type": "CRITICAL", "count": 0 }, 
        "ACCOUNTING": { "type": "CRITICAL", "count": 0 },
         "TRADE CAPTURE": { "type": "CRITICAL", "count": 0 } },
      activeCategory: 'all',
      headerLookup: [
        { value: 'all', cssTag: 'showall', name: 'All' },
        { value: 'Trade_Capture', cssTag: 'tc', name: 'TRADE CAPTURE' },
        { value: 'Confirmation', cssTag: 'c', name: 'Confirmation' },
        { value: 'Accounting', cssTag: 'a', name: 'Accounting' },
         { value: 'Pricing', cssTag: 'p', name: 'Pricing' },
        { value: 'Settlement', cssTag: 's', name: 'Settlement' },
        // { value: 'Data_Delivery', cssTag: 'dd', name: 'Data Delivery' }
      ]
    };
  }

  changeActiveCategory(action) {
    switch (action.type) {
      case 'CATEGORY_CHANGED': {
        //  console.log("CATEGORY_CHANGED");
        this.data.activeCategory = action.text;
        this.emit("ActiveCategoryChanged");
        break;
      }
      case 'EXCEPTION_COUNT_SUMMARY_REFRESH': {
        //   console.log("EXCEPTION_COUNT_SUMMARY_REFRESH");
        this.data.exceptionCountSummary = action.text;
        this.emit("ExceptionCountSummaryRefreshed");
        break;
      }
    }
  }

  getActiveCategory() {
    return this.data.activeCategory;
  }

  getHeaderLookup() {
    let headerLookup= this.data.headerLookup.filter((item) => {
      return userDetailDataStore.getWorkflowConf().stages.indexOf(item.name.toUpperCase()) > -1
    });
    return headerLookup;
  }

  getExceptionCountSummary() {
    return this.data.exceptionCountSummary;
  }


}

const activeNavUpstreamExceptionCategoryStore = new ActiveNavUpstreamExceptionCategoryStore;
ActionDispatcher.register(activeNavUpstreamExceptionCategoryStore.changeActiveCategory.bind(activeNavUpstreamExceptionCategoryStore));
export default activeNavUpstreamExceptionCategoryStore;
