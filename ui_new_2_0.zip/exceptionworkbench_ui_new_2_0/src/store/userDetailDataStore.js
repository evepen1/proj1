import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'
import DynamicDashboard from '../component/GfsMetricsDashboard/DynamicDashboard';
import RankingDynamicDashboard from '../component/RankingDashboard/RankingDynamicDashboard';
import { hashHistory } from 'react-router';

class UserDetailDataStore extends EventEmitter {
    constructor() {
        super();
        this.data = {
            workflowConf: {
                clients: [],
                stages: [],
                roles: []
            },
            userid: '',
            userName: '',
            userlist: [],
            activeClients: ['SLI'],
            clientFilter: 'All',
            slaFilter: 'All',
            slaList: ['Critical SLA', 'SLA', 'Trade Volume', 'Fund NAV'],
            activeStages: ['Trade Capture'],
            clientList: ['SLI', 'KAMES', 'OMGI', 'FSTP', 'TNA', 'CAL', 'DFA', 'AAM', 'AIA'],
            rolelist: ['SLI_OPS_USER', 'FSTP_OPS_USER', 'OMGI_OPS_USER'],
            businessOpsTeam: [{ userId: 'bg25014', userName: 'Barry Grist' }, { userId: 'mk25071', userName: 'Michelle Kennedy' }],
            gfsMetricsDashboardConfTemp: [
                {
                    typeSelected: 'processingtime',
                    basisSelected: 'client',
                    criticalitySelected: null,
                    checkedList: [],
                    durationSelected: 'Weekly',
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'processingvolume',
                    basisSelected: 'stptype',
                    criticalitySelected: null,
                    checkedList: [],
                    durationSelected: 'Monthly',
                    editEnabled: false,
                    typeOfGraph: 'bar'
                },
                {
                    typeSelected: 'exceptionvolume',
                    basisSelected: 'asset',
                    criticalitySelected: 'high',
                    checkedList: ['future', 'depo', 'cash', 'abs'],
                    durationSelected: 'Weekly',
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'exceptionresolvingtime',
                    basisSelected: 'source',
                    criticalitySelected: 'all',
                    checkedList: ['mom', 'moto', 'multifond'],
                    durationSelected: 'Yearly',
                    editEnabled: false,
                    typeOfGraph: 'bar'
                }
            ],
            rankingMetricsDashboardConfTemp: [
                {
                    typeSelected: 'tradevolume',
                    basisSelected: 'firm',
                    topNumberSelected: 5,
                    durationSelected: 'Weekly',
                    editEnabled: false,
                    typeOfGraph: 'bar'
                },
                {
                    typeSelected: 'netassetvalue',
                    basisSelected: 'broker',
                    topNumberSelected: -3,
                    durationSelected: 'Monthly',
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'tradevolume',
                    basisSelected: 'firm',
                    topNumberSelected: -2,
                    durationSelected: 'Weekly',
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'percentagestp',
                    basisSelected: 'broker',
                    topNumberSelected: 4,
                    durationSelected: 'Yearly',
                    editEnabled: false,
                    typeOfGraph: 'bar'
                }
            ],
            exceptionPredictionConfTemp: [
                {
                    typeSelected: 'projectedexception',
                    basisSelected: 'firm',
                    checkedList: [],
                    editEnabled: false,
                    typeOfGraph: 'bar'
                },
                {
                    typeSelected: 'probabilityslabreach',
                    basisSelected: 'exceptioncategory',
                    checkedList: ['tradecapture', 'pricing'],
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'projectedcost',
                    basisSelected: 'firm',
                    checkedList: [],
                    editEnabled: false,
                    typeOfGraph: 'bar'
                },
                {
                    typeSelected: 'projectedexception',
                    basisSelected: 'source',
                    checkedList: ['mom', 'moto', 'confirmation'],
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'probabilityslabreach',
                    basisSelected: 'firm',
                    checkedList: [],
                    editEnabled: false,
                    typeOfGraph: 'line'
                }
            ],
            dynamicDashboardTemp: [
                // {
                //     name: 'Dash 1', property: 'DynamicDashboard', link: 'dash1',
                //     tabConfig: [
                //         {
                //             typeSelected: 'processingtime',
                //             basisSelected: 'client',
                //             criticalitySelected: null,
                //             checkedList: ['fstp', 'omgi'],
                //             durationSelected: 'Weekly'
                //         },
                //         {
                //             typeSelected: 'processingvolume',
                //             basisSelected: 'stptype',
                //             criticalitySelected: null,
                //             checkedList: ['stp', 'nonstp'],
                //             durationSelected: 'Monthly'
                //         }
                //     ]
                // },
                // {
                //     name: 'Dash 2', property: 'DynamicDashboard', link: 'dash2',
                //     tabConfig: [
                //         {
                //             typeSelected: 'processingtime',
                //             basisSelected: 'client',
                //             criticalitySelected: null,
                //             checkedList: ['fstp', 'omgi'],
                //             durationSelected: 'Weekly'
                //         },
                //         {
                //             typeSelected: 'processingvolume',
                //             basisSelected: 'stptype',
                //             criticalitySelected: null,
                //             checkedList: ['stp', 'nonstp'],
                //             durationSelected: 'Monthly'
                //         }
                //     ]
                // },
                // {
                //     name: 'Dash 3', property: 'RankingDynamicDashboard', link: 'dash3',
                //     tabConfig: [
                //         {
                //             typeSelected: 'tradevolume',
                //             basisSelected: 'firm',
                //             topNumberSelected: -2,
                //             durationSelected: 'Weekly'
                //         },
                //         {
                //             typeSelected: 'percentagestp',
                //             basisSelected: 'broker',
                //             topNumberSelected: 2,
                //             durationSelected: 'Yearly'
                //         }
                //      ]
                //},
                // {
                //     name: 'Workflow Dashboard', property: 'GeneralDynamicDashboard', link: 'workflowDashboard',
                //     tabConfig: [
                //         {
                //             dashborardType: 'RankingDynamicDashboard',
                //             typeSelected: 'exceptionsresolved',
                //             basisSelected: 'ops',
                //             topNumberSelected: 2,
                //             durationSelected: 'Weekly',
                //             editEnabled: false,
                //             typeOfGraph: 'bar'
                //         },
                //         {
                //             dashborardType: 'RankingDynamicDashboard',
                //             typeSelected: 'avgexceptionresolutiontime',
                //             basisSelected: 'ops',
                //             topNumberSelected: 3,
                //             durationSelected: 'Yearly',
                //             editEnabled: false,
                //             typeOfGraph: 'line'
                //         },
                //         {
                //             dashborardType: 'RankingDynamicDashboard',
                //             typeSelected: 'exceptionsresolved',
                //             basisSelected: 'ops',
                //             topNumberSelected: -3,
                //             durationSelected: 'Monthly',
                //             editEnabled: false,
                //             typeOfGraph: 'bar'
                //         },
                //         {
                //             dashborardType: 'RankingDynamicDashboard',
                //             typeSelected: 'avgexceptionresolutiontime',
                //             basisSelected: 'ops',
                //             topNumberSelected: -2,
                //             durationSelected: 'Yearly',
                //             editEnabled: false,
                //             typeOfGraph: 'bar'
                //         }
                //     ]
                // },
                {
                    name: 'GeneralDash', property: 'GeneralDynamicDashboard', link: 'generalDash',
                    tabConfig: [
                        {
                            dashborardType: 'ExceptionPredictabilityDynamicDashboard',
                            typeSelected: 'projectedcost',
                            basisSelected: 'firm',
                            checkedList: [],
                            editEnabled: false,
                            typeOfGraph: 'line'
                        },
                        {
                            dashborardType: 'RankingDynamicDashboard',
                            typeSelected: 'tradevolume',
                            basisSelected: 'firm',
                            topNumberSelected: -3,
                            durationSelected: 'Weekly',
                            editEnabled: false,
                            typeOfGraph: 'bar'
                        },
                        {
                            dashborardType: 'DynamicDashboard',
                            typeSelected: 'processingtime',
                            basisSelected: 'client',
                            criticalitySelected: null,
                            checkedList: [],
                            durationSelected: 'Monthly',
                            editEnabled: false,
                            typeOfGraph: 'line'
                        }
                    ]
                }
            ],
            gfsMetricsDashboardConf: [
                {
                    typeSelected: 'processingtime',
                    basisSelected: 'client',
                    criticalitySelected: null,
                    checkedList: [],
                    durationSelected: 'Weekly',
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'processingvolume',
                    basisSelected: 'stptype',
                    criticalitySelected: null,
                    checkedList: [],
                    durationSelected: 'Monthly',
                    editEnabled: false,
                    typeOfGraph: 'bar'
                },
                {
                    typeSelected: 'exceptionvolume',
                    basisSelected: 'asset',
                    criticalitySelected: 'high',
                    checkedList: ['future', 'depo', 'cash', 'abs'],
                    durationSelected: 'Weekly',
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'exceptionresolvingtime',
                    basisSelected: 'source',
                    criticalitySelected: 'all',
                    checkedList: ['mom', 'moto', 'multifond'],
                    durationSelected: 'Yearly',
                    editEnabled: false,
                    typeOfGraph: 'bar'
                }
            ],
            rankingMetricsDashboardConf: [
                {
                    typeSelected: 'tradevolume',
                    basisSelected: 'firm',
                    topNumberSelected: 5,
                    durationSelected: 'Weekly',
                    editEnabled: false,
                    typeOfGraph: 'bar'
                },
                {
                    typeSelected: 'netassetvalue',
                    basisSelected: 'broker',
                    topNumberSelected: -3,
                    durationSelected: 'Monthly',
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'tradevolume',
                    basisSelected: 'firm',
                    topNumberSelected: -2,
                    durationSelected: 'Weekly',
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'percentagestp',
                    basisSelected: 'broker',
                    topNumberSelected: 4,
                    durationSelected: 'Yearly',
                    editEnabled: false,
                    typeOfGraph: 'bar'
                }
            ],
            exceptionPredictionConf: [
                {
                    typeSelected: 'projectedexception',
                    basisSelected: 'firm',
                    checkedList: [],
                    editEnabled: false,
                    typeOfGraph: 'bar'
                },
                {
                    typeSelected: 'probabilityslabreach',
                    basisSelected: 'exceptioncategory',
                    checkedList: [],
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'projectedcost',
                    basisSelected: 'firm',
                    checkedList: [],
                    editEnabled: false,
                    typeOfGraph: 'bar'
                },
                {
                    typeSelected: 'projectedexception',
                    basisSelected: 'source',
                    checkedList: ['mom', 'moto', 'confirmation'],
                    editEnabled: false,
                    typeOfGraph: 'line'
                },
                {
                    typeSelected: 'probabilityslabreach',
                    basisSelected: 'firm',
                    checkedList: [],
                    editEnabled: false,
                    typeOfGraph: 'line'
                }
            ],
            dynamicDashboard: [
                // {
                //     name: 'Dash 1', property: 'DynamicDashboard', link: 'dash1',
                //     tabConfig: [
                //         {
                //             typeSelected: 'processingtime',
                //             basisSelected: 'client',
                //             criticalitySelected: null,
                //             checkedList: ['fstp', 'omgi'],
                //             durationSelected: 'Weekly'
                //         },
                //         {
                //             typeSelected: 'processingvolume',
                //             basisSelected: 'stptype',
                //             criticalitySelected: null,
                //             checkedList: ['stp', 'nonstp'],
                //             durationSelected: 'Monthly'
                //         }
                //     ]
                // },
                // {
                //     name: 'Dash 2', property: 'DynamicDashboard', link: 'dash2',
                //     tabConfig: [
                //         {
                //             typeSelected: 'processingtime',
                //             basisSelected: 'client',
                //             criticalitySelected: null,
                //             checkedList: ['fstp', 'omgi'],
                //             durationSelected: 'Weekly'
                //         },
                //         {
                //             typeSelected: 'processingvolume',
                //             basisSelected: 'stptype',
                //             criticalitySelected: null,
                //             checkedList: ['stp', 'nonstp'],
                //             durationSelected: 'Monthly'
                //         }
                //     ]
                // },
                // {
                //     name: 'Dash 3', property: 'RankingDynamicDashboard', link: 'dash3',
                //     tabConfig: [
                //         {
                //             typeSelected: 'tradevolume',
                //             basisSelected: 'firm',
                //             topNumberSelected: -2,
                //             durationSelected: 'Weekly'
                //         },
                //         {
                //             typeSelected: 'percentagestp',
                //             basisSelected: 'broker',
                //             topNumberSelected: 2,
                //             durationSelected: 'Yearly'
                //         }
                //      ]
                //},
                // {
                //     name: 'Workflow Dashboard', property: 'GeneralDynamicDashboard', link: 'workflowDashboard',
                //     tabConfig: [
                //         {
                //             dashborardType: 'RankingDynamicDashboard',
                //             typeSelected: 'exceptionsresolved',
                //             basisSelected: 'ops',
                //             topNumberSelected: 2,
                //             durationSelected: 'Weekly',
                //             editEnabled: false,
                //             typeOfGraph: 'bar'
                //         },
                //         {
                //             dashborardType: 'RankingDynamicDashboard',
                //             typeSelected: 'avgexceptionresolutiontime',
                //             basisSelected: 'ops',
                //             topNumberSelected: 3,
                //             durationSelected: 'Yearly',
                //             editEnabled: false,
                //             typeOfGraph: 'line'
                //         },
                //         {
                //             dashborardType: 'RankingDynamicDashboard',
                //             typeSelected: 'exceptionsresolved',
                //             basisSelected: 'ops',
                //             topNumberSelected: -3,
                //             durationSelected: 'Monthly',
                //             editEnabled: false,
                //             typeOfGraph: 'bar'
                //         },
                //         {
                //             dashborardType: 'RankingDynamicDashboard',
                //             typeSelected: 'avgexceptionresolutiontime',
                //             basisSelected: 'ops',
                //             topNumberSelected: -2,
                //             durationSelected: 'Yearly',
                //             editEnabled: false,
                //             typeOfGraph: 'bar'
                //         }
                //     ]
                // },
                {
                    name: 'GeneralDash', property: 'GeneralDynamicDashboard', link: 'generalDash',
                    tabConfig: [
                        {
                            dashborardType: 'ExceptionPredictabilityDynamicDashboard',
                            typeSelected: 'projectedcost',
                            basisSelected: 'firm',
                            checkedList: [],
                            editEnabled: false,
                            typeOfGraph: 'line'
                        },
                        {
                            dashborardType: 'RankingDynamicDashboard',
                            typeSelected: 'tradevolume',
                            basisSelected: 'firm',
                            topNumberSelected: -3,
                            durationSelected: 'Weekly',
                            editEnabled: false,
                            typeOfGraph: 'bar'
                        },
                        {
                            dashborardType: 'DynamicDashboard',
                            typeSelected: 'processingtime',
                            basisSelected: 'client',
                            criticalitySelected: null,
                            checkedList: [],
                            durationSelected: 'Monthly',
                            editEnabled: false,
                            typeOfGraph: 'line'
                        }
                    ]
                }
            ],
            dashboardConfChanged: 0,
            navgoto: null,
            nextTabNumber: 1,
            loggedIn: false,
            dropdownNameValueMatch: {
                projectedexception: 'Projected Exception',
                projectedcost: 'Projected Cost',
                probabilityslabreach: 'SLA breach Probability',
                exceptioncategory: 'Exception Category',
                firm: 'Firm',
                suorce: 'source'
            },
            dropdownNameValueMatchRanking: {
                percentagestp: 'Percentage STP',
                netassetvalue: 'Net Asset Value',
                tradevolume: 'Trade Volume',
                exceptionvolume: 'Exception Volume',
                exceptionsresolved: 'Exceptions Resolved',
                avgexceptionresolutiontime: 'Average Exception resolution time'
            },
            dropdownNameValueMatchGfsMetrics: {
                processingvolume: 'Average Processing Volume',
                stptype: 'STP vs non STP',
                processingtime: 'Average Processing Time',
                exceptionvolume: 'Exception Volume',
                exceptionresolvingtime: 'Exception Resolving Time'
            }
        };
    }

    changeUserDetail(action) {
        switch (action.type) {
            case 'LOGIN_SUCCESS': {
                console.log("LOGIN_SUCCESS");
                this.data.gfsMetricsDashboardConf = action.text.dashboardConf.gfsMetricsDashboardConf
                this.data.rankingMetricsDashboardConf = action.text.dashboardConf.rankingMetricsDashboardConf
                this.data.exceptionPredictionConf = action.text.dashboardConf.exceptionPredictionConf
                this.data.dynamicDashboard = action.text.dashboardConf.dynamicDashboard
                this.data.gfsMetricsDashboardConfTemp = JSON.parse(JSON.stringify(action.text.dashboardConf.gfsMetricsDashboardConf))
                this.data.rankingMetricsDashboardConfTemp = JSON.parse(JSON.stringify(action.text.dashboardConf.rankingMetricsDashboardConf))
                this.data.exceptionPredictionConfTemp = JSON.parse(JSON.stringify(action.text.dashboardConf.exceptionPredictionConf))
                this.data.dynamicDashboardTemp = JSON.parse(JSON.stringify(action.text.dashboardConf.dynamicDashboard))
                this.data.workflowConf = action.text.workflowConf
                this.data.userid = action.text.userId;
                this.data.userName = action.text.userName;
                this.data.loggedIn = true
                hashHistory.push('home');
                break;
            }
            case 'LOGOUT_SUCCESS': {
                console.log("LOGOUT_SUCCESS");
                this.data.loggedIn = false
                hashHistory.push('login');
                break;
            }
            case 'CLIENT_FILTER_CHANGED': {
                console.log("CLIENT_FILTER_CHANGED");
                this.data.clientFilter = action.text;
                this.emit('ClientFilterChnaged');
                break;
            }
             case 'SLA_FILTER_CHANGED': {
                console.log("SLA_FILTER_CHANGED");
                this.data.slaFilter = action.text;
                this.emit('SLAFilterChnaged');
                break;
            }
            case 'CLIENT_FILTER_CHANGED_ONLY': {
                console.log("CLIENT_FILTER_CHANGED_ONLY");
                this.data.clientFilter = action.text;
                break;
            }
            case 'ADD_GFS_METRICS_USER_TAB': {
                console.log("ADD_GFS_METRICS_USER_TAB");
                if (action.text === null) {
                    this.data.gfsMetricsDashboardConf.push({
                        typeSelected: 'exceptionvolume',
                        basisSelected: 'asset',
                        criticalitySelected: 'high',
                        checkedList: ['future', 'depo', 'cash', 'abs'],
                        durationSelected: 'Weekly',
                        editEnabled: true,
                        typeOfGraph: 'line'
                    });
                }
                else {
                    this.data.gfsMetricsDashboardConf.push(action.text);
                }
                ++this.data.dashboardConfChanged;
                this.emit("GfsMetricsUserConfUpdated");
                this.emit('dashboardConfChanged');
                break;
            }
            case 'ADD_RANKING_METRICS_USER_TAB': {
                console.log("ADD_RANKING_METRICS_USER_TAB");
                if (action.text === null) {
                    this.data.rankingMetricsDashboardConf.push({
                        typeSelected: 'tradevolume',
                        basisSelected: 'firm',
                        topNumberSelected: 2,
                        durationSelected: 'Weekly',
                        editEnabled: true,
                        typeOfGraph: 'bar'
                    });
                }
                else {
                    this.data.rankingMetricsDashboardConf.push(action.text);
                }
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                this.emit("RankingMetricsUserConfUpdated");
                break;
            }
            case 'ADD_EXCEPTION_PREDICTABILITY_USER_TAB': {
                console.log("ADD_EXCEPTION_PREDICTABILITY_USER_TAB");
                if (action.text === null) {
                    this.data.exceptionPredictionConf.push({
                        typeSelected: 'projectedcost',
                        basisSelected: 'firm',
                        checkedList: [],
                        editEnabled: true,
                        typeOfGraph: 'line'
                    });
                }
                else {
                    this.data.exceptionPredictionConf.push(action.text);
                }
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                this.emit("ExceptionPredictabilityUserConfUpdated");
                break;
            }
            case 'DELETE_GFS_METRICS_USER_TAB': {
                console.log("DELETE_GFS_METRICS_USER_TAB");
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                if (action.text.dynamicDashName === undefined) {
                    if (action.text.deleteIndex < this.data.gfsMetricsDashboardConf.length) {
                        this.data.gfsMetricsDashboardConf.splice(action.text.deleteIndex, 1);
                        this.emit("GfsMetricsUserConfUpdated");
                    }
                }
                else {
                    let tabConfig = this.data.dynamicDashboard.find(page => page.name === action.text.dynamicDashName).tabConfig;
                    if (action.text.deleteIndex < tabConfig.length) {
                        tabConfig.splice(action.text.deleteIndex, 1);
                        this.emit("DynamicDashboardUserConfUpdated" + action.text.dynamicDashName);
                    }
                }
                break;
            }
            case 'DELETE_RANKING_METRICS_USER_TAB': {
                console.log("DELETE_RANKING_METRICS_USER_TAB");
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                if (action.text.dynamicDashName === undefined) {
                    if (action.text.deleteIndex < this.data.rankingMetricsDashboardConf.length) {
                        this.data.rankingMetricsDashboardConf.splice(action.text.deleteIndex, 1);
                        this.emit("RankingMetricsUserConfUpdated");
                    }
                }
                else {
                    let tabConfig = this.data.dynamicDashboard.find(page => page.name === action.text.dynamicDashName).tabConfig;
                    if (action.text.deleteIndex < tabConfig.length) {
                        tabConfig.splice(action.text.deleteIndex, 1);
                        this.emit("DynamicDashboardUserConfUpdated" + action.text.dynamicDashName);
                    }
                }
                break;
            }
            case 'DELETE_EXCEPTION_PREDICTABILITY_USER_TAB': {
                console.log("DELETE_EXCEPTION_PREDICTABILITY_USER_TAB");
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                if (action.text.dynamicDashName === undefined) {
                    if (action.text.deleteIndex < this.data.exceptionPredictionConf.length) {
                        this.data.exceptionPredictionConf.splice(action.text.deleteIndex, 1);
                        this.emit("ExceptionPredictabilityUserConfUpdated");
                    }
                }
                else {
                    let tabConfig = this.data.dynamicDashboard.find(page => page.name === action.text.dynamicDashName).tabConfig;
                    if (action.text.deleteIndex < tabConfig.length) {
                        tabConfig.splice(action.text.deleteIndex, 1);
                        this.emit("DynamicDashboardUserConfUpdated" + action.text.dynamicDashName);
                    }
                }
                break;
            }
            case 'ADD_DYNAMIC_DASHBOARD_USER_TAB': {
                console.log("ADD_DYNAMIC_DASHBOARD_USER_TAB");
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                let dynamicConf = this.data.dynamicDashboard.find(page => page.name === action.text);
                if (dynamicConf.property === 'DynamicDashboard') {
                    dynamicConf.tabConfig.push({
                        typeSelected: null,
                        basisSelected: null,
                        criticalitySelected: null,
                        checkedList: [],
                        durationSelected: 'Weekly',
                        editEnabled: true,
                        typeOfGraph: 'line'
                    });
                }
                else if (dynamicConf.property === 'RankingDynamicDashboard') {
                    dynamicConf.tabConfig.push({
                        typeSelected: 'netassetvalue',
                        basisSelected: 'broker',
                        topNumberSelected: 3,
                        durationSelected: 'Monthly',
                        editEnabled: true,
                        typeOfGraph: 'bar'
                    });
                }
                else if (dynamicConf.property === 'ExceptionPredictabilityDynamicDashboard') {
                    dynamicConf.tabConfig.push({
                        typeSelected: 'projectedcost',
                        basisSelected: 'firm',
                        checkedList: [],
                        editEnabled: true,
                        typeOfGraph: 'line'
                    });
                }
                else if (dynamicConf.property === 'GeneralDynamicDashboard') {
                    dynamicConf.tabConfig.push({
                        dashborardType: 'ExceptionPredictabilityDynamicDashboard',
                        typeSelected: 'projectedcost',
                        basisSelected: 'firm',
                        checkedList: [],
                        editEnabled: true,
                        typeOfGraph: 'line'
                    });
                }
                this.emit("DynamicDashboardUserConfUpdated" + action.text);
                break;
            }
            case 'ADD_GENERAL_DYNAMIC_DASHBOARD_USER_TAB': {
                console.log("ADD_GENERAL_DYNAMIC_DASHBOARD_USER_TAB");
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                let dynamicConf = this.data.dynamicDashboard.find(page => page.name === action.text.name);
                if (dynamicConf.property === 'DynamicDashboard') {
                    dynamicConf.tabConfig.push({
                        typeSelected: null,
                        basisSelected: null,
                        criticalitySelected: null,
                        checkedList: [],
                        durationSelected: 'Weekly',
                        editEnabled: true,
                        typeOfGraph: 'line'
                    });
                }
                else if (dynamicConf.property === 'RankingDynamicDashboard') {
                    dynamicConf.tabConfig.push({
                        typeSelected: 'netassetvalue',
                        basisSelected: 'broker',
                        topNumberSelected: 3,
                        durationSelected: 'Monthly',
                        editEnabled: true,
                        typeOfGraph: 'bar'
                    });
                }
                else if (dynamicConf.property === 'ExceptionPredictabilityDynamicDashboard') {
                    dynamicConf.tabConfig.push({
                        typeSelected: 'projectedcost',
                        basisSelected: 'firm',
                        checkedList: [],
                        editEnabled: true,
                        typeOfGraph: 'line'
                    });
                }
                else if (dynamicConf.property === 'GeneralDynamicDashboard') {
                    if (action.text.graphType === 'Exception Analytics Graph') {
                        dynamicConf.tabConfig.push({
                            dashborardType: 'ExceptionPredictabilityDynamicDashboard',
                            typeSelected: 'projectedcost',
                            basisSelected: 'firm',
                            checkedList: [],
                            editEnabled: true,
                            typeOfGraph: 'line'
                        });
                    }
                    else if (action.text.graphType === 'Ranking Graph') {
                        dynamicConf.tabConfig.push({
                            dashborardType: 'RankingDynamicDashboard',
                            typeSelected: 'tradevolume',
                            basisSelected: 'firm',
                            topNumberSelected: -2,
                            durationSelected: 'Weekly',
                            editEnabled: true,
                            typeOfGraph: 'bar'
                        });
                    }
                    else {
                        dynamicConf.tabConfig.push({
                            dashborardType: 'DynamicDashboard',
                            typeSelected: 'processingtime',
                            basisSelected: 'client',
                            criticalitySelected: null,
                            checkedList: [],
                            durationSelected: 'Weekly',
                            editEnabled: true,
                            typeOfGraph: 'line'
                        });
                    }
                }
                this.emit("DynamicDashboardUserConfUpdated" + action.text.name);
                break;
            }
            case 'ADD_DYNAMIC_DASHBOARD_NAVIGATION_TAB': {
                console.log("ADD_DYNAMIC_DASHBOARD_NAVIGATION_TAB");
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                let tempProperty = '';
                switch (action.text.selectedDynamicTabType) {
                    case 'Gfs Metrics Dashboard': {
                        tempProperty = 'GeneralDynamicDashboard'
                        break;
                    }
                    case 'Ranking Dashboard': {
                        tempProperty = 'GeneralDynamicDashboard'
                        break;
                    }
                    case 'Exception Analytics Dashboard': {
                        tempProperty = 'GeneralDynamicDashboard'
                        break;
                    }
                    case 'General Dynamic Dashboard': {
                        tempProperty = 'GeneralDynamicDashboard'
                        break;
                    }
                }
                this.data.dynamicDashboard.push({
                    name: action.text.dynamicDashName, property: tempProperty, link: action.text.dynamicDashName.replace(/\s/g, "").toLowerCase(),
                    tabConfig: [
                    ]
                });
                this.data.nextTabNumber = this.data.nextTabNumber + 1;
                this.data.navgoto = 'app/dynamic/' + this.data.dynamicDashboard[this.data.dynamicDashboard.length - 1].link;
                this.emit("DynamicDashboardNavigationTabUpdated");
                break;
            }
            case 'DELETE_DYNAMIC_DASHBOARD_NAVIGATION_TAB': {
                console.log("DELETE_DYNAMIC_DASHBOARD_NAVIGATION_TAB");
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                let matchIndex = -1;
                for (let itr in this.data.dynamicDashboard) {
                    if (action.text === this.data.dynamicDashboard[itr].name) {
                        matchIndex = itr;
                    }
                }
                if (matchIndex > -1) {
                    this.data.dynamicDashboard.splice(matchIndex, 1);
                    if (matchIndex > 0) {
                        this.data.navgoto = 'app/dynamic/' + this.data.dynamicDashboard[matchIndex - 1].link;
                    }
                    else {
                        this.data.navgoto = 'app/exceptionAnalyticsDashboard';
                    }
                }
                this.emit("DynamicDashboardNavigationTabUpdated");
                break;
            }
            case 'CHANGE_RANKING_DASHBOARD_TAB_CONFIG': {
                console.log("CHANGE_RANKING_DASHBOARD_TAB_CONFIG");
                this.emit('dashboardConfChanged');
                ++this.data.dashboardConfChanged;
                if (action.text.dynamicDashName === undefined) {
                    if (action.text.valueToChange === 'typeSelected') {
                        this.data.rankingMetricsDashboardConf[action.text.indexValue]['basisSelected'] = null;
                    }
                    this.data.rankingMetricsDashboardConf[action.text.indexValue][action.text.valueToChange] = action.text.value;
                    this.emit("RankingMetricsUserConfUpdated");
                }
                else {
                    if (action.text.valueToChange === 'typeSelected') {
                        this.data.dynamicDashboard.find(page => page.name === action.text.dynamicDashName).tabConfig[action.text.indexValue]['basisSelected'] = null;
                    }
                    this.data.dynamicDashboard.find(page => page.name === action.text.dynamicDashName).tabConfig[action.text.indexValue][action.text.valueToChange] = action.text.value;
                    this.emit("DynamicDashboardUserConfUpdated" + action.text.dynamicDashName);
                }
                break;
            }
            case 'CHANGE_EXCEPTION_PREDICTABILITY_TAB_CONFIG': {
                console.log("CHANGE_EXCEPTION_PREDICTABILITY_TAB_CONFIG");
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                if (action.text.dynamicDashName === undefined) {
                    if (action.text.valueToChange !== 'editEnabled' && action.text.valueToChange !== 'typeOfGraph' && action.text.valueToChange !== 'durationSelected') {
                        this.data.exceptionPredictionConf[action.text.indexValue].checkedList = [];
                    }
                    this.data.exceptionPredictionConf[action.text.indexValue][action.text.valueToChange] = action.text.value;
                    this.emit("ExceptionPredictabilityUserConfUpdated");
                }
                else {
                    if (action.text.valueToChange !== 'editEnabled' && action.text.valueToChange !== 'typeOfGraph' && action.text.valueToChange !== 'durationSelected') {
                        this.data.dynamicDashboard.find(page => page.name === action.text.dynamicDashName).tabConfig[action.text.indexValue].checkedList = [];
                    }
                    this.data.dynamicDashboard.find(page => page.name === action.text.dynamicDashName).tabConfig[action.text.indexValue][action.text.valueToChange] = action.text.value;
                    this.emit("DynamicDashboardUserConfUpdated" + action.text.dynamicDashName);
                }
                break;
            }
            case 'CHANGE_GFS_METRICS_TAB_CONFIG': {
                console.log("CHANGE_GFS_METRICS_TAB_CONFIG");
                ++this.data.dashboardConfChanged;
                this.emit('dashboardConfChanged');
                if (action.text.dynamicDashName === undefined) {
                    if (action.text.valueToChange === 'basisSelected' || action.text.valueToChange === 'typeSelected') {
                        this.data.gfsMetricsDashboardConf[action.text.indexValue].checkedList = [];
                    }
                    this.data.gfsMetricsDashboardConf[action.text.indexValue][action.text.valueToChange] = action.text.value;
                    this.emit("GfsMetricsUserConfUpdated");
                }
                else {
                    if (action.text.valueToChange !== 'editEnabled' && action.text.valueToChange !== 'typeOfGraph' && action.text.valueToChange !== 'durationSelected') {
                        this.data.dynamicDashboard.find(page => page.name === action.text.dynamicDashName).tabConfig[action.text.indexValue].checkedList = [];
                    }
                    this.data.dynamicDashboard.find(page => page.name === action.text.dynamicDashName).tabConfig[action.text.indexValue][action.text.valueToChange] = action.text.value;
                    this.emit("DynamicDashboardUserConfUpdated" + action.text.dynamicDashName);
                }
                break;
            }
            case 'DRILLDOWN_HEADER_ICON_CLICK': {
                if (action.text === "chat") {
                    this.emit("HandleImClick");
                } else if (action.text === "help") {
                    this.emit("HandleHelpClick");
                }
                break;
            }
            case 'USER_LIST_ACQUIRED': {
                console.log('USER_LIST_ACQUIRED');
                this.data.userlist = action.text;
                this.emit('UserlistRefreshed');
                break;
            }
            case 'ROLE_LIST_ACQUIRED': {
                console.log('ROLE_LIST_ACQUIRED');
                this.data.rolelist = action.text;
                this.emit('RolelistRefreshed');
                break;
            }
            case 'BUSSINESS_OPS_LIST_ACQUIRED': {
                console.log('BUSSINESS_OPS_LIST_ACQUIRED');
                this.data.businessOpsTeam = action.text;
                this.emit('BussinessOpsTeamRefreshed');
                break;
            }
            case 'CLIENT_STAGE_LIST_ACQUIRED': {
                console.log('CLIENT_STAGE_LIST_ACQUIRED');
                this.data.activeClients = action.text.clients;
                this.data.activeStages = action.text.stages;
                this.emit('ClientStageListRefreshed');
                break;
            }
            case 'CLIENT_LIST_UPDATE': {
                console.log('CLIENT_LIST_UPDATE');
                // this.data.clientList = action.text;
                // this.emit('ClientListRefreshed');
                break;
            }
            case 'CANCEL_DAHSBOARD_CHANGE': {
                this.data.dashboardConfChanged = 0;
                this.data.gfsMetricsDashboardConf = JSON.parse(JSON.stringify(this.data.gfsMetricsDashboardConfTemp))
                this.data.rankingMetricsDashboardConf = JSON.parse(JSON.stringify(this.data.rankingMetricsDashboardConfTemp))
                this.data.exceptionPredictionConf = JSON.parse(JSON.stringify(this.data.exceptionPredictionConfTemp))
                this.data.dynamicDashboard = JSON.parse(JSON.stringify(this.data.dynamicDashboardTemp))
                this.emit('dashboardConfChanged');
                this.emit('refreshAllDashboard');
                break;
            }
            case 'SAVE_DAHSBOARD_CHANGE': {
                this.data.dashboardConfChanged = 0;
                this.data.gfsMetricsDashboardConfTemp = JSON.parse(JSON.stringify(this.data.gfsMetricsDashboardConf))
                this.data.rankingMetricsDashboardConfTemp = JSON.parse(JSON.stringify(this.data.rankingMetricsDashboardConf))
                this.data.exceptionPredictionConfTemp = JSON.parse(JSON.stringify(this.data.exceptionPredictionConf))
                this.data.dynamicDashboardTemp = JSON.parse(JSON.stringify(this.data.dynamicDashboard))
                this.emit('dashboardConfChanged');
                break;
            }
        }
    }

    getClientList() {
        return this.data.clientList;
    }
    getActiveClients() {
        return this.data.activeClients;
    }
    getActiveStagess() {
        return this.data.activeStages;
    }
    getBussinessOpsTeam() {
        return this.data.businessOpsTeam;
    }
    getClientFilterActive() {
        return this
    }
    getUserList() {
        return this.data.userlist;
    }
    getClientFilterActive() {
        return this.data.clientFilter;
    }
    getRoleList() {
        return this.data.rolelist;
    }
    getStagesMapped() {
        return this.data.workflowConf.stages.map((stageName) => {
            return stageName.replace(/\s/g, "").toUpperCase();
        });
    }
    getLoggedInStatus() {
        return this.data.loggedIn;
    }

    getGfsMetricsConfUserDetail() {
        return this.data.gfsMetricsDashboardConf;
    }
    getRankingMetricsConfUserDetail() {
        return this.data.rankingMetricsDashboardConf;
    }
    getDynamicTabData() {
        return this.data.dynamicDashboard;
    }
    getUserTabConfig(name) {
        try {
            return this.data.dynamicDashboard.find(page => page.name === name).tabConfig;
        }
        catch (e) {
            hashHistory.push('/app');
            this.emit('NavBarRefresh');
        }
    }
    getNavGoTo() {
        return this.data.navgoto;
    }
    getExceptionPredictabilityConfUserDetail() {
        return this.data.exceptionPredictionConf;
    }

    getNameValueLookup(item) {
        return this.data.dropdownNameValueMatch[item];
    }

    getNameValueLookupRanking(item) {
        return this.data.dropdownNameValueMatchRanking[item];
    }

    getNameValueLookupGfsMetrics(item) {
        return this.data.dropdownNameValueMatchGfsMetrics[item];
    }

    getWorkflowConf() {
        return this.data.workflowConf;
    }
    getUserId() {
        return this.data.userid;
    }
    getUserName() {
        return this.data.userName;
    }

    getListOfDynamicDashName() {
        let dashName = ['GFS Metrics Dashboard', 'Ranking Dashboard', 'Exception Prediction'];
        this.data.dynamicDashboard.forEach((item) => {
            dashName.push(item.name);
        });
        return dashName;
    }

    getDashboardChangedValues() {
        return this.data.dashboardConfChanged;
    }

    getSLAFilterActive(){
        return this.data.slaFilter;
    }

    getSLAList(){
        return this.data.slaList;
    }

    getDashboardChangedStatus() {
        return true ? this.data.dashboardConfChanged > 0 : false;
    }

    getUserDashboardChangeDataToSave() {
        return {
            gfsMetricsDashboardConf: this.data.gfsMetricsDashboardConf,
            rankingMetricsDashboardConf: this.data.rankingMetricsDashboardConf,
            exceptionPredictionConf: this.data.exceptionPredictionConf,
            dynamicDashboard: this.data.dynamicDashboard
        };
    }
}

const userDetailDataStore = new UserDetailDataStore;
userDetailDataStore.setMaxListeners(100);
ActionDispatcher.register(userDetailDataStore.changeUserDetail.bind(userDetailDataStore));
export default userDetailDataStore;