import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'


class PopupStore extends EventEmitter {
  constructor() {
    super();
    this.parameter = {
      display: 'none'
    };
    this.data = [];
  }
  
  changePopupAction(action) {
    switch (action.type) {
    case 'POPUP_OPEN_CLICKED': {
      //  console.log("POPUP_OPEN_CLICKED");
        this.data = action.text;
     //   console.log(this.data);
        break;
      }
      case 'POPUP_CLOSE_CLICKED': {
        console.log("POPUP_CLOSE_CLICKED");
        this.parameter.display = 'none';
        this.emit("PopupCloseClicked");
        break;
      }
     
    }
  }

  getDisplayStyle() {
    return this.parameter.display;
  }

  getPopupData() {
    return this.data;
  }

}

const popupStore = new PopupStore;
ActionDispatcher.register(popupStore.changePopupAction
.bind(popupStore));
export default popupStore;

