import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'


class GraphAborNavDataStore extends EventEmitter {
  constructor() {
    super();
    this.graphData = {
      graphTypeSelected: 'Stacked Bar Chart',
      chartData: [],
      graphTypeList: ['Pie Chart', 'Stacked Bar Chart', 'Stacked Column Chart', 'Tree Map Chart'],
      graphNameList: ['Exception by Branch','Exception by Client'],
      graphNameSelected: 'Exception by Branch'
    };
  }

  changeGraphData(action) {
    switch (action.type) {
      case 'CHANGE_GRAPH_NAME_SELECTED_ABOR_NAV': {
        console.log("CHANGE_GRAPH_NAME_SELECTED_ABOR_NAV");
        this.graphData.graphNameSelected = action.text;
        this.emit("GraphNameSelectedChangedAborNav");
        break;
      }
      case 'CHANGE_GRAPH_TYPE_SELECTED_ABOR_NAV': {
        console.log("CHANGE_GRAPH_TYPE_SELECTED_ABOR_NAV");
        this.graphData.graphTypeSelected = action.text;
        this.emit("GraphTypeSelectedChangedAborNav");
        break;
      }
      case 'CHART_ABOR_NAV_DATA_REFRESH': {
        console.log("CHART_ABOR_NAV_DATA_REFRESH");
        this.graphData.chartData = action.text;
        this.emit("ChartAborNavDataRefreshed");
        break;
      }
    }
  }

  getChartData() {
    return this.graphData.chartData;
  }

  getGraphTypeSelected() {
    return this.graphData.graphTypeSelected;
  }

  getGraphNameSelected() {
    return this.graphData.graphNameSelected;
  }

  getGraphTypeList() {
    return this.graphData.graphTypeList;
  }

  getGraphNamelist() {
    return this.graphData.graphNameList;
  }

}

const graphAborNavDataStore = new GraphAborNavDataStore;
ActionDispatcher.register(graphAborNavDataStore.changeGraphData.bind(graphAborNavDataStore));
export default graphAborNavDataStore;
