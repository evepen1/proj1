import React from 'react'
import { EventEmitter } from 'events'
import ActionDispatcher from '../dispatcher/actionDispatcher'


class ExceptionTableDataStore extends EventEmitter {
    constructor() {
        super();
        this.data = {
            tableData: [],
            detailedData: [],
            headerList: [
                { displayName: 'checkBox', fieldName: 'checkBox' },
                { displayName: 'Firm Code', fieldName: 'firmCode' },
                { displayName: 'Source', fieldName: 'source' },
                // { displayName: 'Severity', fieldName: 'criticality' },
                { displayName: 'Aging (hh:mm)', fieldName: 'aging' },
                { displayName: 'Allocation Id', fieldName: 'allocationId' },
                { displayName: 'Block Id', fieldName: 'blockExternalReferenceId' },
                { displayName: 'Asset Class', fieldName: 'assetClass' },
                { displayName: 'Portfolio Code', fieldName: 'portfolioCode' },
                { displayName: 'Stage', fieldName: 'exceptionCategory' },
                { displayName: 'Exception Category', fieldName: 'errorCategory' },
                { displayName: 'Description', fieldName: 'errorDescription' },
                //     { displayName: 'Remediation Step', fieldName: 'remediationStep' },
                { displayName: 'Assignee', fieldName: 'assignee' },
                { displayName: 'Status', fieldName: 'status' }
                // { displayName: 'Comment', fieldName: 'comment' }
            ],
            tradeDetail: { name1: 'N1', name2: 'N2', name3: 'N3' },
            similarExceptionSelectedList: []
        };
        this.filterData = [];
        this.selectedFIlterCategory = null;
        this.selectedFilterStatus = {};
        this.checkedItemSearchBox = {};
        this.remediationStepData = [
            {
                errorName: 'Failure Resolving Net Amount. (Principal=1500000) +/- (Fees=190) + (Accrued Interest=)', steps: [
                    '1. Login to MOM Prod and select the firm and open the Deal Blotter screen by navigating the toolbar at the top of the screen.\n',
                    '2. Filter the trade by batch date and select status pending. \n',
                    '3. Select the the given trade by batch Id. \n',
                    '4. If the TransactionType field in the screen is Buy/Sell, Then satisfy the New Amount value as per given formula. And change the values of field',
                    '5. Click Submit. '
                ]
            },
            {
                errorName: 'Security Origination Failed in SSM', steps: ['1.	Login to MOM Prod and open the MOTO Block Trade and Deal Blotter screens (shown below) by navigating the toolbar at the top of the screen.\n',
                    '2.	In MOM PROD on the Moto Block Trade screen, get the TICKER of the faulty trade by right clicking on the trade and clicking Open Trade File.  This will open an XML file in Explorer and the TICKER will be in this file. \n',
                    '3. Open up SSM (PROD) and then copy and paste the TICKER into the symbol bar on SSM and click search.\n',
                    '4. If the ticker has no match in SSM then continue to number 6. If there is a match click into the trade and copy the Axis ID. \n',
                    '5. Return to MOM and paste this ID into the SSM Security ID field. Click validate in Moto Block Trade, close the trade and open Deal blotter and repeat the process for trade to process through. \n',
                    '6. If there is no match in SSM, additional data must be sourced from Bloomberg. Take note of the option ID (usually available via email) then search for this in Bloomberg. \n',
                    '7.	Click into the appropriate ID and press FPRP and Enter on the keyboard. \n',
                    '8.	Search for ‘Unique’ in search bar and it will appear. The ID is large, to get the full ID hover your cursor over the ID and note the full ID. Also, take note of the currency. \n',
                    '9.	Return to SSM, and go to Origination and then Manual. \n',
                    '10. From here, you can set up the security using the data sourced from Bloomberg. \n']
            }
        ]
    }

    clearData() {
        this.filterData = [];
        this.selectedFIlterCategory = null;
        this.selectedFilterStatus = null;
        this.checkedItemSearchBox = {};
    }

    changeExceptionTableData(action) {
        switch (action.type) {
            case 'TABLE_DATA_REFRESH': {
                console.log("TABLE_DATA_REFRESH");
                this.data.tableData = action.text;
                this.filterData = [];
                this.checkedItemSearchBox = [];
                if (this.selectedFIlterCategory != null) {
                    this.data.tableData.forEach(item => {
                        if (item.errorCategory === this.selectedFIlterCategory) {
                            this.filterData.push(item);
                        }
                    });
                }
                if (this.selectedFilterStatus != null) {
                    this.data.tableData.forEach(item => {
                        if (item.errorCategory === this.selectedFilterStatus.categoryName
                            && item.status === this.selectedFilterStatus.currentStatus) {
                            this.filterData.push(item);
                        }
                    });
                }
                this.emit("TableDataRefreshed");
                break;
            }
            case 'TRADE_DETAIL_REFRESH': {
                console.log("TRADE_DETAIL_REFRESH");
                this.data.tradeDetail = action.text;
                this.emit("TradeDetailRefresh");
                break;
            }
            case 'REFRESH_SIMILAR_EXCEPTION_SELECTED_LIST': {
                console.log("REFRESH_SIMILAR_EXCEPTION_SELECTED_LIST");
                let index = -1;
                for (let i = 0; i < this.data.similarExceptionSelectedList.length; ++i) {
                    if (this.data.similarExceptionSelectedList[i].transactionId == action.text.transactionId) {
                        index = i;
                        break
                    }
                }
                if (index > -1) {
                    this.data.similarExceptionSelectedList.splice(index, 1);
                }
                else {
                    this.data.similarExceptionSelectedList.push(action.text);
                }
                this.emit("SimilarExceptionSelectedListRefreshed");
                break;
            }
            case 'REFRESH_SIMILAR_EXCEPTION_SELECTED_LIST_ALL': {
                console.log("REFRESH_SIMILAR_EXCEPTION_SELECTED_LIST_ALL");
                let index = -1;
                if (action.text == null) {
                    this.data.similarExceptionSelectedList = [];
                }
                else {
                    this.data.similarExceptionSelectedList = action.text
                }
                this.emit("SimilarExceptionSelectedListRefreshed");
                break;
            }
            case 'ACTIVE_CATEGORY_EXCEPTION_TABLE_CHANGE': {
                this.filterData = [];
                this.checkedItemSearchBox = [];
                this.selectedFIlterCategory = action.text;
                this.data.tableData.forEach(item => {
                    if (item.errorCategory === action.text) {
                        this.filterData.push(item);
                    }
                });
                this.emit("TableDataRefreshed");
                break;
            }
            case 'ACTIVE_CATEGORY_POPUP_EXCEPTION_TABLE_CHANGE': {
                this.filterData = [];
                this.selectedFilterStatus = action.text;
                if (action.text != null) {
                    this.data.tableData.forEach(item => {
                        if (item.errorCategory === action.text.categoryName
                            && item.status === action.text.currentStatus) {
                            this.filterData.push(item);
                        }
                    });
                }
                this.emit("TableDataRefreshed");
                break;
            }
            case 'DETAILED_CONTENT_TABLE_DATA': {
                console.log("datailed content data");
                this.data.detailedData = [];
                this.data.tableData.forEach(item => {
                    if (item.allocationId === action.text) {
                        this.data.detailedData.push(item);
                    }
                })
                this.emit("DetailedDataRefreshed");
                break;
            }
            case 'CLEAR_EXCEPTION_TABLE_POPUP_FILTER': {
                console.log("CLEAR_EXCEPTION_TABLE_POPUP_FILTER");
                if (action.text != undefined) {
                    delete this.checkedItemSearchBox[action.text];
                }
                else {
                    this.checkedItemSearchBox = {};
                }
                this.filterData = [];
                this.data.tableData.forEach(item => {
                    if (this.selectedException != null) {
                        if (this.selectedException === item.errorCategory) {
                            let multilevelSearchedMatched = false;
                            Object.keys(this.checkedItemSearchBox).map(eachFieldName => {
                                this.checkedItemSearchBox[eachFieldName].map(valueItem => {
                                    if (item[eachFieldName] == valueItem) {
                                        this.filterData.push(item);
                                    }
                                })
                            })
                            if (multilevelSearchedMatched) {
                                this.filterData.push(item);
                            }
                        }
                    } else {
                        let multilevelSearchedMatched = false;
                        Object.keys(this.checkedItemSearchBox).map(eachFieldName => {
                            this.checkedItemSearchBox[eachFieldName].map(valueItem => {
                                if (item[eachFieldName] == valueItem) {
                                    this.filterData.push(item);
                                }
                            })
                        })
                        if (multilevelSearchedMatched) {
                            this.filterData.push(item);
                        }
                    }
                });
                this.emit("TableDataRefreshed");
                break;
            }
            case 'SELECT_ALL_EXCEPTION_TABLE_POPUP_FILTER': {
                console.log("SELECT_ALL_EXCEPTION_TABLE_POPUP_FILTER");
                let listTodeAdded = Array.from(this.getFilterHeaderData(action.text));
                if (this.checkedItemSearchBox[action.text] == undefined) {
                    this.checkedItemSearchBox[action.text] = listTodeAdded;
                }
                else if (this.checkedItemSearchBox[action.text] != undefined && this.checkedItemSearchBox[action.text].length != listTodeAdded.length) {
                    this.checkedItemSearchBox[action.text] = listTodeAdded;
                }
                else {
                    delete this.checkedItemSearchBox[action.text];
                }
                this.filterData = [];
                this.data.tableData.forEach(item => {
                    if (this.selectedException != null) {
                        if (this.selectedException === item.errorCategory) {
                            let multilevelSearchedMatched = false;
                            Object.keys(this.checkedItemSearchBox).map(eachFieldName => {
                                this.checkedItemSearchBox[eachFieldName].map(valueItem => {
                                    if (item[eachFieldName] == valueItem) {
                                        this.filterData.push(item);
                                    }
                                })
                            })
                            if (multilevelSearchedMatched) {
                                this.filterData.push(item);
                            }
                        }
                    } else {
                        let multilevelSearchedMatched = false;
                        Object.keys(this.checkedItemSearchBox).map(eachFieldName => {
                            this.checkedItemSearchBox[eachFieldName].map(valueItem => {
                                if (item[eachFieldName] == valueItem) {
                                    this.filterData.push(item);
                                }
                            })
                        })
                        if (multilevelSearchedMatched) {
                            this.filterData.push(item);
                        }
                    }
                });
                this.emit("TableDataRefreshed");
                break;
            }
            case 'SEARCH_BOX_FILTER_CHANGE': {
                console.log("SEARCH_BOX_FILTER_CHANGE");
                if (this.checkedItemSearchBox[action.text.headerFieldName] != undefined && this.checkedItemSearchBox[action.text.headerFieldName].indexOf(action.text.headerFieldValue) > -1) {
                    this.checkedItemSearchBox[action.text.headerFieldName].splice(this.checkedItemSearchBox[action.text.headerFieldName].indexOf(action.text.headerFieldValue), 1);
                    if (this.checkedItemSearchBox[action.text.headerFieldName].length == 0) {
                        delete this.checkedItemSearchBox[action.text.headerFieldName];
                    }
                }
                else if (this.checkedItemSearchBox[action.text.headerFieldName] === undefined) {
                    this.checkedItemSearchBox[action.text.headerFieldName] = [];
                    this.checkedItemSearchBox[action.text.headerFieldName].push(action.text.headerFieldValue);
                }
                else {
                    this.checkedItemSearchBox[action.text.headerFieldName].push(action.text.headerFieldValue);
                }
                this.filterData = [];
                this.data.tableData.forEach(item => {
                    if (this.selectedException != null) {
                        if (this.selectedException === item.errorCategory) {
                            let multilevelSearchedMatched = false;
                            Object.keys(this.checkedItemSearchBox).map(eachFieldName => {
                                this.checkedItemSearchBox[eachFieldName].map(valueItem => {
                                    if (item[eachFieldName] == valueItem) {
                                        this.filterData.push(item);
                                    }
                                })
                            })
                            if (multilevelSearchedMatched) {
                                this.filterData.push(item);
                            }
                        }
                    } else {
                        let multilevelSearchedMatched = false;
                        Object.keys(this.checkedItemSearchBox).map(eachFieldName => {
                            this.checkedItemSearchBox[eachFieldName].map(valueItem => {
                                if (item[eachFieldName] == valueItem) {
                                    this.filterData.push(item);
                                }
                            })
                        })
                        if (multilevelSearchedMatched) {
                            this.filterData.push(item);
                        }
                    }
                });
                this.emit("TableDataRefreshed");
                break;

            }
            case 'REFRESH_CHANGE_EXCEPTION_TABLE_DATA_SELECTED_SEARCH': {
                console.log("refresh active header field ");
                this.emit("TableDataRefreshed");
                break;
            }
        }
    }

    getTableData() {
        if (this.filterData.length > 0) {
            return this.filterData;
        } else {
            return this.data.tableData;
        }

    }

    getTableHeaderList() {
        return this.data.headerList;
    }

    getSimilarExceptionSelectedList() {
        return this.data.similarExceptionSelectedList;
    }

    getEtfTableHeaderList() {
        return this.data.headerList.filter((item) => {
            return item.displayName != 'Stage';
        });;
    }

    getDetailedData(allocationId) {
        let detailedData = [];
        this.data.tableData.forEach(item => {
            if (item.allocationId === allocationId) {
                detailedData.push(item);
            }
        })
        return detailedData;
    }

    getSimilarExceptionTradeData(tradeItem) {
        return this.data.tableData.filter((item) => {
            return item.errorDescription === tradeItem.errorDescription && item.transactionId != tradeItem.transactionId;
        });
    }

    clearSelectedSimExList() {
        this.data.similarExceptionSelectedList = [];
    }

    getFilterHeaderData(headerFieldName) {
        console.log(headerFieldName);
        let headerSet = new Set();
        console.log(this.getTableData());
        this.data.tableData.forEach(item => {
            if (this.selectedException != null) {
                if (this.selectedException === item.errorCategory) {
                    if (item[headerFieldName] != null)
                        headerSet.add(item[headerFieldName]);
                }
            } else {
                if (item[headerFieldName] != null)
                    headerSet.add(item[headerFieldName]);
            }
        })
        console.log(headerSet);
        return headerSet;
    }

    getCheckedItemSearchBox() {
        return this.checkedItemSearchBox;
    }

    getRemediationStepData(errorDescription) {
        let stepDetails = [];
        this.remediationStepData.map(remediation => {
            if (errorDescription === remediation.errorName) {
                stepDetails = remediation.steps;
            }
        });
        return stepDetails;
    }

    getTradeDetail() {
        return this.data.tradeDetail;
    }
}

const exceptionTableDataStore = new ExceptionTableDataStore;
ActionDispatcher.register(exceptionTableDataStore.changeExceptionTableData.bind(exceptionTableDataStore));
export default exceptionTableDataStore;