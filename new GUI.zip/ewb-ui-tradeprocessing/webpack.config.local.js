const webpack = require("webpack");
const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const merge = require("webpack-merge");
const parts = require("./webpack.parts.js");
const CleanWebpackPlugin = require('clean-webpack-plugin')

const PATHS = {
    app: path.join(__dirname, "src/app.js"),
    build: path.join(__dirname, "build")
};

const commonConfig = merge([{
    entry: {
        "ewb-tp": PATHS.app
    },
    output: {
        path: PATHS.build,
        filename: "[name]-l.js"
    },
    module: {
        rules: [
            {
                test: /\.jsx?$/,
                use: "babel-loader",
                exclude: /node_modules/
            }
        ]
    },
    plugins: [
        new CleanWebpackPlugin(PATHS.build),
        new HtmlWebpackPlugin({
            template: 'template-index.html'
        }),
        new webpack.DefinePlugin({
            'process.env': {
                'NODE_ENV': JSON.stringify('qa'),
                'GQL_URL': JSON.stringify('http://GCOTDVMMW795456:10601/graphqlTPNew'),
                'CHANGE_EVENT_PUB_URL': JSON.stringify('http://GCOTDVMMW795456:8090/change-event-websocket')
            }
        }),
        new webpack.optimize.UglifyJsPlugin({
            compress: { warnings: false }
        })
    ],
    resolve: {},
    devServer: {
        inline: true,
        contentBase: "./build",
        stats: "errors-only",
        host: process.env.HOST, // Defaults to `localhost`
        port: 10701, // Defaults to 8080
    }
}]);

module.exports = (env) => {
    return merge(commonConfig, parts.extractCSS({
        use: [{ loader: 'css-loader', options: { minimize: true } }],
        namePostfix: 'l'
    }));
};