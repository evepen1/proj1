import React from "react";
import ReactDOM from "react-dom";
import { configure } from 'enzyme';
import { shallow, mount, render } from 'enzyme';
import TradeProcessing from "../../src/tradeProcessing";

describe("EWB Trade processing UI", () => {
  it("Renders without crashing", () => {
    const div = document.createElement("div");
    ReactDOM.render(<TradeProcessing />, div);
  });
  describe("Check if HTML container is created", () => {
    const wrapper = mount(<TradeProcessing />);
    it("parent container is created", () => {
      expect(wrapper.find(".ewb-tp").length).toEqual(1);
    });
    it("three chart container is created", () => {
      expect(wrapper.find(".chart-container").length).toEqual(3);
    });
  });
});
