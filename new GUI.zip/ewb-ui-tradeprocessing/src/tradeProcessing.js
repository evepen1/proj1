import React, { Component } from 'react';
import 'rxjs';
import { Provider } from 'react-redux';
import ewbtpStore from './store/ewbtpStore';
import TradeProcessingView from './tradeProcessingView';


export default class TradeProcessing extends Component {
    render() {
        return (<Provider store={ewbtpStore}>
            <TradeProcessingView />
        </Provider>
        );
    }
}