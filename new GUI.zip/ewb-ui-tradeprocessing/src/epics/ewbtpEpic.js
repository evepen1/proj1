import { combineEpics } from 'redux-observable';
import { combineReducers } from 'redux';
import cycleEpic from './tradeCycleEpics/cycleEpic';
import selectorEpic from './tradeExceptionEpics/selectorEpic';

export const ewbtpEpic = combineEpics(
    cycleEpic, selectorEpic
);
