import { TLC_INITIAL_LOADING } from '../../actions/actions';
import { stageCountUpdate, gqlUpdate } from '../../actionCreators/actionCreator.js';
import { ajax } from 'rxjs/observable/dom/ajax';
import { Observable } from 'rxjs';
import cycleQuery from '../../gqlQuery/cycleQuery';
import { combineEpics } from 'redux-observable';

const GQL_URL=process.env.GQL_URL;

const initialLoadSelectEpic = (action$, store) =>
    action$.ofType(TLC_INITIAL_LOADING)
        .mergeMap(action =>
            ajax.post(GQL_URL, cycleQuery.generate(store.getState().activeClient,store.getState().activeStage,store.getState().activeSeverity), { 'Content-Type': 'application/json' })
                .map(response => gqlUpdate(response.response))
                .catch((err) => {
                    return Observable.of({
                        type: GQL_UPDATE_ERROR,
                        payload: '' + err
                    });
                })
        );

const selectotEpic = combineEpics(
    initialLoadSelectEpic
);

export default selectotEpic;