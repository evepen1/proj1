import { CLIENT_SELECT, STAGE_SELECT, SEVERITY_SELECT,INITIAL_LOADING, GQL_UPDATE_ERROR } from '../../actions/actions';
import { stageCountUpdate, gqlUpdate } from '../../actionCreators/actionCreator.js';
import { ajax } from 'rxjs/observable/dom/ajax';
import { Observable } from 'rxjs';
import gqlQuery from '../../gqlQuery/gqlQuery';
import { combineEpics } from 'redux-observable';

const GQL_URL=process.env.GQL_URL;

const initialLoadSelectEpic = (action$, store) =>
    action$.ofType(INITIAL_LOADING)
        .mergeMap(action =>
            ajax.post(GQL_URL, gqlQuery.generate(store.getState().tradeProcessingException.activeClient,store.getState().tradeProcessingException.activeStage,store.getState().tradeProcessingException.activeSeverity), { 'Content-Type': 'application/json' })
                .map(response => gqlUpdate(response.response))
                .catch((err) => {
                    return Observable.of({
                        type: GQL_UPDATE_ERROR,
                        payload: '' + err
                    });
                })
        );

const clientSelectEpic = (action$, store) =>
   action$.ofType(CLIENT_SELECT)
        .mergeMap(action =>
            ajax.post(GQL_URL, gqlQuery.generate(store.getState().tradeProcessingException.activeClient,store.getState().tradeProcessingException.activeStage,store.getState().tradeProcessingException.activeSeverity), { 'Content-Type': 'application/json' })
                .map(response => gqlUpdate(response.response))
                .catch((err) => {
                    return Observable.of({
                        type: GQL_UPDATE_ERROR,
                        payload: '' + err
                    });
                })
        );

const stageSelectEpic = (action$, store) =>
    action$.ofType(STAGE_SELECT)
        .mergeMap(action =>
            ajax.post(GQL_URL, gqlQuery.generate(store.getState().tradeProcessingException.activeClient,store.getState().tradeProcessingException.activeStage,store.getState().tradeProcessingException.activeSeverity), { 'Content-Type': 'application/json' })
                .map(response => gqlUpdate(response.response))
                .catch((err) => {
                    return Observable.of({
                        type: GQL_UPDATE_ERROR,
                        payload: '' + err
                    });
                })
        );

const severitySelectEpic = (action$, store) =>
    action$.ofType(SEVERITY_SELECT)
        .mergeMap(action =>
            ajax.post(GQL_URL, gqlQuery.generate(store.getState().tradeProcessingException.activeClient,store.getState().tradeProcessingException.activeStage,store.getState().tradeProcessingException.activeSeverity), { 'Content-Type': 'application/json' })
                .map(response => gqlUpdate(response.response))
                .catch((err) => {
                    return Observable.of({
                        type: GQL_UPDATE_ERROR,
                        payload: '' + err
                    });
                })
        );

const selectotEpic = combineEpics(
    clientSelectEpic, stageSelectEpic, severitySelectEpic,initialLoadSelectEpic
);

export default selectotEpic;