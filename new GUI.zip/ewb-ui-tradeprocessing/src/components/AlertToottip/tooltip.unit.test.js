import React from "react";
import ReactDOM from "react-dom";
import { shallow, mount, render } from 'enzyme';
import ConnectedTooltip, { Tootltip } from "./tooltip";
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';

describe("Alert Tooltip test", () => {
    describe("HTML Container check", () => {
        let wrapper;
        let tooltipAlert = { type: 'danger', text: 'Test danger' };
        beforeEach(() => {
            wrapper = shallow(<Tootltip tooltipAlert={tooltipAlert} />);
        })
        it("creation on Exception", () => {
            expect(wrapper.find(".tooltip-container").exists()).toEqual(true);
        });
        it("creation with proper and css dispaly", () => {
            expect(wrapper.find(".alert-" + tooltipAlert.type).exists()).toEqual(true);
        });
        it("creation with proper message", () => {
            expect(wrapper.text()).toEqual(tooltipAlert.text);
        });
    });

    describe("Redux react connectivity check", () => {
        const initialState = { tooltipAlert: { type: 'sucess', text: 'Test success' } };
        const mockStore = configureStore();
        let store, wrapper;
        beforeEach(() => {
            store = mockStore(initialState);
            wrapper = mount(<Provider store={store}><ConnectedTooltip /></Provider>);
        });

        it("creation on success", () => {
            expect(wrapper.find(".tooltip-container").exists()).toEqual(true);
        });
        it("creation with proper type and css dispaly", () => {
            expect(wrapper.find(".alert-" + initialState.tooltipAlert.type).exists()).toEqual(true);
        });
        it("creation with proper message", () => {
            expect(wrapper.text()).toEqual(initialState.tooltipAlert.text);
        });
    });


    describe("Tooltip disappers after 4 second", () => {
        let wrapper;
        let tooltipAlert = { type: 'danger', text: 'Test danger' };
        beforeEach((done) => {
            wrapper = mount(<Tootltip tooltipAlert={tooltipAlert} />);
            wrapper.instance().handleFadeOut();
            setTimeout(() => {
                done();
            }, 4000);
        });
        it("Disappearence of tooltip", () => {
            expect(wrapper.html().match(/style="([^"]*)"/i)[1]).toBe('display: none;');
        });
    });
});
