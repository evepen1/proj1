import React, { Component } from 'react';
import { connect } from 'react-redux';

export class Tootltip extends Component {

    handleFadeOut() {
        setTimeout(() => {
            this.myRef.style.display = 'none';
        }, 4000);
    }

    render() {
        if (this.props.tooltipAlert.text == undefined || this.props.tooltipAlert.text.length == 0) {
            return null;
        }
        return (
            <div ref={(ref) => this.myRef = ref} className={'tooltip-container alert alert-' + this.props.tooltipAlert.type} onAnimationEnd={(e) => { this.handleFadeOut() }}>
                {this.props.tooltipAlert.text}
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        tooltipAlert: state.tooltipAlert
    };
}

export default connect(
    mapStateToProps,
    null
)(Tootltip);



