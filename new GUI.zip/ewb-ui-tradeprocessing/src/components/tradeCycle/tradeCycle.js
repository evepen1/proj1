/*import React, { Component } from 'react';
import { connect } from 'react-redux';
import { initialLoad } from '../../actionCreators/actionCreator';
import TradeExceptionSocket from '../../communication/tradeExceptionSocket';

import CycleTable from './cycleTable';


class TradeException extends Component {
    render() {
        return (
            <div className='container-fluid trade-exception-container'>
                <CycleTable />
            </div>
        );
    }

    componentDidMount() {
        TradeExceptionSocket.connect();
        this.props.initialLoad();
    }
    componentWillUnmount() {
        TradeExceptionSocket.disconnect();
    }
}

function mapDispatchToProps(dispatch) {
    return {
        initialLoad: (text) => dispatch(initialLoad(text))
    };
}

export default connect(
    null,
    mapDispatchToProps
)(TradeException);


*/
