import React, { Component } from 'react';
import { connect } from 'react-redux';
import { navSelect } from '../../actionCreators/actionCreator';
import ChevronRightIcon from '../icons/ChevronRightIcon';
import Tooltip from '../AlertToottip/tooltip';
import { teal100 } from 'material-ui/styles/colors';
import TradeException from '../tradeExceptions/tradeException';
import { hashHistory } from 'react-router';

const activeChevronColor = {
    fill: 'rgb(255,2,2)'
};

const inActiveChevronColor = {
    fill: 'rgb(0,0,0,0)'
};

class NavigationPanel extends Component {
    selectedNavItem(text) {
        if (text === "Trade Processing Exception") {
            //    hashHistory.push('TradeException');
        }
    }
    render() {
        let navList = this.props.navigationList.map((navItem) => {
            if (navItem === this.props.activeNav) {
                return (
                    <li key={navItem} className="nav-item active" onClick={this.selectedNavItem(navItem)}>
                        <a className="nav-link" href="#">{navItem}
                            <ChevronRightIcon style={activeChevronColor} />
                        </a>
                    </li>
                );
            }
            return (<li key={navItem} className="nav-item" onClick={(e) => { this.props.chnageActiveNav(navItem) }}>
                <a className="nav-link" href="#">{navItem}
                    <ChevronRightIcon style={inActiveChevronColor} />
                </a>
            </li>);
        }
        );
        return (
            <div className='row' style={{ 'backgroundColor': '#131d2a' }}>
                <Tooltip />
                <nav className="navbar navbar-expand-sm">
                    <ul className="navbar-nav">
                        {navList}
                    </ul>
                </nav>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        navigationList: state.navigationList,
        activeNav: state.activeNav
    };
}

function mapDispatchToProps(dispatch) {
    return {
        chnageActiveNav: (text) => dispatch(navSelect(text))
    };
}


export default connect(
    mapStateToProps, mapDispatchToProps
)(NavigationPanel);



