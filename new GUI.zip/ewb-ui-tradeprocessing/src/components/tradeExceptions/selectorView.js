import React, { Component } from 'react';
import Donut from './donut';
import DonutD3 from './donut-d3';
import CategoryBar from './bar';

export default class SelectorView extends Component {
    render() {
        if (this.props.selectorData.dataLoadState == 'loaded') {

            let child;
            if (this.props.heading == "Exception Summary")
                child = <CategoryBar data={this.props.selectorData.data} heading={this.props.heading} handler={this.props.changeSelectorValue} />;
            else
                child = <DonutD3 data={this.props.selectorData.data} heading={this.props.heading} handler={this.props.changeSelectorValue} />
            let dispList = this.props.selectorData.data.map((selectorItem) => {
                selectorItem.name = selectorItem.name.anyToUpperCamelWithSpace();
                if (selectorItem.name == this.props.active) {
                    return (
                        <div key={selectorItem.name} className='severity-entity-active col-sm-12' onClick={(e) => { this.props.changeSelectorValue(selectorItem.name) }}>
                            <span>{selectorItem.name}</span>
                            <span>{selectorItem.count}</span>
                        </div>
                    );
                }
                return (
                    <div key={selectorItem.name} className='severity-entity col-sm-12' onClick={(e) => { this.props.changeSelectorValue(selectorItem.name) }}>
                        <span>{selectorItem.name}</span>
                        <span>{selectorItem.count}</span>
                    </div>
                );
            });
            return (
                <article className='container-fluid chart-container'>
                    <div className='row'>
                        <div className='severity-entity-header col-sm-12'>
                            {this.props.heading}
                        </div>
                        {child}
                    </div>
                </article>
            );
        }
        else if (this.props.selectorData.dataLoadState == 'error') {
            return (
                <article className='container-fluid chart-container'>
                    <div className='row'>
                        <div className='severity-entity-header col-sm-12'>
                            {this.props.selectorData.error}
                        </div>
                    </div>
                </article>
            );
        }
        else {
            return (
                <article className='container-fluid chart-container'>
                    <div className='loader'>
                    </div>
                </article>
            );
        }
    }
}




