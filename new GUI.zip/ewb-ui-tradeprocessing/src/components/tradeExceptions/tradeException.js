import React, { Component } from 'react';
import { connect } from 'react-redux';
import { initialLoad } from '../../actionCreators/actionCreator';
import TradeExceptionSocket from '../../communication/tradeExceptionSocket';
import ExceptionSelector from './exceptionSelector';
import ExceptionTable from './exceptionTable';
import Dropdown from './clientDropdown';

String.prototype.lowerCamelCase2Capitalise = function () {
    var str = "";
    for (var i = 0; i < this.length; ++i) {
        var character = this.charAt(i);
        if (i > 0) {
            if (character == character.toUpperCase()) {
                str = str + ' ';
            }
        }
        str = str + character;
    }
    return str;
}

String.prototype.anyToUpperCamelWithSpace = function () {
    let str = "";
    var Regex = '^[a-zA-Z]*$';
    for (let i = 0; i < this.length; ++i) {
        let character = this.charAt(i);
        if (i > 0) {
            let prevCharacter = this.charAt(i - 1);
            if (character == character.toUpperCase() && prevCharacter.match(Regex) != null) {
                str = str + character.toLowerCase();
            }
            else if (character == character.toLowerCase()) {
                str = str + character;
            }
            else {
                str = str + character.toUpperCase();
            }
        }
        else {
            str = str + character.toUpperCase();
        }
    }
    return str;
}

class TradeException extends Component {
    render() {
        return (
            <div id='glc' className='container-fluid trade-exception-container'>
                <Dropdown />
                <ExceptionSelector />
                <ExceptionTable />
            </div>
        );
    }

    componentDidMount() {
        TradeExceptionSocket.connect();
        this.props.initialLoad();
    }
    componentWillUnmount() {
        TradeExceptionSocket.disconnect();
    }
}

function mapDispatchToProps(dispatch) {
    return {
        initialLoad: (text) => dispatch(initialLoad(text))
    };
}

export default connect(
    null,
    mapDispatchToProps
)(TradeException);



