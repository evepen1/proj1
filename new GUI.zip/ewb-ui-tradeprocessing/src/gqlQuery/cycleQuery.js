class CycleQuery {
    constructor() {
        this.gql = {
            query: "{exceptionListHolder{_id,firmCode,transactionId,allocationId,Trade Capture, Confirmation, Settlement, Acccounting, Data Delivery}}"
        }
    }
    generate(client = 'All', stage = 'All', severityType = 'All') {
        if(client=='All'){
            client='';
        }
         if(stage=='All'){
            stage='';
        }
         if(severityType=='All'){
            severityType='';
        }
        let elHolder = `exceptionList(client: \\"${client.toUpperCase()}\\", stage: \\"${stage.toUpperCase()}\\", severityType : \\"${severityType.toUpperCase()}\\")`;
        let stagecHolder = `stageCounts(client: \\"${client.toUpperCase()}\\", severityType : \\"${severityType.toUpperCase()}\\")`;
        let severitycHolder = `severityCounts(client: \\"${client.toUpperCase()}\\", stage: \\"${stage.toUpperCase()}\\")`;
        let esHolder = `exceptionSummaryList(client: \\"${client.toUpperCase()}\\", stage: \\"${stage.toUpperCase()}\\", severityType : \\"${severityType.toUpperCase()}\\")`;
        
        let str = JSON.stringify(this.gql).replace('exceptionListHolder', elHolder).replace('stageCountHolder', stagecHolder).replace('severityCountHolder', severitycHolder).replace('exceptionSummaryHolder', esHolder);
        
        console.log('Generate - \n' + str);
        return str;
    }

}

export default new CycleQuery;
