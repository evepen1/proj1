import * as actions from './actionCreator'
import * as types from '../actions/actions'

describe('Test action creators', () => {
    it('should create an action for intial loading', () => {
        let text = { ut: 'Success' }
        const expectedAction = {
            type: types.INITIAL_LOADING,
            payload: text
        }
        expect(actions.initialLoad(text)).toEqual(expectedAction);
    });
    it('should create an action for client selection', () => {
        let text = { ut: 'Success' }
        const expectedAction = {
            type: types.CLIENT_SELECT,
            payload: text
        }
        expect(actions.clientSelect(text)).toEqual(expectedAction);
    });
    it('should create an action for stage selection', () => {
        let text = { ut: 'Success' }
        const expectedAction = {
            type: types.STAGE_SELECT,
            payload: text
        }
        expect(actions.stageSelect(text)).toEqual(expectedAction);
    });
    it('should create an action for severity selection', () => {
        let text = { ut: 'Success' }
        const expectedAction = {
            type: types.SEVERITY_SELECT,
            payload: text
        }
        expect(actions.severitySelect(text)).toEqual(expectedAction);
    });
    it('should create an action for navigation selection', () => {
        let text = { ut: 'Success' }
        const expectedAction = {
            type: types.NAV_SELECT,
            payload: text
        }
        expect(actions.navSelect(text)).toEqual(expectedAction);
    });
    it('should create an action for Graph QL update', () => {
        let text = { ut: 'Success' }
        const expectedAction = {
            type: types.GQL_UPDATE,
            payload: text
        }
        expect(actions.gqlUpdate(text)).toEqual(expectedAction);
    });
    it('should create an action for new excetion', () => {
        let text = { ut: 'Success' }
        const expectedAction = {
            type: types.NEW_EXCEPTION,
            payload: text
        }
        expect(actions.newException(text)).toEqual(expectedAction);
    });
    it('should create an action for tooltip display', () => {
        let text = { ut: 'Success' }
        const expectedAction = {
            type: types.ALERT_TOOTLTIP,
            payload: text
        }
        expect(actions.alertTooltip(text)).toEqual(expectedAction);
    });
})