import { createStore, applyMiddleware } from 'redux';
import ewbtpReducer from '../reducers/ewbtpReducer';
import { createEpicMiddleware } from 'redux-observable';
import { ewbtpEpic } from '../epics/ewbtpEpic';

const epicMiddleware = createEpicMiddleware(ewbtpEpic);
const ewbtpStore = createStore(
    ewbtpReducer,
  applyMiddleware(epicMiddleware)
 );
export default ewbtpStore;