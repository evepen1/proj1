import React, { Component } from 'react';
import { Router, Route, IndexRoute, hashHistory } from 'react-router';
import NavigationPanel from './components/navigation/NavigationPanel';
import TradeException from './components/tradeExceptions/tradeException';

export default class Routing extends Component {

    render() {
        console.log("Inside Router");
      return (
       
        <Router history={hashHistory}>
        <Route path='/' component={NavigationPanel}>
          {/* <IndexRoute component={LoginScreen}></IndexRoute> */}
          <Route path='TradeException' component={TradeException} ></Route>
        </Route>
        </Router>

      );
    }
  }