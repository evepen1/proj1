import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import NavigationPanel from './components/navigation/NavigationPanel';
import TradeException from './components/tradeExceptions/tradeException';
import Routing from './router'

export default class TradeProcessingView extends Component {
    render() {
        return (
            <MuiThemeProvider>
                <div className='ewb-tp container-fluid'>
               <NavigationPanel />
               {/* <Routing /> */}
                <TradeException />
</div>
            </MuiThemeProvider>
        ); 
    }
}


