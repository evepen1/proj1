//Common event
export const ALERT_TOOTLTIP='ALERT_TOOTLTIP';
export const NAV_SELECT='NAV_SELECT';


//Trade processing exception related event
export const INITIAL_LOADING='INITIAL_LOADING';
export const CLIENT_SELECT='CLIENT_SELECT';
export const STAGE_SELECT='STAGE_SELECT';
export const SEVERITY_SELECT='SEVERITY_SELECT';
export const NEW_EXCEPTION='NEW_EXCEPTION';
export const GQL_UPDATE='GQL_UPDATE';
export const GQL_UPDATE_ERROR='GQL_UPDATE_ERROR';

// Trade life cycle related events
export const TLC_INITIAL_LOADING='TLC_INITIAL_LOADING';




