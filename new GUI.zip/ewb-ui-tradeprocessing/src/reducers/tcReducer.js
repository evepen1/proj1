import { combineReducers } from 'redux';
import * as selectorReducer from './tradeExceptionReducers/selectorReducer';
import * as miscellaneousReducer from './miscellaneousReducer'
import { cycleTableUpdate } from './tradeCycleReducers/cycleTableReducer';


const tcReducer = combineReducers({
    //navigationList: miscellaneousReducer.navigationList,
    cycleTableList: cycleTableUpdate
});

export default tcReducer;