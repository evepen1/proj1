import { combineReducers } from 'redux';
import * as miscellaneousReducer from './miscellaneousReducer'
import tcReducer from './tcReducer';
import tpReducer from './tpReducer';

const ewbtpReducer = combineReducers({
    tradeProcessingException: tpReducer,
    tradeLifeCycle: tcReducer,
    navigationList: miscellaneousReducer.navigationList,
    activeNav: miscellaneousReducer.navSelect,
    tooltipAlert: miscellaneousReducer.tooltip,
});

export default ewbtpReducer;