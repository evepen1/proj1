import { CLIENT_SELECT, STAGE_SELECT, GQL_UPDATE, GQL_UPDATE_ERROR, INITIAL_LOADING, NEW_EXCEPTION } from '../../actions/actions';

const defaultExceptionTable = {
};

export function cycleTableUpdate(state = defaultExceptionTable, action) {
    return state;
}