import { ALERT_TOOTLTIP, NAV_SELECT } from '../actions/actions';

export function navigationList(state = ['Trade Processing Exception', 'Trade Life Cycle'], action) {
  return state
}

export function tooltip(state = { type: 'light', text: '' }, action) {
  switch (action.type) {
    case ALERT_TOOTLTIP:
      return action.payload;
    default:
      return state;
  }
}

export function navSelect(state = 'Trade Processing Exception', action) {
  switch (action.type) {
    case NAV_SELECT:
      return action.payload;
    default:
      return state
  }
}
