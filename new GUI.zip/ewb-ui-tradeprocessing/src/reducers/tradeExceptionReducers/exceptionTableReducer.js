import { CLIENT_SELECT, STAGE_SELECT, GQL_UPDATE, GQL_UPDATE_ERROR, INITIAL_LOADING, NEW_EXCEPTION } from '../../actions/actions';

const defaultExceptionTable = {
    dataLoadState: 'loading',
    error: 'None',
    recordsPerPage: 10,
    totalPages: 5,
    onPage: 1,
    data: []
};

export function exceptionTableUpdate(state = defaultExceptionTable, action) {
    switch (action.type) {
        case GQL_UPDATE:
            return {
                dataLoadState: 'loaded',
                data: action.payload.data.exceptionList
            };
        case GQL_UPDATE_ERROR:
            return {
                dataLoadState: 'error',
                error: action.payload
            };
        case NEW_EXCEPTION:
            if (action.payload.activeClient == 'All' || action.payload.activeClient.toUpperCase() == action.payload.data.firmCode.toUpperCase()) {
                if (action.payload.activeSeverity == 'All' || action.payload.activeSeverity.toUpperCase() == action.payload.data.severity.toUpperCase()) {
                    if (action.payload.activeStage == 'All' || action.payload.activeStage.toUpperCase() == action.payload.data.stage.toUpperCase()) {
                        if (action.payload.data.status.toUpperCase() != 'RESOLVED') {
                            let tempData = state.data;
                            tempData.pop();
                            tempData.unshift(action.payload.data);
                            return {
                                dataLoadState: 'loaded',
                                data: tempData
                            };
                        }
                        else {
                            return {
                                dataLoadState: 'loaded',
                                data: state.data.filter((item) => {
                                    return item._id != action.payload.data._id
                                })
                            };
                        }
                    }
                    else {
                        return state;
                    }
                }
                else {
                    return state;
                }
            }
            else {
                return state;
            }
        case INITIAL_LOADING:
            return {
                dataLoadState: 'loading',
            };
        default:
            return state
    }
}