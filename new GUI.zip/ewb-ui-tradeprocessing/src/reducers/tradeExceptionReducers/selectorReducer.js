import { CLIENT_SELECT, STAGE_SELECT, SEVERITY_SELECT, NAV_SELECT } from '../../actions/actions';

export function clientSelect(state = 'All', action) {
  switch (action.type) {
    case CLIENT_SELECT:
      return action.payload;
    default:
      return state
  }
}

export function stageSelect(state = 'All', action) {
  switch (action.type) {
    case STAGE_SELECT:
      return action.payload;
    default:
      return state
  }
}

export function severitySelect(state = 'Critical', action) {
  switch (action.type) {
    case SEVERITY_SELECT:
      return action.payload;
    default:
      return state
  }
}
