var ReduxTpEWBStates = {
    navigationList: ['Trade Processing Exception', 'Trade Life Cycle'],
    tooltipAlert: { type: 'light', text: '' },
    activeNav: 'Trade Processing Exception',
    tradeProcessingException: {
        activeClient: 'SLI',
        activeStage: 'Trade Capture',
        activeSeverity: 'Critical',
        stageCounts: {
            dataLoadState: 'loaded',
            error: 'None',
            data: [
                { name: 'Trade Capture', count: 12 },
                { name: 'Confirmation', count: 4 }
            ]
        },
        severityCounts: {
            dataLoadState: 'loaded',
            error: 'None',
            data: [
                { name: 'Critical', count: 3 },
                { name: 'Medium', count: 3 }
            ]
        },
        exceptionSummaryList: {
            dataLoadState: 'loaded',
            error: 'None',
            data: [
                { name: 'BUSSINESS_VALIDATION', count: 2, statusList: [{ name: 'Open', count: 2 }] },
                { name: 'Missing Mandatory Fields', count: 2, statusList: [{ name: 'Work in Progress', count: 2 }] }
            ]
        },
        exceptionList: {
            dataLoadState: 'loaded',
            error: 'None',
            recordsPerPage: 10,
            totalPages: 5,
            onPage: 1,
            data: []
        }
    }
}