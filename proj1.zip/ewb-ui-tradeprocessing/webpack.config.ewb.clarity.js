const webpack = require("webpack");
const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const merge = require("webpack-merge");
const parts = require("./webpack.parts.js");
const CleanWebpackPlugin = require('clean-webpack-plugin')
const fs = require('fs');
const PATHS = {
    app: path.join(__dirname, "src/app_cl.js"),
    build: path.join(__dirname, "build_ewb_clarity")
};

const commonConfig = merge([{
    entry: {
        "ewb-cl": PATHS.app
    },
    output: {
        path: PATHS.build,
        filename: "[name]-d.js"
    },
    module: {
        rules: [
            {
                test: /\.jsx?$/,
                use: "babel-loader",
                exclude: /node_modules/
            }
        ]
    },
    plugins: [
        new CleanWebpackPlugin(PATHS.build),
        new HtmlWebpackPlugin({
            template: 'template-index.html'
        }),
        new webpack.DefinePlugin({
            'process.env': {
                'NODE_ENV': JSON.stringify('dev'),
                'GQL_URL': JSON.stringify('http://sd-c60a-6520:10601/graphqlTPNew'),
                // 'CHANGE_EVENT_PUB_URL': JSON.stringify('http://GCOTDVMMW795456.nam.nsroot.net:8090/change-event-websocket')
                'CHANGE_EVENT_PUB_URL': JSON.stringify('http://sd-c60a-6520:10501/change-event-websocket')
            }
        }),
        new webpack.optimize.UglifyJsPlugin({
            compress: { warnings: false }
        })
    ],
    resolve: {},
    devServer: {
       // https: true,
        // https: {
        //     key: fs.readFileSync("C:/EWB/EWB_SSL_Certs/ewbssl.key"),
        //     cert: fs.readFileSync("C:/EWB/EWB_SSL_Certs/ewbssl.cer"),
        //     passphrase:'ewb$$citi'
           // ca: fs.readFileSync("/path/to/ca.pem"),
      //  },
        inline: true,
        contentBase: "./build",
        stats: "errors-only",
        host: process.env.HOST, // Defaults to `localhost`
        port: 10701, // Defaults to 8080
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept'
        }
    }
}]);

module.exports = (env) => {
    return merge(commonConfig, parts.extractCSS({
        use: [{ loader: 'css-loader', options: { minimize: true } }],
        namePostfix: 'd'
    }));
};