import { TLC_SUMMARY_INITIAL_LOADING, TLC_TABLE_INITIAL_LOADING, TLC_SUMMARY_GQL_UPDATE, TLC_TABLE_GQL_UPDATE, GQL_UPDATE_ERROR } from '../../actions/actions';
import { stageCountUpdate, tlcSummaryGqlUpdate, tlcTableGqlUpdate } from '../../actionCreators/actionCreator.js';
import { ajax } from 'rxjs/observable/dom/ajax';
import { Observable } from 'rxjs';
import cycleQuery from '../../gqlQuery/cycleQuery';
import { combineEpics } from 'redux-observable';

const GQL_URL = process.env.GQL_URL;
const TLC_GQL_URL = process.env.TLC_GQL_URL;
//const REST_URL = process.env.REST_URL;

const summaryEpic = (action$, store) =>
    action$.ofType(TLC_SUMMARY_INITIAL_LOADING)
        .mergeMap(action =>
            ajax.get(TLC_GQL_URL, { 'Content-Type': 'application/json' })
                .map(response => tlcSummaryGqlUpdate(response.response))
                .catch((err) => {
                    return Observable.of({
                        type: GQL_UPDATE_ERROR,
                        payload: '' + err
                    });
                })
        );

const tableEpic = (action$, store) =>
    action$.ofType(TLC_TABLE_INITIAL_LOADING)
        .mergeMap(action =>
            ajax.post(GQL_URL, cycleQuery.generate(), { 'Content-Type': 'application/json' })
                .map(response => tlcTableGqlUpdate(response.response))
                .catch((err) => {
                    return Observable.of({
                        type: GQL_UPDATE_ERROR,
                        payload: '' + err
                    });
                })
        );


const cycleEpic = combineEpics(
    tableEpic, summaryEpic
);

export default cycleEpic;