import "../asset/css/ewb-tp.css";
import "../asset/css/ewb-tc.css";
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom'
import TradeProcessing from './tradeProcessing';

ReactDOM.render(<BrowserRouter><TradeProcessing /></BrowserRouter>, document.getElementById('app'))

