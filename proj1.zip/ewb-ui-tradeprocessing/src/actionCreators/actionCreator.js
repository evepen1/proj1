import {
    TRADE_DETAIl_OPEN, TRADE_DETAIl_DATA_RECIEVE, TRADE_DETAIl_CLOSE, CLIENT_SELECT, STAGE_SELECT, NAV_SELECT, SEVERITY_SELECT, GQL_UPDATE, INITIAL_LOADING, NEW_EXCEPTION, ALERT_TOOTLTIP, UPDATE_ASSIGNEE, UPDATE_STATUS, EXCEPTION_SUMMARY_SELECT, EXCEPTION_SUMMARY_UNSELECT,
    TLC_TABLE_INITIAL_LOADING, TLC_SUMMARY_INITIAL_LOADING, TLC_TABLE_GQL_UPDATE, TLC_SUMMARY_GQL_UPDATE, TLC_SUMMARY_NEW_EXCEPTION, TLC_TABLE_NEW_EXCEPTION
} from '../actions/actions';

export function initialLoad(text) {
    // console.log(`Action Creator - initialLoad - ${text}`);
    return { type: INITIAL_LOADING, payload: text };
}

export function clientSelect(text) {
    // console.log(`Action Creator - clientSelect - ${text}`);
    return { type: CLIENT_SELECT, payload: text };
}

export function stageSelect(text) {
    //console.log(`Action Creator - stageSelect - ${text}`);
    return { type: STAGE_SELECT, payload: text };
}

export function severitySelect(text) {
    //console.log(`Action Creator - severitySelect - ${text}`);
    return { type: SEVERITY_SELECT, payload: text };
}

export function exceptionSummarySelect(text) {
    //console.log(`Action Creator - exceptionSummarySelect - ${text}`);
    return { type: EXCEPTION_SUMMARY_SELECT, payload: text };
}

export function exceptionSummaryUnSelect(text) {
    //console.log(`Action Creator - exceptionSummaryUnSelect - ${text}`);
    return { type: EXCEPTION_SUMMARY_UNSELECT, payload: text };
}

export function navSelect(text) {
    //console.log(`Action Creator - navSelect - ${text}`);
    return { type: NAV_SELECT, payload: text };
}

export function gqlUpdate(text) {
    //console.log(`Action Creator - gqlUpdate - \n${JSON.stringify(text)}`);
    return { type: GQL_UPDATE, payload: text };
}

export function newException(text) {
    //console.log(`Action Creator - newException - ${text}`);
    return { type: NEW_EXCEPTION, payload: text };
}

export function alertTooltip(text) {
    //console.log(`Action Creator - alertTooltip - ${text}`);
    return { type: ALERT_TOOTLTIP, payload: text };
}

export function openTradeDetail(text) {
    console.log(`Action Creator - openTradeDetail - ${text}`);
    return { type: TRADE_DETAIl_OPEN, payload: text };
}

export function recievedTradeDetail(text) {
    console.log(`Action Creator - recievedTradeDetail - ${text}`);
    return { type: TRADE_DETAIl_DATA_RECIEVE, payload: text };
}

export function closeTradeDetail(text) {
    console.log(`Action Creator - closeTradeDetail - ${text}`);
    return { type: TRADE_DETAIl_CLOSE, payload: text };
}

export function updateStatus(text) {
    console.log(`Action Creator - updateStatus - ${text}`);
    return { type: UPDATE_STATUS, payload: text };
}

export function updateAssignee(text) {
    console.log(`Action Creator - updateAssignee - ${text}`);
    return { type: UPDATE_ASSIGNEE, payload: text };
}

export function tlcTableInitialLoad(text) {
    // console.log(`Action Creator - tlcTableInitialLoad - ${text}`);
    return { type: TLC_TABLE_INITIAL_LOADING, payload: text };
}

export function tlcSummaryInitialLoad(text) {
    //console.log(`Action Creator - tlcSummaryInitialLoad - ${text}`);
    return { type: TLC_SUMMARY_INITIAL_LOADING, payload: text };
}

export function tlcSummaryGqlUpdate(text) {
    //  console.log(`Action Creator - tlcSummaryGqlUpdate - \n${JSON.stringify(text)}`);
    return { type: TLC_SUMMARY_GQL_UPDATE, payload: text };
}

export function tlcTableGqlUpdate(text) {
    // console.log(`Action Creator - tlcTableGqlUpdate - \n${JSON.stringify(text)}`);
    return { type: TLC_TABLE_GQL_UPDATE, payload: text };
}

export function tlcSummaryNewException(text) {
    // console.log(`Action Creator - tlcSummaryNewException - ${text}`);
    return { type: TLC_SUMMARY_NEW_EXCEPTION, payload: text };
}

export function tlcTableNewException(text) {
    // console.log(`Action Creator - tlcTableNewException - ${text}`);
    return { type: TLC_TABLE_NEW_EXCEPTION, payload: text };
}

