import { combineReducers } from 'redux';
import { cycleSummaryUpdate } from './tradeCycleReducers/cycleSummaryReducer';
import { cycleTableUpdate } from './tradeCycleReducers/cycleTableReducer';

const tcReducer = combineReducers({
    
    cycleSummaryList: cycleSummaryUpdate,
    cycleTableList: cycleTableUpdate
});

export default tcReducer;