import tpReducer from './tpReducer';
import tcReducer from './tcReducer';
import { combineReducers } from 'redux';
import * as miscellaneousReducer from './miscellaneousReducer'


const ewbtpReducer = combineReducers({
    
    tradeProcessingException: tpReducer,
    tradeCycleException: tcReducer,
    navigationList: miscellaneousReducer.navigationList,
    activeNav: miscellaneousReducer.navSelect,
    tooltipAlert: miscellaneousReducer.tooltip,
});


export default ewbtpReducer;