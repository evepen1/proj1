import { combineReducers } from 'redux';
import * as selectorReducer from './tradeExceptionReducers/selectorReducer';
import * as miscellaneousReducer from './miscellaneousReducer'
import { stageCountUpdate } from './tradeExceptionReducers/stageCountReducer';
import { severityCountUpdate } from './tradeExceptionReducers/severityCountReducer';
import { exceptionSummaryUpdate } from './tradeExceptionReducers/exceptionSummaryReducer';
import { exceptionTableUpdate } from './tradeExceptionReducers/exceptionTableReducer';
import { tradeDetailUpdate } from './tradeExceptionReducers/tradeDetailReducer';

const tpReducer = combineReducers({

    activeNav: miscellaneousReducer.navSelect,
    activeClient: selectorReducer.clientSelect,
    activeStage: selectorReducer.stageSelect,
    activeSeverity: selectorReducer.severitySelect,
    activeSummary: selectorReducer.exceptionSummarySelect,
    unSelectFlag: selectorReducer.exceptionSummaryUnSelect,
    stageCounts: stageCountUpdate,
    severityCounts: severityCountUpdate,
    exceptionSummaryList: exceptionSummaryUpdate,
    exceptionTableList: exceptionTableUpdate,
    activeTradeDetail: tradeDetailUpdate
});

export default tpReducer;