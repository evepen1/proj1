import { CLIENT_SELECT, STAGE_SELECT, SEVERITY_SELECT, EXCEPTION_SUMMARY_SELECT, EXCEPTION_SUMMARY_UNSELECT, NAV_SELECT } from '../../actions/actions';

export function clientSelect(state = 'All', action) {
  switch (action.type) {
    case CLIENT_SELECT:
      return action.payload;
    default:
      return state
  }
}

export function stageSelect(state = 'All', action) {
  switch (action.type) {
    case STAGE_SELECT:
      return action.payload;
    default:
      return state
  }
}

export function severitySelect(state = 'All', action) {
  switch (action.type) {
    case SEVERITY_SELECT:
      return action.payload;
    default:
      return state
  }
}

export function exceptionSummarySelect(state = '', action) {
  switch (action.type) {
    case EXCEPTION_SUMMARY_SELECT:
      return action.payload;
    default:
      return state
  }
}

export function exceptionSummaryUnSelect(state = '', action) {
  switch (action.type) {
    case EXCEPTION_SUMMARY_UNSELECT:
      return action.payload;
    default:
      return state
  }
}