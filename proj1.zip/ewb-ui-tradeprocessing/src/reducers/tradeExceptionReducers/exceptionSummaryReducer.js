import { CLIENT_SELECT, STAGE_SELECT, EXCEPTION_SUMMARY_SELECT, NEW_EXCEPTION, GQL_UPDATE, SEVERITY_SELECT, GQL_UPDATE_ERROR } from '../../actions/actions';

const defaultExceptionSummary = {
    dataLoadState: 'loading',
    error: 'None',
    data: [
        { name: 'BUSSINESS_VALIDATION', count: 2, statusList: [{ name: 'Open', count: 2 }] },
        { name: 'Missing Mandatory Fields', count: 2, statusList: [{ name: 'Work in Progress', count: 2 }] }
    ]
};

export function exceptionSummaryUpdate(state = defaultExceptionSummary, action) {
    switch (action.type) {
        case GQL_UPDATE:
            return {
                dataLoadState: 'loaded',
                error: 'None',
                data: action.payload.data.exceptionSummaryList
            };
        case GQL_UPDATE_ERROR:
            return {
                dataLoadState: 'error',
                error: action.payload
            };
        case NEW_EXCEPTION:
            if (action.payload.activeClient == 'All' || action.payload.activeClient.toUpperCase() == action.payload.data.firmCode.toUpperCase()) {
                if (action.payload.activeSeverity == 'All' || action.payload.activeSeverity.toUpperCase() == action.payload.data.severity.toUpperCase()) {
                    if (action.payload.activeStage == 'All' || action.payload.activeStage.toUpperCase() == action.payload.data.stage.toUpperCase()) {
                        if (action.payload.data.status.toUpperCase() != 'RESOLVED') {
                            let found = false;
                            let tempData = state.data.map((item) => {
                                if (item.name.toUpperCase() == action.payload.data.errorCategory.toUpperCase() || item.name.toUpperCase() == 'ALL') {
                                    found = true;
                                    let sfound = false;
                                    let temStatusList = item.statusList.map((tmpStatus) => {
                                        if (tmpStatus.name.toUpperCase() == action.payload.data.status.toUpperCase()) {
                                            sfound = true;
                                            return ({ name: tmpStatus.name, count: tmpStatus.count + 1 });
                                        }
                                        else {
                                            return ({ name: tmpStatus.name, count: tmpStatus.count });
                                        }
                                    });
                                    if (!sfound) {
                                        temStatusList.push({ name: action.payload.data.status, count: 1 });
                                    }
                                    return ({ name: item.name, count: item.count + 1, statusList: temStatusList });
                                }
                                else {
                                    return ({ name: item.name, count: item.count, statusList: item.statusList });
                                }
                            });
                            if (!found) {
                                tempData.push({ name: action.payload.data.errorCategory, count: 1, statusList: [{ name: action.payload.data.status, count: 1 }] });
                            }
                            return {
                                dataLoadState: 'loaded',
                                data: tempData
                            };
                        }
                        else {
                            return {
                                dataLoadState: 'loaded',
                                data: state.data.map((item) => {
                                    if (item.name.toUpperCase() == action.payload.data.errorCategory.toUpperCase() || item.name.toUpperCase() == 'ALL') {
                                        let tmStatusList = item.statusList.map((tmpStatus) => {
                                            if (tmpStatus.name.toUpperCase() == action.payload.data.status.toUpperCase()) {
                                                return ({ name: tmpStatus.name, count: tmpStatus.count - 1 });
                                            }
                                            else {
                                                return ({ name: tmpStatus.name, count: tmpStatus.count });
                                            }
                                        }).filter(tmpStatus => {
                                            return tmpStatus.count > 0
                                        })
                                        return ({ name: item.name, count: item.count - 1, statusList: tmStatusList });
                                    }
                                    else {
                                        return ({ name: item.name, count: item.count, statusList: item.statusList });
                                    }
                                }).filter(item => {
                                    return item.count > 0
                                })
                            };
                        }
                    }
                    else {
                        return state;
                    }
                }
                else {
                    return state;
                }
            }
            else {
                return state;
            }
        default:
            return state
    }
}