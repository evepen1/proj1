import { TRADE_DETAIl_OPEN, TRADE_DETAIl_DATA_RECIEVE, TRADE_DETAIl_CLOSE } from '../../actions/actions';

const defaultTradeDetail = {
    selectedId: null,
    detail: null
};

export function tradeDetailUpdate(state = defaultTradeDetail, action) {
    switch (action.type) {
        case TRADE_DETAIl_CLOSE:
            return {
                selectedId: null,
                detail: null
            };
        case TRADE_DETAIl_OPEN:
            return {
                selectedId: action.payload,
                detail: null
            };
        case TRADE_DETAIl_DATA_RECIEVE:
            return {
                selectedId: state.selectedId,
                detail: action.payload.data.tradeDetail
            };
        default:
            return state
    }
}