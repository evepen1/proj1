var ReduxTpEWBStates = {
    navigationList: ['Trade Processing Exception', 'Trade Life Cycle'],
    tooltipAlert: { type: 'light', text: '' },
    activeNav: 'Trade Processing Exception',
    tradeProcessingException: {
        activeClient: 'SLI',
        activeStage: 'Trade Capture',
        activeSeverity: 'Critical',
        stageCounts: {
            dataLoadState: 'loaded',
            error: 'None',
            data: [
                { name: 'Trade Capture', count: 12 },
                { name: 'Confirmation', count: 4 }
            ]
        },
        severityCounts: {
            dataLoadState: 'loaded',
            error: 'None',
            data: [
                { name: 'Critical', count: 3 },
                { name: 'Medium', count: 3 }
            ]
        },
        exceptionSummaryList: {
            dataLoadState: 'loaded',
            error: 'None',
            data: [
                { name: 'BUSSINESS_VALIDATION', count: 2, statusList: [{ name: 'Open', count: 2 }] },
                { name: 'Missing Mandatory Fields', count: 2, statusList: [{ name: 'Work in Progress', count: 2 }] }
            ]
        },
        exceptionList: {
            dataLoadState: 'loaded',
            error: 'None',
            recordsPerPage: 10,
            totalPages: 5,
            onPage: 1,
            data: []
        }
    },

    activeNav: 'Trade Life Cycle',
    tradeCycleException: {
        dataLoadState: 'loaded',
        error: 'None',
        data: [
            { client: 'SLI',
                summary: [
                    { name: 'tradeCapture', statusList: [ { Processed: 23, Not_Received: 0, Pending: 5, Exception: 10} ] },
                    { name: 'Confirmation', statusList: [ { Processed: 15, Not_Received: 10, Pending: 5, Exception: 8 } ] },
                    { name: 'Settlement', statusList: [ { Processed: 10, Not_Received: 18, Pending: 5, Exception: 5 } ] },
                    { name: 'Accounting', statusList: [ { Processed: 7, Not_Received: 23, Pending: 5, Exception: 3 } ] },
                    { name: 'DataDelivery', statusList: [ { Processed: 5, Not_Received: 26, Pending: 5, Exception: 2 } ] }
                ]
            },
            { client: 'OMGI',
                summary: [
                    { name: 'tradeCapture', statusList: [ { Processed: 15, Not_Received: 20, Pending: 6, Exception: 1} ] },
                    { name: 'Confirmation', statusList: [ { Processed: 11, Not_Received: 0, Pending: 15, Exception: 8 } ] },
                    { name: 'Settlement', statusList: [ { Processed: 9, Not_Received: 18, Pending: 5, Exception: 5 } ] },
                    { name: 'Accounting', statusList: [ { Processed: 7, Not_Received: 23, Pending: 8, Exception: 3 } ] },
                    { name: 'DataDelivery', statusList: [ { Processed: 5, Not_Received: 26, Pending: 0, Exception: 2 } ] }
                ]
            }

        ]
        
    }

}