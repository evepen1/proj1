import { TLC_SUMMARY_NEW_EXCEPTION, TLC_SUMMARY_GQL_UPDATE, GQL_UPDATE_ERROR, TLC_SUMMARY_INITIAL_LOADING } from '../../actions/actions';

const defaultCycleSummary = {
    dataLoadState: 'loading',
    error: 'None',
    data: []
};

export function cycleSummaryUpdate(state = defaultCycleSummary, action) {
    switch (action.type) {
        case TLC_SUMMARY_GQL_UPDATE:
            return {
                dataLoadState: 'loaded',
                error: 'None',
                data: action.payload
            };
        case GQL_UPDATE_ERROR:
            return {
                dataLoadState: 'error',
                error: action.payload
            };
        case TLC_SUMMARY_NEW_EXCEPTION:
            let tempData = state.data;
            tempData.map((oldDataObject, index) => {
                if(oldDataObject.report[0].firm == action.payload.data.report[0].firm){
                    console.log("INdex==>", index);
                    tempData.splice(index, 1);
                    tempData.unshift(action.payload.data); 
                }   
            })
            return {
                dataLoadState: 'loaded',
                data: tempData
            };
         default:
            return state
    }
}
