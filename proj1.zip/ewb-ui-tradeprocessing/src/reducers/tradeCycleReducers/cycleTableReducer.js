import { TLC_TABLE_NEW_EXCEPTION, TLC_TABLE_GQL_UPDATE, GQL_UPDATE_ERROR, TLC_TABLE_INITIAL_LOADING } from '../../actions/actions';

const defaultCycleTable = {
    dataLoadState: 'loading',
    error: 'None',
    recordsPerPage: 10,
    totalPages: 5,
    onPage: 1,
    data: []
};

export function cycleTableUpdate(state = defaultCycleTable, action) {
    switch (action.type) {
        case TLC_TABLE_GQL_UPDATE:
            return {
                dataLoadState: 'loaded',
                data: action.payload.data.tradeLifeCycleData,
                recordsPerPage: 25,
                onPage: 1
            };
        case GQL_UPDATE_ERROR:
            return {
                dataLoadState: 'error',
                error: action.payload
            };
        case TLC_TABLE_NEW_EXCEPTION:
                let tempData = state.data;
                tempData.pop();
                tempData.unshift(action.payload.data);
            return {
                dataLoadState: 'loaded',
                data: tempData,
                recordsPerPage: 25,
                onPage: 1
            };      
        case TLC_TABLE_INITIAL_LOADING:
            return {
                dataLoadState: 'loading',
            };
        default:
            return state
    }
}
