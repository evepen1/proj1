import { ALERT_TOOTLTIP, NAV_SELECT } from '../actions/actions';

export function navigationList(state = [{ name: 'Trade Processing Exception', uri: '/tradeException' },{ name: 'Trade Life Cycle', uri: '/tradeLifeCycle' }], action) {
  return state
}

export function tooltip(state = { type: 'light', text: '' }, action) {
  switch (action.type) {
    case ALERT_TOOTLTIP:
      return action.payload;
    default:
      return state;
  }
}

export function navSelect(state, action) {
  switch (action.type) {
    case NAV_SELECT:
      return action.payload;
    default:
    if (window.location.hash == '#/tradeLifeCycle'){
      return 'Trade Life Cycle'
    }
    else if (window.location.hash == '#/tradeException'){
      return 'Trade Processing Exception'
    }
    else {
      return 'Trade Processing Exception'
    }
  }
}
