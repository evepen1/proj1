import SockJS from 'sockjs-client';
import Stomp from 'stompjs';
import { tlcSummaryNewException, tlcTableNewException, alertTooltip } from '../actionCreators/actionCreator';
import ewbtpStore from '../store/ewbtpStore';

const CHANGE_EVENT_PUB_URL = process.env.CHANGE_EVENT_PUB_URL;

class TradeCycleSocket {

    constructor() {
        this.socket = null;
    }

    connect() {
        try {
            let ws = new SockJS(CHANGE_EVENT_PUB_URL);
            let stompClient = Stomp.over(ws);
            stompClient.connect({}, function (frame) {
                console.log("Connect", frame);
                stompClient.subscribe("/topic/tlc/stats", (message) => {
                    console.log("/topic/tc/update");
                    if (message.body) {
                        console.log(message.body);
                        let data = JSON.parse(message.body);
                        ewbtpStore.dispatch(tlcSummaryNewException({ data }));
                    }
                });
                stompClient.subscribe("/topic/tlc/tradedata", (message) => {
                    console.log("/topic/tc/exception");
                    if (message.body) {
                        console.log(message.body);
                        let data = JSON.parse(message.body);
                        ewbtpStore.dispatch(tlcTableNewException({ data }));
                    }
                });
            }, function (err) {
                ewbtpStore.dispatch(alertTooltip({
                    type: 'danger',
                    text: 'Real time update discontnued due to websocket connection issue'
                }));
            });
            this.socket = stompClient;
        }
        catch (err) {
            ewbtpStore.dispatch(alertTooltip({
                type: 'danger',
                text: 'Real time update discontnued due to websocket connection issue'
            }));
        }
    }

    disconnect() {
        console.log('Disconnect');
        this.socket.disconnect();
        this.socket = null;
    }
}

export default new TradeCycleSocket;


