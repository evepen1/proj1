import SockJS from 'sockjs-client';
import Stomp from 'stompjs';
import { newException, alertTooltip, updateStatus, updateAssignee } from '../actionCreators/actionCreator';
import ewbtpStore from '../store/ewbtpStore';

const CHANGE_EVENT_PUB_URL = process.env.CHANGE_EVENT_PUB_URL;

class TradeExceptionSocket {

    constructor() {
        this.socket = null;
    }

    connect() {
        try {
            let ws = new SockJS(CHANGE_EVENT_PUB_URL);
            let stompClient = Stomp.over(ws);
            stompClient.connect({}, function (frame) {
                console.log("Connect", frame);
                stompClient.subscribe("/topic/tp/exception", (message) => {
                    console.log("/topic/tp/exception");
                    if (message.body) {
                        console.log(message.body);
                        let data = JSON.parse(message.body);
                        ewbtpStore.dispatch(newException({
                            data, activeClient: ewbtpStore.getState().tradeProcessingException.activeClient,
                            activeStage: ewbtpStore.getState().tradeProcessingException.activeStage, 
                            activeSeverity: ewbtpStore.getState().tradeProcessingException.activeSeverity
                        }));
                    }
                });
                stompClient.subscribe("/topic/tp/updateStatus", (message) => {
                    console.log("/topic/tp/updateStatus");
                    if (message.body) {
                        console.log(message.body);
                        let data = JSON.parse(message.body);
                        ewbtpStore.dispatch(updateStatus(data));
                    }
                });
                stompClient.subscribe("/topic/tp/updateAssignee", (message) => {
                    console.log("/topic/tp/updateAssignee");
                    if (message.body) {
                        console.log(message.body);
                        let data = JSON.parse(message.body);
                        ewbtpStore.dispatch(updateAssignee(data));
                    }
                });
            }, function (err) {
                ewbtpStore.dispatch(alertTooltip({
                    type: 'danger',
                    text: 'Real time update discontnued due to websocket connection issue'
                }));
            });
            this.socket = stompClient;
        }
        catch (err) {
            ewbtpStore.dispatch(alertTooltip({
                type: 'danger',
                text: 'Real time update discontnued due to websocket connection issue'
            }));
        }
    }

    disconnect() {
        console.log('Disconnect');
        this.socket.disconnect();
        this.socket = null;
    }
}

export default new TradeExceptionSocket;


