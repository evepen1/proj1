import React, { Component } from 'react';
import { connect } from 'react-redux';
import { tlcSummaryInitialLoad, tlcTableInitialLoad } from '../../actionCreators/actionCreator';
import TradeCycleSocket from '../../communication/tradeCycleSocket';
import CycleSummary from './cycleSummary';
import CycleTable from './cycleTable';

class TradeCycle extends Component {
    render() {
        return (
            <div id='glc' className='container-fluid trade-exception-container'>
                <div className='ewbtc-summary'>
                    <CycleSummary />
                </div>
                <div>
                    <CycleTable />
                </div>
            </div>
        );
    }
    componentDidMount() {
        TradeCycleSocket.connect();
        this.props.tlcSummaryInitialLoad();
        this.props.tlcTableInitialLoad();

    }
    componentWillUnmount() {
        TradeCycleSocket.disconnect();
    }
}

function mapDispatchToProps(dispatch) {
    return {
        tlcSummaryInitialLoad: (text) => dispatch(tlcSummaryInitialLoad(text)),
        tlcTableInitialLoad: (text) => dispatch(tlcTableInitialLoad(text))
    };
}

export default connect(
    null,
    mapDispatchToProps
)(TradeCycle);