import React, { Component } from 'react';
import { connect } from 'react-redux';
import ProgressBar from './progressBar';

export class CycleSummary extends Component {
    constructor() {
        super();
        this.data = {
            summaryHeaderList: [
                { displayName: 'Trade Capture', fieldName: 'TradeCapture' },
                { displayName: 'Confirmation', fieldName: 'Confirmation' },
                { displayName: 'Settlement', fieldName: 'Settlement' },
                { displayName: 'Accounting', fieldName: 'Accounting' },
                { displayName: 'Data Delivery', fieldName: 'DataDelivery' }
            ]
        };
    }
    render() {
        if (this.props.cycleSummaryList.dataLoadState == 'loaded') {
        let headRow = this.data.summaryHeaderList.map((item) => {
            return <th className='ewbtc-table-th'>
                {item.displayName}
            </th>
        });
        let tempArray = [];
        this.props.cycleSummaryList.data.map((object) => {
            tempArray.push(object.report)
        })
        let records = Object.keys(tempArray).map((firm) => {
            let totalTrades = 0;
            let sumDataPerClient = tempArray[firm];
            let section = sumDataPerClient[0].section.map((sectionData) => {
                let subRecords = this.data.summaryHeaderList.map((stageName) => {
                    if (sectionData.name == stageName.fieldName) {
                        let summary = sectionData.value.map((sumValue) => {
                            totalTrades = parseInt(totalTrades) + parseInt(sumValue.fieldValue);
                        });
                    }  
                });
                let exception, processed, notReceived, pending;
                sectionData.value.map((object) => {
                        if (object.fieldName == 'Exception' ) {
                            exception = object
                        }
                        else if (object.fieldName == 'Processed' ) {
                            processed = object
                        }
                        else if (object.fieldName == 'NotReceived' ) {
                            notReceived = object
                        }
                        else if (object.fieldName == 'Pending' ) {
                            pending = object
                        }                     
                });
                if (exception.fieldValue < 0) {
                     exception.fieldValue = 0
                }
                if (processed.fieldValue < 0) {
                     processed.fieldValue = 0
                }
                if (notReceived.fieldValue < 0) {
                     notReceived.fieldValue = 0;
                }
                if (pending.fieldValue < 0) {
                     pending.fieldValue = 0;
                }

                let displayName;
                this.data.summaryHeaderList.map((object) => {    
                    if (object.fieldName == sectionData.name ) {
                        displayName = object.fieldName
                    }
                });
                return <td>
                    <ProgressBar  clientName={sumDataPerClient.firm} 
                        green={parseInt(processed.fieldValue)}
                        orange={parseInt(notReceived.fieldValue)}
                        blue={parseInt(pending.fieldValue)}
                        red={parseInt(exception.fieldValue)} />
                </td>;
            });
            return <tr className='ewbtc-table-tr'>
                <td className='ewbtc-table-td'>
                    <span> {sumDataPerClient[0].firm}</span>
                    <span className='ewbtc-table-total-trade-span'>{'   (' + totalTrades / 5 + ')'}</span>
                </td>
                {section}
            </tr>;
        
        });
        return (
            <div className='ewbtc-div'>
                <div className='ewbtc-table-div'>
                    <table className='ewbtc-table'>
                        <thead className='ewbtc-thead'>
                            <tr>
                                <th>
                                </th>
                                {headRow}
                            </tr>
                        </thead>
                        <tbody>
                            {records}
                        </tbody>
                    </table>
                </div>
                <div className='ewbtc-legend-div'>
                    <div className='ewbtc-legend-container'>
                        <div className='ewbtc-legend-green'> </div>
                        <div className='ewbtc-legend-green-data'> Processed </div>
                        <div className='ewbtc-legend-orange'> </div>
                        <div className='ewbtc-legend-orange-data'> Not Recieved </div>
                        <div className='ewbtc-legend-blue'> </div>
                        <div className='ewbtc-legend-blue-data'> Pending </div>
                        <div className='ewbtc-legend-red'> </div>
                        <div className='ewbtc-legend-red-data'> Exception </div>
                    </div>
                </div>
            </div>
        );
        }
        else {
            return (
                <div className='row table-responsive table-container'>
                    <div className='loader'>
                    </div>
                </div>
            );
        }
    }
}



function mapStateToProps(state) {
    return {
        cycleSummaryList: state.tradeCycleException.cycleSummaryList
    };
}

export default connect(
    mapStateToProps
)(CycleSummary);