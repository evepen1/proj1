import React, { Component } from 'react';
import { connect } from 'react-redux';

class CycleTable extends Component {
    constructor() {
        super();
        this.data = {
            headerList: [
                { displayName: 'Firm Code', fieldName: 'firmCode' },
                { displayName: 'Trade Id', fieldName: 'allocationId' },
                { displayName: 'Block Id', fieldName: 'blockExternalReferenceId' },
                { displayName: 'Asset Class', fieldName: 'assetClass' },
                { displayName: 'Trade Capture', fieldName: 'tradeCapture' },
                { displayName: 'Confirmation', fieldName: 'confirmation' },
                { displayName: 'Settlement', fieldName: 'settlement' },
                { displayName: 'Accounting', fieldName: 'accounting' },
                { displayName: 'Data Delivery', fieldName: 'dataDelivery' }
            ]
        };
    }

    render() {
        if (this.props.cycleTableList.dataLoadState == 'loaded' && this.props.cycleTableList.data.length > 0) {
            let header = this.data.headerList.map(item => {
                return (
                    <th>
                        <div>
                            <div > {item.displayName}</div>
                        </div>
                    </th>
                );
            });
            let tempTableData = [];
            for (
                let i = (this.props.cycleTableList.onPage - 1) * this.props.cycleTableList.recordsPerPage;
                i < this.props.cycleTableList.data.length &&
                i < this.props.cycleTableList.onPage * this.props.cycleTableList.recordsPerPage;
                ++i
            ) {
                tempTableData.push(this.props.cycleTableList.data[i]);
            }
            let records = tempTableData.map((item, index) => {
                let colList = this.data.headerList.map(header => {
                    let style = {
                        color: '#ddd'
                    };
                    if (item[header.fieldName] == 'Exception') {
                        style.color = '#ff3d11';
                        style.width = '20px';
                        style.height = '18px';
                        style.position = 'relative';
                        style.left = '45%';
                        style.borderRadius = '10px';
                        style.backgroundColor = '#ff3d11';
                        style.margin = '5px 0px 5px ';
                        return (
                            <td>
                                <div style={style}></div>
                            </td>
                        );
                    }
                    else if (item[header.fieldName] == 'NotReceived') {
                        style.color = '#ffe330';
                        style.width = '20px';
                        style.height = '18px';
                        style.position = 'relative';
                        style.left = '45%';
                        style.borderRadius = '10px';
                        style.backgroundColor = '#ffe330';
                        style.margin = '5px 0px 5px ';
                        return (
                            <td>
                                <div style={style}></div>
                            </td>
                        );
                    }
                    else if (item[header.fieldName] == 'Processed') {
                        style.color = '#90EC7D';
                        style.width = '20px';
                        style.height = '18px';
                        style.position = 'relative';
                        style.left = '45%';
                        style.borderRadius = '10px';
                        style.backgroundColor = '#90EC7D';
                        style.margin = '5px 0px 5px ';
                        return (
                            <td>
                                <div style={style}></div>
                            </td>
                        );
                    }
                    else if (item[header.fieldName] == 'Pending') {
                        style.color = '#287eba';
                        style.width = '20px';
                        style.height = '18px';
                        style.position = 'relative';
                        style.left = '45%';
                        style.borderRadius = '10px';
                        style.backgroundColor = '#287eba';
                        style.margin = '5px 0px 5px ';
                        return (
                            <td>
                                <div style={style}></div>
                            </td>
                        );
                    }
                    return (
                        <td>
                            <div style={style}>{item[header.fieldName]}</div>
                        </td>
                    );
                });
                return (
                    <tr key={item.client + item.tradeId} className={"ewbtc-t-tr-" + index % 2}>
                        {colList}
                    </tr>
                );
            });
            return (
                <div className='row table-responsive table-container'>
                    <table className="table table-striped table-hover">
                        <thead>
                            <tr>
                                {header}
                            </tr>
                        </thead>
                        <tbody>
                            {records}
                        </tbody>
                    </table>
                </div>
            );
        }
        else {
            return (
                    <div className='row table-responsive table-container'>
                        <div className='loader'>
                        </div>
                    </div>
            );
        }
    }
}

function mapStateToProps(state) {
    return {
        cycleTableList: state.tradeCycleException.cycleTableList
    };
}

export default connect(
    mapStateToProps
)(CycleTable);



