import React from 'react';
import SvgIcon from 'material-ui/SvgIcon';

const ChevronDownIcon = (props) => (
    <SvgIcon {...props}>
        <path d="M30 12 L16 24 2 12" />
    </SvgIcon>
);

export default ChevronDownIcon