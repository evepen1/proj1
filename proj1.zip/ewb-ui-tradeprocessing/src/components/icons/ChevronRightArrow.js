import React from 'react';
import SvgIcon from 'material-ui/SvgIcon';

const ChevronRightArrow = (props) => (
    <SvgIcon {...props}>
        <path d="M22 12l-4-4v3H3v2h15v3z"/>
    </SvgIcon>
);

export default ChevronRightArrow