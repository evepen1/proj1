import React from 'react';
import * as d3 from 'd3';
import {donutColors} from './colors';

function draw(props){
    var data = props.data.filter(item => item.name != 'ALL');

    var svg = d3.select("#" + props.heading);
    svg.selectAll("*").remove();
    
    var radius = 21,
        g = svg.append("g").attr("transform", "translate(" + radius + "," + radius + ")");


    var pie = d3.pie().value(d=>d.count);

    var path = d3.arc()
            .outerRadius(radius - 2)
            .innerRadius(radius - 6)
            .cornerRadius(0)
            .padAngle(0);

    var label = d3.arc()
            .outerRadius(radius - 15)
            .innerRadius(radius - 15);

    var arcs = g.selectAll(".arc")
                .data(pie(data))
                .enter().append("g")
                    .attr("class", "arc");

    var previous = null;

    arcs.append("path")
            .attr("d", path)
            .attr("fill", function(d, i) { return donutColors[i%10]; })
            .attr("stroke", "white")          
            .attr("stroke-width", function(d){ 
                if(d.data.name == props.active.toUpperCase()) {
                    previous = d3.select(this);
                    return "0.5";
                }
                return "0"; })
            .on("click", function(d) {

                svg.select(".chart-number").attr("text-decoration", "none");

                let target = d3.select(this);
                if(previous != null) {
                    previous.attr("stroke-width", "0");
                }

                target.transition()
                    .attr("stroke-width", "0.5")
                    .duration(300);

                if(previous != target) {
                    props.handler(d.data.name);
                }
                previous = target;
            });

    var whiteBorder = svg.append("circle")
                            .attr("cx", radius)
                            .attr("cy", radius)
                            .attr("r",  radius-6)
                            .attr("fill", "transparent")
                            .attr("stroke", "white")          
                            .attr("stroke-width", "0.7")
                            .attr("display","none");
                            
    var texts = svg.append("g").attr("class", "chart-text")
                    .on("click", ()=>{
                        if(previous != null) {
                            previous.attr("stroke-width", "0");
                            previous = null;
                        }
                        svg.select(".chart-number").attr("text-decoration", "underline");
                        whiteBorder.transition().attr("display", "block").duration(300);
                        props.handler("All");
                    });

    var all = props.data.filter(item => item.name == 'ALL').map(item=> item.count);
    texts.append("text")
        .attr("class", "chart-number")
        .attr("x", "50%")
        .attr("y", "52%")
        .text(all);

    texts.append("text")
        .attr("class", "chart-label")
        .attr("x", "50%")
        .attr("y", "65%")
        .text("ALL");

    if (previous == null){
        svg.select(".chart-number").attr("text-decoration", "underline");
        whiteBorder.transition().attr("display", "block").duration(300);
    }
}

export default class DonutD3New extends React.Component {

    componentDidMount(){
        console.log("Donut chart: component did mount is called");
        draw(this.props);
    }

    componentWillUpdate(nextProps){
        draw(nextProps);
    }

    render(){
        console.log("Donut chart: render is called");
        var liElements = this.props.data.filter(item => item.name != 'ALL').map((item, i)=>{
                return (
                    <li key={item.name}>
                        <span className="shape-circle" style={{backgroundColor: donutColors[i%10]}}></span> {item.name} ({item.count})
                    </li>
                )
            })

        return (
            <div className="donut-container">
                <svg width="70%" height="70%" id={this.props.heading} preserveAspectRatio="xMidYMin meet" viewBox="0 0 42 42" className="donut" role="img">
                    

                </svg>
                <div className="col-sm-12 inside">
                    <ul className="figure-key-list">
                        {liElements}
                    </ul>
                </div>             
            </div>
        )
    }
}