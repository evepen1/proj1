import React, { Component } from 'react';
import { connect } from 'react-redux';

export default class Remediation extends Component {
    constructor(props) {
        super(props);
    }

    inputHolderFactory(remediationEntity) {
        switch (remediationEntity.fieldType) {
            case "Text":
                return (<input disabled={this.props.inputDisabled} type='text' defaultValue={remediationEntity.fieldValue} />);
            case "Checkbox":
                return (<input disabled={this.props.inputDisabled} type='text' defaultValue={remediationEntity.fieldValue} />);
            case "Dropdown":
                return (<input disabled={this.props.inputDisabled} type='text' defaultValue={remediationEntity.fieldValue} />);
            default:
                return null;
        }
    }

    render() {
        let remediationList = this.props.remediationStep.map((item) => {
            let inputHolder = inputHolderFactory(item);
            return (
                <div className='col-sm-12 col-md-6 trade-overview-entity'>
                    <div className='row'>
                        <div className='col-sm-5 trade-overview-entity-header text-center'>{item.fieldName.lowerCamelCase2Capitalise()}</div>
                        <div className='col-sm-5 trade-overview-entity-content'>
                            {inputHolder}
                        </div>
                    </div>
                </div>
            );
        });
        return (
            <section className='row'>
                {remediationList}
            </section>
        );
    }
}




