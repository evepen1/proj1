import React, { Component } from 'react';
import { connect } from 'react-redux';

export default class DetailDescriptor extends Component {
    constructor(props) {
        super(props);
        this.toFilterOut=['_id','errorCategory','errorDescription','severity'];
    }

    render() {
        let toList = Object.keys(this.props.detail)
            .filter((item) => { return ((Object.prototype.toString.call(this.props.detail[item]) === '[object String]'||Object.prototype.toString.call(this.props.detail[item]) === '[object Number]') && (this.props.toFilterOut==undefined || this.props.toFilterOut.indexOf(item)<0) && (this.props.toFilterIn==undefined || this.props.toFilterIn.indexOf(item)>-1) )})
            .map((item) => {
                return (
                    <div className='col-sm-12 col-md-6 trade-overview-entity'>
                        <div className='row'>
                            <div className='col-sm-5 trade-overview-entity-header text-center'>{item.lowerCamelCase2Capitalise().capitalise()}</div>
                            <div className='col-sm-5 trade-overview-entity-content'>{this.props.detail[item]}</div>
                        </div>
                    </div>
                );
            });
        return (
            <section className='row'>
                {toList}
            </section>
        );
    }
}




