import React, { Component } from 'react';
import { connect } from 'react-redux';
import DetailDescriptor from './detailDescriptor';
import Remediation from './remediation';
import { closeTradeDetail } from '../../../actionCreators/actionCreator';

class TradeDetail extends Component {
    constructor(props) {
        super(props);
        this.errorOverview = { toFilterIn: ['errorCategory', 'errorDescription', 'severity'] };
        this.tradeOverview = { toFilterOut: ['_id', 'errorCategory', 'errorDescription', 'severity'] };
    }

    render() {
        return (
            <article className='container-fluid trade-exception-container'>
                <section className='row'>
                    <div className='col-sm-12'>
                        <span className='close pull-right' onClick={(e) => { this.props.closeTradeDetail(null) }}>X</span>
                    </div>
                </section>
                <section className='row'>
                    <div className='col-sm-12 trade-detail-heading text-left'>
                        Trade Overview
                    </div>
                </section>
                <DetailDescriptor detail={this.props.activeTradeDetail.detail} toFilterOut={this.tradeOverview.toFilterOut} />
                <section className='row'>
                    <div className='col-sm-12 trade-detail-heading text-left'>
                        Error Overview
                    </div>
                </section>
                <DetailDescriptor detail={this.props.activeTradeDetail.detail} toFilterIn={this.errorOverview.toFilterIn} />
                <section className='row'>
                    <div className='col-sm-12 trade-detail-heading text-left'>
                        Remediation
                    </div>
                </section>
                {/*<Remediation inputDisabled={false} remediationStep={this.props.activeTradeDetail.detail.remediation.remediationStep} />*/}
            </article>
        );
    }
}

function mapDispatchToProps(dispatch) {
    return {
        closeTradeDetail: (text) => dispatch(closeTradeDetail(text))
    };
}

export default connect(
    null,
    mapDispatchToProps
)(TradeDetail);




