import React from 'react';

export default class Donut extends React.Component {

    shouldComponentUpdate(){
        return true;
    }

    componentDidMount(){
        console.log(this.props.data);
        var data = this.props.data.filter(item => item.name != 'All').map(item => item.count);
        var canvas = this.refs.chart,
            context = canvas.getContext("2d");

        var width = canvas.width,
        height = canvas.height,
        radius = Math.min(width, height) / 2;

        var colors = [
            "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd",
            "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf"
            ];
            
        var arc = d3.arc()
                .outerRadius(radius - 10)
                .innerRadius(radius - 25)
                .padAngle(0.03)
                .context(context);
        
        var pie = d3.pie();
        var arcs = pie(data);

        context.translate(width / 2, height / 2);

        context.globalAlpha = 0.5;
        arcs.forEach((d, i) =>{
            context.beginPath();
            arc(d);
            context.fillStyle = colors[i%10];
            context.fill();
        });
    }

    render(){
        return (
            <div className="col-ms-12">
                <canvas ref="chart"></canvas>
            </div>
        )
    }
}