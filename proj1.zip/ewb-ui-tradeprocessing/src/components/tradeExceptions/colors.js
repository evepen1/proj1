export const donutColors = [
            "#ff7f0e", "#ffe330", "#ff3d11", "#287eba", "#9467bd",
            "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf"
        ];

export const rightBarColor = "#9E2A0F";
export const rightBarHoverColor = "#FF2C00";