import React from 'react';
import { rightBarColor, rightBarHoverColor } from './colors';

export default class BarPopUp extends React.Component {

    handleMouseEnter(e){
        this.popup.style.display = 'block';
        this.targetBar.style.backgroundColor = rightBarHoverColor;
    }

    handleMouseLeave(e){
        if(this.lastClick==''){
            this.popup.style.display = 'none';
            this.targetBar.style.backgroundColor = rightBarColor;            
        }
    }

    handleClick(e, category, item, index){

        console.log({errorCategory: category, status: item.name});
        if (this.lastClick == category + item.name){
            this.lastClick = '';
            this.props.unSelectHandler(true);

            this.popup.style.display = 'none';
            this.targetBar.style.backgroundColor = rightBarColor;
            return this.props.handler({errorCategory: '', status: ''});
        }

        let lastClick = document.getElementById(this.lastClick);
        if(lastClick != null)
            lastClick.style.backgroundColor = index%2==0? '#243246':'#314d71';
        this.props.unSelectHandler(false);
        this.lastClick = category + item.name;
        document.getElementById(this.lastClick).style.backgroundColor = '#0d508b';
        return this.props.handler({errorCategory: category, status: item.name});  
    }

    componentWillUpdate(nextProps){
        if(nextProps.resetFlag)
            this.lastClick = '';
    }

    componentDidMount(){
        this.popup = document.querySelector("#"+this.props.id);
        this.lastClick = '';
    }

    render(){
        console.log('exception summary popup: render is called.');
        this.targetBar = document.querySelector("#"+this.props.targetBarID);
        if(this.resetFlag)
            this.lastClick = '';
        var activeBar = this.props.data;
        var category = activeBar? activeBar.name : '';
        var data     = activeBar? activeBar.statusList : [];

        var list = data.map((item, index)=>{
                var style = {};
                if(this.lastClick!='' && this.lastClick == category + item.name)
                    style = {backgroundColor: '#0d508b'}

                return(
                    <div
                        style={style}
                        id={category+item.name}
                        onClick={ (e) => this.handleClick(e, category, item, index) }
                    >{item.name} {item.count}</div>
                )
            });

        return(
            <div id={this.props.id}  className="bar-popup"
                onMouseEnter={ (e) => this.handleMouseEnter(e) }
                onMouseLeave={ (e) => this.handleMouseLeave(e) }>
                {list}
            </div>
        );
    }
}