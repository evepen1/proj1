import React, { Component } from 'react';
import { connect } from 'react-redux';
import ewbSocket from '../../communication/tradeExceptionSocket';
import { openTradeDetail } from '../../actionCreators/actionCreator';

class ExceptionTable extends Component {
    constructor(props) {
        super(props);
        this.lookup = {
            statusList: ['Open', 'Work in Progress', 'Pending Approval', 'Approved', 'Rejected', 'Resolved'],
            disbledStatusList: ['Pending Approval', 'Approved', 'Rejected', 'Resolved'],
            assigneeList: ['Jason Bourne', 'Selina Kyle', 'Clark Kent', 'Bruce Wayne', 'Tony Stark', 'Jack Reacher']
        };
    }

    handleStatusChange(e, rowItem) {
        let data = {
            type: 'update',
            coreSystem: rowItem['coreSystem'],
            id: rowItem['_id'],
            status: e.target.value
        }
        ewbSocket.socket.send("/ewbc/update", {}, JSON.stringify(data));
    }

    handleAssigneeChange(e, rowItem) {
        let data = {
            type: 'update',
            coreSystem: rowItem['coreSystem'],
            id: rowItem['_id'],
            assignee: e.target.value
        }
        ewbSocket.socket.send("/ewbc/update", {}, JSON.stringify(data));
    }

    render() {
        if (this.props.exceptionTableList.dataLoadState == 'loaded' && this.props.exceptionTableList.data.length > 0) {
            let headerList = Object.keys(this.props.exceptionTableList.data[0]).filter(keyItem => keyItem != '_id').map((keyItem, index) => {
                return (
                    <th key={index}>{keyItem.lowerCamelCase2Capitalise()}</th>
                );
            });
            let rowList = this.props.exceptionTableList.data.map((rowItem, index) => {
                let colList = Object.keys(rowItem).filter(rKey => rKey != '_id').map((rKey, colIndex) => {
                    if (rKey == 'allocationId') {
                       return (
                            <td key={colIndex} className='link' onClick={(e) => { this.props.showTradeDetail(rowItem._id) }}>{rowItem[rKey]}</td>
                        );
                    }
                    else if (rKey == 'status') {
                        let optionList = this.lookup.statusList.map((item) => {
                            return <option value={item} disabled={this.lookup.disbledStatusList.indexOf(item) > -1}>{item}</option>;
                        });
                        return (
                            <td key={colIndex}>
                                <select key={rowItem[rKey]} defaultValue={rowItem[rKey]} onChange={(e) => { this.handleStatusChange(e, rowItem) }}>
                                    {optionList}
                                </select>
                            </td>
                        );
                    }
                    else if (rKey == 'assignee') {
                        let optionList = this.lookup.assigneeList.map((item) => {
                            return <option value={item}>{item}</option>;
                        });
                        return (
                            <td key={colIndex}>
                                <select key={rowItem[rKey]} defaultValue={rowItem[rKey]} onChange={(e) => { this.handleAssigneeChange(e, rowItem) }}>
                                    {optionList}
                                </select>
                            </td>
                        );
                    }
                    else {
                        return (
                            <td key={colIndex}>{rowItem[rKey]}</td>
                        );
                    }
                });
                return (<tr key={index}>
                    {colList}
                </tr>);
            });
            return (
                <div className='row table-responsive table-container'>
                    <table className='table table-striped table-hover'>
                        <thead>
                            <tr>
                                {headerList}
                            </tr>
                        </thead>
                        <tbody>
                            {rowList}
                        </tbody>
                    </table>
                </div>
            );
        }
        else if (this.props.exceptionTableList.dataLoadState == 'error') {
            return (
                <div className='row table-responsive table-container'>
                    <div className='col'>
                        {this.props.exceptionTableList.error}
                    </div>
                </div>
            );
        }
        else if (this.props.exceptionTableList.dataLoadState == 'loading') {
            return (
                <div className='row table-responsive table-container'>
                    <div className='loader'>
                    </div>
                </div>
            );
        }
        else {
            return null;
        }
    }
}

function mapStateToProps(state) {
    return {
        exceptionTableList: state.tradeProcessingException.exceptionTableList
    };
}

function mapDispatchToProps(dispatch) {
    return {
        showTradeDetail: (text) => dispatch(openTradeDetail(text))
    };
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(ExceptionTable);



