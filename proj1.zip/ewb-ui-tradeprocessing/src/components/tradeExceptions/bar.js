import React from 'react';
import BarPopUp from './barPopUp';
import { rightBarColor, rightBarHoverColor } from './colors';

export default class CategoryBar  extends React.Component {
    constructor(props){
        super(props);
        this.state = { activeBar: null, targetBarID: null };
    }
    
    handleMouseEnter(e, item, id){
        console.log("Bar handle Mouse Enter ---- ");
        if(!this.hoverAllowed)
            return;
        this.setState({activeBar: item, targetBarID: id});

        let target = e.target.classList.contains('triangle-right')?e.target.parentElement:e.target;
   
        target.style.backgroundColor = rightBarHoverColor;

        let rect = target.getBoundingClientRect();
        let popup = this.popup;
        popup.style.left = rect.right - 5 + 'px';
        popup.style.top = rect.top + 0 + 'px';
        popup.style.display = 'block';
    }

    handleMouseLeave(e, item){
        console.log("Bar handle Mouse Leave ---- ");        
        if(!this.hoverAllowed)
            return;
        let popup = this.popup;
        popup.style.display = 'none';

        let target = e.target.classList.contains('triangle-right')?e.target.parentElement:e.target;
        target.style.backgroundColor = rightBarColor;
    }


    handleClick(e, item, id){
        console.log("exception summary bar handle click ---- ");
        console.log(this.lastClicked);

        if(this.lastClicked!=null)
            this.lastClicked.style.backgroundColor = rightBarColor;

        if(this.lastClicked == document.querySelector("#"+id)){
            console.log("exception summary bar click handler ---- unselect");
            this.lastClicked.style.backgroundColor = rightBarColor;
            this.popup.style.display = 'none';
            this.hoverAllowed = true;
            this.lastClicked = null;
            return;
        }

        this.hoverAllowed = true;
        this.lastClicked = document.querySelector("#"+id);
        console.log("exception summary bar click handler ---- select");
        console.log(this.lastClicked);        
        this.handleMouseEnter(e, item, id);
        this.hoverAllowed = false;
    }

    componentWillReceiveProps(nextProps){
        console.log('exception summary bar: componentWillReceiveProps is called.');
        if(this.props.unSelectFlag != nextProps.unSelectFlag && nextProps.unSelectFlag == true){
            this.hoverAllowed = true;
            this.lastClicked = null;
            console.log('componentWillReceiveProps:  hoverAllowed true.');
        }
        

        if(nextProps.unSelectFlag == false){
            this.hoverAllowed = false;
            this.lastClicked = document.querySelector("#"+this.state.targetBarID);
            console.log('componentWillReceiveProps:  hoverAllowed false. == one item in popup is clicked');
        }

        // when active client or severity or stage changes
        if(this.props.resetFlag){
            console.log('active client or severity or stage changed');
            if(this.lastClicked!=null)
                this.lastClicked.style.backgroundColor = rightBarColor;
            this.popup.style.display = 'none';
            this.hoverAllowed = true;
            this.lastClicked = null;
            this.setState({ activeBar: null, targetBarID: null });
        }/**/        
    }

    componentDidMount(){
        console.log('exception summary chart: componentDidMount is called.');
        this.popup = document.querySelector("#barPopUp");
        this.hoverAllowed = true;
        this.lastClicked = null;      
    }

    render() {
        console.log('exception summary chart: render is called.');
        let data = this.props.data;

        console.log(this.hoverAllowed);
        let barList = data.map((item, i) => {
            return (
                <div className="category-bar">
                    <div className="left-bar">{item.name}</div>
                    <div className="right-bar"
                        id={"right_bar" + i}
                        onClick={ (e) => this.handleClick(e, item, "right_bar" + i) }
                        onMouseEnter={ (e) => this.handleMouseEnter(e, item, "right_bar" + i) }
                        onMouseLeave={ (e) => this.handleMouseLeave(e, item) }>
                            {item.count} <div className="triangle-right"></div>
                    </div>
                </div>
            )
        })

        return (
            <div className="category-container">
                {barList}
                <BarPopUp id="barPopUp"
                          data={this.state.activeBar}
                          handler={this.props.handler}
                          targetBarID={this.state.targetBarID}
                          unSelectHandler={this.props.unSelectHandler}
                          resetFlag={this.props.resetFlag}
                />
            </div>
        );
    }
}