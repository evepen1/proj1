import React, { Component } from 'react';
import { connect } from 'react-redux';
import SelectorView from './selectorView';
import { clientSelect, stageSelect, severitySelect, exceptionSummarySelect, exceptionSummaryUnSelect } from '../../actionCreators/actionCreator';

export class ExceptionSelector extends Component {

    componentWillUpdate(nextProps){
        this.resetFlag = false;
        if(this.props.activeClient != nextProps.activeClient ||
            this.props.activeSeverity != nextProps.activeSeverity ||
            this.props.activeStage != nextProps.activeStage)
            this.resetFlag = true;
    }

    render() {
        return (
            <div className='row selector-container'>
                <div className='col-md-4'>
                    <SelectorView heading='Severity' active={this.props.activeSeverity} selectorData={this.props.severityCounts} changeSelectorValue={this.props.changeSeveritySelect} />
                </div>
                <div className='col-md-4'>
                    <SelectorView heading='Stage' active={this.props.activeStage} selectorData={this.props.stageCounts} changeSelectorValue={this.props.changeStageSelect} />
                </div>
                <div className='col-md-4'>
                    <SelectorView heading='Exception Summary' active={''} selectorData={this.props.exceptionSummaryList} 
                                  changeSelectorValue={this.props.changeExceptionSummarySelect} 
                                  unSelect={this.props.changeExceptionSummaryUnSelect} 
                                  unSelectFlag={this.props.unSelectFlag}
                                  resetFlag={this.resetFlag} />
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        activeClient: state.tradeProcessingException.activeClient,
        activeStage: state.tradeProcessingException.activeStage,
        activeSeverity: state.tradeProcessingException.activeSeverity,
        stageCounts: state.tradeProcessingException.stageCounts,
        severityCounts: state.tradeProcessingException.severityCounts,
        exceptionSummaryList: state.tradeProcessingException.exceptionSummaryList,
        unSelectFlag: state.tradeProcessingException.unSelectFlag,
    };
}

function mapDispatchToProps(dispatch) {
    return {
        changeStageSelect: (text) => dispatch(stageSelect(text)),
        changeSeveritySelect: (text) => dispatch(severitySelect(text)),
        changeExceptionSummarySelect: (text) => dispatch(exceptionSummarySelect(text)),
        changeExceptionSummaryUnSelect: (text) => dispatch(exceptionSummaryUnSelect(text)),
    };
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(ExceptionSelector);



