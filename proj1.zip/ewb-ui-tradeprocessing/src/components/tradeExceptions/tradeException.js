import React, { Component } from 'react';
import { connect } from 'react-redux';
import { initialLoad } from '../../actionCreators/actionCreator';
import TradeExceptionSocket from '../../communication/tradeExceptionSocket';
import ExceptionSelector from './exceptionSelector';
import ExceptionTable from './exceptionTable';
import ClientSelector from './clientSelector';
import TradeDetail from './tradeDetail/tradeDetail';

String.prototype.lowerCamelCase2Capitalise = function () {
    let str = "";
    for (var i = 0; i < this.length; ++i) {
        var character = this.charAt(i);
        if (i > 0) {
            if (character == character.toUpperCase()) {
                str = str + ' ';
            }
        }
        str = str + character;
    }
    return str;
}

String.prototype.capitalise = function () {
    return this.charAt(0).toUpperCase() + this.slice(1);
}

String.prototype.anyToUpperCamelWithSpace = function () {
    let str = "";
    var Regex = '^[a-zA-Z]*$';
    for (let i = 0; i < this.length; ++i) {
        let character = this.charAt(i);
        if (i > 0) {
            let prevCharacter = this.charAt(i - 1);
            if (character == character.toUpperCase() && prevCharacter.match(Regex) != null) {
                str = str + character.toLowerCase();
            }
            else if (character == character.toLowerCase()) {
                str = str + character;
            }
            else {
                str = str + character.toUpperCase();
            }
        }
        else {
            str = str + character.toUpperCase();
        }
    }
    return str;
}

class TradeException extends Component {
    render() {
        if (this.props.activeTradeDetail.detail != null && this.props.activeTradeDetail.detail != undefined) {
            return (
                <TradeDetail activeTradeDetail={this.props.activeTradeDetail} />
            );
        }
        return (
            <div className='container-fluid trade-exception-container'>
                <ClientSelector />
                <ExceptionSelector />
                <ExceptionTable />
            </div>
        );
    }

    componentDidMount() {
        TradeExceptionSocket.connect();
        this.props.initialLoad();
    }
    componentWillUnmount() {
        TradeExceptionSocket.disconnect();
    }
}

function mapStateToProps(state) {
    return {
        activeTradeDetail: state.tradeProcessingException.activeTradeDetail
    };
}

function mapDispatchToProps(dispatch) {
    return {
        initialLoad: (text) => dispatch(initialLoad(text))
    };
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(TradeException);
