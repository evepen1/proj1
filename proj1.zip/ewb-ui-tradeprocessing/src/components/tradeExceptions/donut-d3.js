import React from 'react';
import * as D3 from 'd3';

export default class DonutD3 extends React.Component {
    
        render(){
            console.log("for testing");
            console.log(D3);
            var all = this.props.data.filter(item => item.name == 'All').map(item=> item.count);
            var data = this.props.data.filter(item => item.name != 'All');

            if(all.length == 0)
                all = data.reduce((total, num) => total + parseInt(num.count), 0);

            var colors = [
                "#ff7f0e", "#ffe330", "#ff3d11", "#287eba", "#9467bd",
                "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf"
                ];

            var dashoffset = 0;

            var circles = data.map((item, i) => {
                var dashLength = item.count / all * 100;
                var dashGap = 100 - dashLength;

                var styles = {
                    stroke: colors[i%10],
                    strokeDasharray: [dashLength, dashGap],
                    transform: "rotate(" + dashoffset*3.6 + "deg)",
                    transformOrigin: [50, 50]
                };
                dashoffset += dashLength;

                return (
                    <circle className="donut-segment" cx="21" cy="21" r="16" fill="transparent"
                            key={item.name} 
                            strokeWidth="7"
                            style={styles}
                            onClick={(e) => this.props.handler(item.name)} >
                        <title id="donut-segment-1-title">{item.name} : {(item.count/all*100).toFixed(2)}%</title>
                    </circle>
                )
            });

            var liElements = data.map((item, i)=>{
                return (
                    <li key={item.name}>
                        <span className="shape-circle" style={{backgroundColor: colors[i%10]}}></span> {item.name} ({item.count})
                    </li>
                )
            })

            return (
                <figure>
                    <div className="figure-content">
                        <svg width="100%" height="100%" viewBox="0 0 42 42" className="donut" aria-labelledby="beers-title beers-desc" role="img">
                            <title id="beers-title">{this.props.heading}</title>
                            
                            {circles}
                            <circle className="donut-hole" cx="21" cy="21" r="16" fill="transparent" role="presentation"></circle>

                            <g className="chart-text" onClick={(e) => this.props.handler("All")} >
                                <text x="50%" y="50%" className="chart-number">
                                {all}
                                </text>
                                <text x="50%" y="50%" className="chart-label">
                                ALL
                                </text>
                            </g>
                        </svg>
                    </div>

                    <figcaption className="figure-key">
                        <ul className="figure-key-list" aria-hidden="true" role="presentation">
                            {liElements}
                        </ul>
                    </figcaption>
                </figure>
            )
        }
    }