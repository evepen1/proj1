import React, { Component } from 'react';
import { connect } from 'react-redux';
import { navSelect } from '../../actionCreators/actionCreator';
import ChevronRightIcon from '../icons/ChevronRightIcon';
import Tooltip from '../AlertToottip/tooltip';
import { teal100 } from 'material-ui/styles/colors';
import TradeException from '../tradeExceptions/tradeException';
import TradeCycle from '../tradeCycle/tradeCycle';
import { Link } from 'react-router-dom';

const activeChevronColor = {
    fill: 'rgb(255,2,2)'
};

const inActiveChevronColor = {
    fill: 'rgb(0,0,0,0)'
};

class NavigationPanel extends Component {
    render() {
        let navList = this.props.navigationList.map((navItem) => {
            if (navItem.name === this.props.activeNav) {
                return (
                    <li key={navItem.name} className="nav-item active">
                        <Link className="nav-link" to={navItem.uri}>{navItem.name}
                            <ChevronRightIcon style={activeChevronColor} />
                        </Link>
                    </li>
                );
            }
            return (<li key={navItem.name} className="nav-item" onClick={(e) => { this.props.chnageActiveNav(navItem.name) }}>
                        <Link className="nav-link" to={navItem.uri}>{navItem.name}
                            <ChevronRightIcon style={inActiveChevronColor} />
                        </Link>
                    </li>
            );
        }
        );
        return (
            <div className='row' style={{ 'backgroundColor': '#131d2a' }}>
                <Tooltip />
                <nav className="navbar navbar-expand-sm">
                    <ul className="navbar-nav">
                        {navList}
                    </ul>
                </nav>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        navigationList: state.navigationList,
        activeNav: state.activeNav
    };
}

function mapDispatchToProps(dispatch) {
    return {
        chnageActiveNav: (text) => dispatch(navSelect(text))
    };
}

export default connect(
    mapStateToProps, mapDispatchToProps
)(NavigationPanel);



