import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import EwbClarity from './ewbClarity/ewbClarity';

ReactDOM.render(<EwbClarity />, document.getElementById('app'))

