class CycleQuery {
    constructor() {}
    generate() {      
        let str = JSON.stringify({query: '{tradeLifeCycleData(client: ""){_id, firmCode, assetClass, allocationId, blockExternalReferenceId, tradeCapture, confirmation, settlement, accounting, dataDelivery}}'})
        console.log('TLC Table Query - \n' + str);
        return str;
    }
}

export default new CycleQuery;