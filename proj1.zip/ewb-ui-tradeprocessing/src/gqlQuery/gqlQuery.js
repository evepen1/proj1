class GqlQuery {
    constructor() {
        this.gql = {
            query: "{exceptionListHolder{_id,coreSystem,firmCode,severity,transactionId,allocationId,stage,errorCategory,errorDescription,status,assignee} stageCountHolder{name,count} severityCountHolder{name,count} exceptionSummaryHolder{name,count,statusList{name,count}}}"
        }
        this.gqlTradeDetail = {
query: "{tradeDetailHolder{_id,transactionId,allocationId,firmCode,severity,source,assetClass,assetTypeCode,portfolioCode,quantity,custodianAccount,tradeReceivedDate,stage,errorCategory,errorDescription,status,assignee,commentary{comment,userId,userName,time},fileType}}"
}
    }
    generate(client = 'All', stage = 'All', severityType = 'All', errorCategory = '', status = '') {
        if (client == 'All') {
            client = '';
        }
        if (stage == 'All') {
            stage = '';
        }
        if (severityType == 'All') {
            severityType = '';
        }
        let elHolder = `exceptionList(client: \\"${client.toUpperCase()}\\", stage: \\"${stage.toUpperCase()}\\", severityType : \\"${severityType.toUpperCase()}\\", errorCategory: \\"${errorCategory}\\", status: \\"${status}\\")`;
        let stagecHolder = `stageCounts(client: \\"${client.toUpperCase()}\\", severityType : \\"${severityType.toUpperCase()}\\")`;
        let severitycHolder = `severityCounts(client: \\"${client.toUpperCase()}\\", stage: \\"${stage.toUpperCase()}\\")`;
        let esHolder = `exceptionSummaryList(client: \\"${client.toUpperCase()}\\", stage: \\"${stage.toUpperCase()}\\", severityType : \\"${severityType.toUpperCase()}\\")`;

        let str = JSON.stringify(this.gql).replace('exceptionListHolder', elHolder).replace('stageCountHolder', stagecHolder).replace('severityCountHolder', severitycHolder).replace('exceptionSummaryHolder', esHolder);

        console.log('Generate - \n' + str);
        return str;
    }

    generateTradeDetailQuery(_id) {
        let tdHolder = `tradeDetail(_id: \\"${_id}\\")`;
        let str = JSON.stringify(this.gqlTradeDetail).replace('tradeDetailHolder', tdHolder);
        console.log('Generate Trade Detail Query - \n' + str);
        return str;
    }

}

export default new GqlQuery;