import SockJS from 'sockjs-client';
import Stomp from 'stompjs';

const CHANGE_EVENT_PUB_URL = process.env.CHANGE_EVENT_PUB_URL;
console.log("WS URL - ", CHANGE_EVENT_PUB_URL);

class EwbWs {

    constructor() {
        this.socket = null;
        this.selector = {
            client: 'ALL',
            severityType: 'CRITICAL',
            stage: 'ALL'
        };
        this.subList = [];
        this.connected = false;
    }

    subs(subType) {
        if (!this.connected)
            this.subList.push(subType);
        else {
            this.socket.subscribe(subType.endpoint, subType.ca);
        }
    }

    connect() {
        try {
            if (this.socket == null) {
                let ws = new SockJS(CHANGE_EVENT_PUB_URL);
                let stompClient = Stomp.over(ws);
                stompClient.connect({}, (frame) => {
                    console.log("Connect", frame);
                    this.subList.forEach((item) => {
                        stompClient.subscribe(item.endpoint, item.ca);
                    });
                    this.connected = true;
                    console.log('_______________');
                    console.log(this.selector);
                    stompClient.send("/ewbc/getTpData", {}, JSON.stringify(this.selector));
                }, function (err) {
                    console.log("Error", err);
                });
                this.socket = stompClient;
            }
        }
        catch (err) {
            console.log("Error", err);
        }
    }

    disconnect() {
        console.log('Disconnect');
        if (this.socket != null) {
            this.socket.disconnect();
        }
        this.socket = null;
    }
}

export default new EwbWs;


