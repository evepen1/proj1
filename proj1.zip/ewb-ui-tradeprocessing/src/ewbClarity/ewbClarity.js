import "../../asset/css/ewb-clarity.css";
import React, { Component } from 'react';
import SeverityChart from './components/severityChart';
import StageChart from './components/stageChart';
import ExceptionSummaryList from './components/exceptionSummaryList';
import ExceptionTable from './components/exceptionTable';
import ewbWs from './ewbWs';

String.prototype.lowerCamelCase2Capitalise = function () {
    var str = "";
    for (var i = 0; i < this.length; ++i) {
        var character = this.charAt(i);
        if (i > 0) {
            if (character == character.toUpperCase()) {
                str = str + ' ';
            }
        }
        str = str + character;
    }
    return str;
}

String.prototype.anyToUpperCamelWithSpace = function () {
    let str = "";
    var Regex = '^[a-zA-Z]*$';
    for (let i = 0; i < this.length; ++i) {
        let character = this.charAt(i);
        if (i > 0) {
            let prevCharacter = this.charAt(i - 1);
            if (character == character.toUpperCase() && prevCharacter.match(Regex) != null) {
                str = str + character.toLowerCase();
            }
            else if (character == character.toLowerCase()) {
                str = str + character;
            }
            else {
                str = str + character.toUpperCase();
            }
        }
        else {
            str = str + character.toUpperCase();
        }
    }
    return str;
}

export default class EwbClarity extends Component {

    render() {
        return (
            <div>
                <SeverityChart />
                <StageChart />
                <ExceptionSummaryList />
                <ExceptionTable />
            </div>
        );
    }
    componentDidMount() {
        ewbWs.connect();
    }

    componentWillUnmount() {
        console.log('COMPONENT WILL UNMOUNT');
        ewbWs.disconnect();
    }

}

window.SeverityChart = SeverityChart;
window.StageChart = StageChart;
window.ExceptionSummaryList = ExceptionSummaryList;
window.ExceptionTable = ExceptionTable;







