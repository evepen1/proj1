import React, { Component } from 'react';
import SelectorView from './selectorView';
import ewbWs from '../ewbWs';

export default class StageChart extends Component {

    constructor(props) {
        super(props);
        this.state = {
            activeStage: 'All',
            stageCounts: {
                dataLoadState: 'loading',
                error: 'None',
                data: [
                    { name: 'Trade Capture', count: 12 },
                    { name: 'Confirmation', count: 4 }
                ]
            },
        };
        this.changeStageSelect = this.changeStageSelect;
    }

    handleNewException(data) {
        if (ewbWs.selector.client.toUpperCase() == 'ALL' || ewbWs.selector.client.toUpperCase() == data.firmCode.toUpperCase()) {
            if (ewbWs.selector.severityType.toUpperCase() == 'ALL' || ewbWs.selector.severityType.toUpperCase() == data.severity.toUpperCase()) {
                if (data.status.toUpperCase() != 'RESOLVED') {
                    this.setState({
                        stageCounts: {
                            dataLoadState: 'loaded',
                            error: 'None',
                            data: this.state.stageCounts.data.map((item) => {
                                if ((item.name.toUpperCase() == data.stage.toUpperCase()) || item.name.toUpperCase() == 'ALL') {
                                    return ({ name: item.name, count: item.count + 1 });
                                }
                                else {
                                    return ({ name: item.name, count: item.count });
                                }
                            })
                        }
                    });
                }
                else {
                    this.setState({
                        stageCounts: {
                            dataLoadState: 'loaded',
                            error: 'None',
                            data: this.state.stageCounts.data.map((item) => {
                                if (item.name.toUpperCase() == data.stage.toUpperCase() || item.name.toUpperCase() == 'ALL') {
                                    return ({ name: item.name, count: item.count - 1 });
                                }
                                else {
                                    return ({ name: item.name, count: item.count });
                                }
                            }).filter(item => {
                                return item.count > 0
                            })
                        }
                    });
                }
            }
            else {
                return;
            }
        }
        else {
            return;
        }
    }

    changeStageSelect(text) {
        console.log(`changeStageSelect - ${text}`);
        ewbWs.selector.stage = text.toUpperCase();
        this.setState({
            activeStage: text
        });
        console.log('______________________');
        console.log(ewbWs.selector);
        ewbWs.socket.send("/ewbc/getTpData", {}, JSON.stringify(ewbWs.selector));
    }

    render() {
        return (
            <article className='ewb-tp'>
                <SelectorView heading='Stage' active={this.state.activeStage} selectorData={this.state.stageCounts} changeSelectorValue={(text) => this.changeStageSelect(text)} />
            </article>
        );
    }

    componentDidMount() {
        ewbWs.connect();
        let subType = {};
        subType.endpoint = "/topic/ewbc/tpData";
        subType.ca = (message) => {
            console.log("/topic/ewbc/tpData");
            if (message.body) {
                //console.log(message.body);
                let data = JSON.parse(message.body).stageCounts;
                this.setState({
                    stageCounts: {
                        dataLoadState: 'loaded',
                        error: 'None',
                        data: data
                    }
                });
            }
        };
        ewbWs.subs(subType);

        let subType_I = {};
        subType_I.endpoint = "/topic/ewbc/tpException";
        subType_I.ca = (message) => {
            console.log("stageCounts - /topic/ewbc/tpException");
            if (message.body) {
                console.log(message.body);
                let data = JSON.parse(message.body);
                this.handleNewException(data);
            }
        };
        ewbWs.subs(subType_I);
    }

    componentWillUnmount() {
        console.log('COMPONENT WILL UNMOUNT');
        ewbWs.disconnect();
    }
}