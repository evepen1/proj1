import React, { Component } from 'react';
import ewbWs from '../ewbWs';

export default class ExceptionTable extends Component {

    constructor(props) {
        super(props);
        this.state = {
            exceptionTableList: {
                dataLoadState: 'loading',
                error: 'None',
                recordsPerPage: 10,
                totalPages: 5,
                onPage: 1,
                data: []
            }
        }
    }

    handleNewException(data) {
        if (ewbWs.selector.client.toUpperCase() == 'ALL' || ewbWs.selector.client.toUpperCase() == data.firmCode.toUpperCase()) {
            if (ewbWs.selector.severityType.toUpperCase() == 'ALL' || ewbWs.selector.severityType.toUpperCase() == data.severity.toUpperCase()) {
                if (ewbWs.selector.stage.toUpperCase() == 'ALL' || ewbWs.selector.stage.toUpperCase() == data.stage.toUpperCase()) {
                    if (data.status.toUpperCase() != 'RESOLVED') {
                        let tempData = this.state.exceptionTableList.data;
                        tempData.pop();
                        tempData.unshift(data);
                        this.setState({
                            exceptionTableList: {
                                dataLoadState: 'loaded',
                                error: 'None',
                                recordsPerPage: 10,
                                totalPages: 5,
                                onPage: 1,
                                data: tempData
                            }
                        });
                    }
                    else {
                        this.setState({
                            exceptionTableList: {
                                dataLoadState: 'loaded',
                                error: 'None',
                                recordsPerPage: 10,
                                totalPages: 5,
                                onPage: 1,
                                data: this.state.exceptionTableList.data.filter((item) => {
                                    return item._id != data._id
                                })
                            }
                        });
                    }
                }
                else {
                    return;
                }
            }
            else {
                return;
            }
        }
        else {
            return;
        }
    }

    render() {
        if (this.state.exceptionTableList.dataLoadState == 'loaded' && this.state.exceptionTableList.data != undefined && this.state.exceptionTableList.data.length > 0) {
            let headerList = Object.keys(this.state.exceptionTableList.data[0]).filter(keyItem => keyItem != '_id').map((keyItem, index) => {
                return (
                    <th key={index}>{keyItem.lowerCamelCase2Capitalise()}</th>
                );
            });
            let rowList = this.state.exceptionTableList.data.map((rowItem, index) => {
                let colList = Object.keys(rowItem).filter(rKey => rKey != '_id').map((rKey, colIndex) => {
                    return (
                        <td key={colIndex}>{rowItem[rKey]}</td>
                    );
                });
                return (<tr key={index}>
                    {colList}
                </tr>);
            });
            return (
                <article className='ewb-tp'>
                    <div className='table-responsive table-container'>
                        <table className="table table-striped table-hover">
                            <thead>
                                <tr>
                                    {headerList}
                                </tr>
                            </thead>
                            <tbody>
                                {rowList}
                            </tbody>
                        </table>
                    </div>
                </article>
            );
        }
        else if (this.state.exceptionTableList.dataLoadState == 'error') {
            return (
                <article className='ewb-tp'>
                    <div className='table-responsive table-container'>
                        <div className='col'>
                            {this.state.exceptionTableList.error}
                        </div>
                    </div>
                </article>
            );
        }
        else if (this.state.exceptionTableList.dataLoadState == 'loading') {
            return (
                <article className='ewb-tp'>
                    <div className='table-responsive table-container'>
                        <div className='loader'>
                        </div>
                    </div>
                </article>
            );
        }
        else {
            return null;
        }
    }

    componentDidMount() {
        ewbWs.connect();
        let subType = {};
        subType.endpoint = "/topic/ewbc/tpData";
        subType.ca = (message) => {
            //console.log("/topic/ewbc/tpData");
            if (message.body) {
                //console.log(message.body);
                let data = JSON.parse(message.body).exceptionList;
                this.setState({
                    exceptionTableList: {
                        dataLoadState: 'loaded',
                        error: 'None',
                        recordsPerPage: 10,
                        totalPages: 5,
                        onPage: 1,
                        data: data
                    }
                });
            }
        };
        ewbWs.subs(subType);
        
        let subType_I = {};
        subType_I.endpoint = "/topic/ewbc/tpException";
        subType_I.ca = (message) => {
            console.log("exceptionTableList - /topic/ewbc/tpException");
            if (message.body) {
                console.log(message.body);
                let data = JSON.parse(message.body);
                this.handleNewException(data);
            }
        };
        ewbWs.subs(subType_I);
    }

    componentWillUnmount() {
        console.log('COMPONENT WILL UNMOUNT');
        ewbWs.disconnect();
    }
}
