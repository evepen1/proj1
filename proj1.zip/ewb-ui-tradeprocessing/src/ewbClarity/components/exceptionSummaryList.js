import React, { Component } from 'react';
import SelectorView from './selectorView';
import ewbWs from '../ewbWs';

export default class ExceptionSummaryList extends Component {

    constructor(props) {
        super(props);
        this.state = {
            exceptionSummaryList: {
                dataLoadState: 'loading',
                error: 'None',
                data: [
                    { name: 'BUSSINESS_VALIDATION', count: 2, statusList: [{ name: 'Open', count: 2 }] },
                    { name: 'Missing Mandatory Fields', count: 2, statusList: [{ name: 'Work in Progress', count: 2 }] }
                ]
            }
        };
        this.changeExceptionSummarySelect = this.changeExceptionSummarySelect;
    }

    handleNewException(data) {
        if (ewbWs.selector.client.toUpperCase() == 'ALL' || ewbWs.selector.client.toUpperCase() == data.firmCode.toUpperCase()) {
            if (ewbWs.selector.severityType.toUpperCase() == 'ALL' || ewbWs.selector.severityType.toUpperCase() == data.severity.toUpperCase()) {
                if (ewbWs.selector.stage.toUpperCase() == 'ALL' || ewbWs.selector.stage.toUpperCase() == data.stage.toUpperCase()) {
                    if (data.status.toUpperCase() != 'RESOLVED') {
                        let found = false;
                        let tempData = this.state.exceptionSummaryList.data.map((item) => {
                            if (item.name.toUpperCase() == data.errorCategory.toUpperCase() || item.name.toUpperCase() == 'ALL') {
                                found = true;
                                return ({ name: item.name, count: item.count + 1 });
                            }
                            else {
                                return ({ name: item.name, count: item.count });
                            }
                        });
                        if (!found) {
                            tempData.push({ name: data.errorCategory, count: 1 });
                        }
                        this.setState({
                            exceptionSummaryList: {
                                dataLoadState: 'loaded',
                                error: 'None',
                                data: tempData
                            }
                        });
                    }
                    else {
                        this.setState({
                            exceptionSummaryList: {
                                dataLoadState: 'loaded',
                                error: 'None',
                                data: this.state.exceptionSummaryList.data.map((item) => {
                                    if (item.name.toUpperCase() == data.errorCategory.toUpperCase() || item.name.toUpperCase() == 'ALL') {
                                        return ({ name: item.name, count: item.count - 1 });
                                    }
                                    else {
                                        return ({ name: item.name, count: item.count });
                                    }
                                }).filter(item => {
                                    return item.count > 0
                                })
                            }
                        });
                    }
                }
                else {
                    return;
                }
            }
            else {
                return;
            }
        }
        else {
            return;
        }
    }

    changeExceptionSummarySelect(text) {
        console.log('changeExceptionSummarySelect');
    }

    render() {
        return (
            <article className='ewb-tp'>
                <SelectorView heading='Exception Summary' active={''} selectorData={this.state.exceptionSummaryList} changeSelectorValue={this.changeExceptionSummarySelect} />
            </article>
        );
    }

    componentDidMount() {
        ewbWs.connect();
        let subType = {};
        subType.endpoint = "/topic/ewbc/tpData";
        subType.ca = (message) => {
            //console.log("/topic/ewbc/tpData");
            if (message.body) {
                // console.log(message.body);
                let data = JSON.parse(message.body).exceptionSummaryList;
                this.setState({
                    exceptionSummaryList: {
                        dataLoadState: 'loaded',
                        error: 'None',
                        data: data
                    }
                });
            }
        };
        ewbWs.subs(subType);

        let subType_I = {};
        subType_I.endpoint = "/topic/ewbc/tpException";
        subType_I.ca = (message) => {
            console.log("exceptionSummaryList - /topic/ewbc/tpException");
            if (message.body) {
                console.log(message.body);
                let data = JSON.parse(message.body);
                this.handleNewException(data);
            }
        };
        ewbWs.subs(subType_I);
    }

    componentWillUnmount() {
        console.log('COMPONENT WILL UNMOUNT');
        ewbWs.disconnect();
    }
}
