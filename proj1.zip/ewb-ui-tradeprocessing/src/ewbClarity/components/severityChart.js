import React, { Component } from 'react';
import SelectorView from './selectorView';
import ewbWs from '../ewbWs';

export default class SeverityChart extends Component {

    constructor(props) {
        super(props);
        this.state = {
            activeSeverity: 'Critical',
            severityCounts: {
                dataLoadState: 'loading',
                error: 'None',
                data: [
                    { name: 'Critical', count: 3 },
                    { name: 'Medium', count: 3 }
                ]
            },
        };
        this.changeSeveritySelect = this.changeSeveritySelect;
    }

    handleNewException(data) {
        if (ewbWs.selector.client.toUpperCase() == 'ALL' || ewbWs.selector.client.toUpperCase() == data.firmCode.toUpperCase()) {
            if (data.status.toUpperCase() != 'RESOLVED') {
                this.setState({
                    severityCounts: {
                        dataLoadState: 'loaded',
                        error: 'None',
                        data: this.state.severityCounts.data.map((item) => {
                            if (item.name.toUpperCase() == data.severity.toUpperCase() || item.name.toUpperCase() == 'ALL') {
                                return ({ name: item.name, count: item.count + 1 });
                            }
                            else {
                                return ({ name: item.name, count: item.count });
                            }
                        })
                    }
                });
            }
            else {
                this.setState({
                    severityCounts: {
                        dataLoadState: 'loaded',
                        error: 'None',
                        data: this.state.severityCounts.data.map((item) => {
                            if (item.name.toUpperCase() == data.severity.toUpperCase() || item.name.toUpperCase() == 'ALL') {
                                return ({ name: item.name, count: item.count - 1 });
                            }
                            else {
                                return ({ name: item.name, count: item.count });
                            }
                        }).filter(item => {
                            return item.count > 0
                        })
                    }
                });
            }
        }
        else {
            return;
        }
    }

    changeSeveritySelect(text) {
        console.log(`changeSeveritySelect - ${text}`);
        ewbWs.selector.severityType = text.toUpperCase();
        this.setState({
            activeSeverity: text
        });
        console.log('______________________');
        console.log(ewbWs.selector);
        ewbWs.socket.send("/ewbc/getTpData", {}, JSON.stringify(ewbWs.selector));
    }

    render() {
        return (
            <article className='ewb-tp'>
                <SelectorView heading='Severity' active={this.state.activeSeverity} selectorData={this.state.severityCounts} changeSelectorValue={(text) => this.changeSeveritySelect(text)} />
            </article>
        );
    }

    componentDidMount() {
        ewbWs.connect();
        let subType = {};
        subType.endpoint = "/topic/ewbc/tpData";
        subType.ca = (message) => {
            //console.log("/topic/ewbc/tpData");
            if (message.body) {
                // console.log(message.body);
                let data = JSON.parse(message.body).severityCounts;
                this.setState({
                    severityCounts: {
                        dataLoadState: 'loaded',
                        error: 'None',
                        data: data
                    }
                });
            }
        };
        ewbWs.subs(subType);

        let subType_I = {};
        subType_I.endpoint = "/topic/ewbc/tpException";
        subType_I.ca = (message) => {
            console.log("severityCounts - /topic/ewbc/tpException");
            if (message.body) {
                console.log(message.body);
                let data = JSON.parse(message.body);
                this.handleNewException(data);
            }
        };
        ewbWs.subs(subType_I);
    }

    componentWillUnmount() {
        console.log('COMPONENT WILL UNMOUNT');
        ewbWs.disconnect();
    }
}