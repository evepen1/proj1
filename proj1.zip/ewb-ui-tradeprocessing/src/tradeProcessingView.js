import React, { Component } from 'react';
import {  HashRouter, Switch, Route } from 'react-router-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import NavigationPanel from './components/navigation/NavigationPanel';
import TradeException from './components/tradeExceptions/tradeException';
import TradeCycle from './components/tradeCycle/tradeCycle';

export default class TradeProcessingView extends Component {
    render() {
        return (
            <MuiThemeProvider>
                <HashRouter>
                    <div className='ewb-tp container-fluid'>
                        <NavigationPanel />
                        <Switch>
                            <Route exact path='/' component={TradeException} />
                            <Route exact path='/tradeException' component={TradeException} />
                            <Route exact path='/tradeLifeCycle' component={TradeCycle} />
                        </Switch>
                    </div>
                </HashRouter>
            </MuiThemeProvider>
        ); 
    }
}


