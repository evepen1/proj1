import React from "react";
import ReactDOM from "react-dom";
import { shallow, mount, render } from 'enzyme';
import ConnectedExceptionSelector, { ExceptionSelector } from "./exceptionSelector";
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';

describe("Exception Selector test", () => {
    let initialState = {
        activeClient: 'TEST_CLIENT',
        activeStage: 'TEST_STAGE',
        activeSeverity: 'TEST_SEVERITY',
        stageCounts: 'TEST_SC',
        severityCounts: 'TEST_SVC',
        exceptionSummaryList: 'TEST_ESL',
    };
    const mockStore = configureStore();
    let store, wrapper;
    beforeEach(() => {
        store = mockStore(initialState);
        wrapper = mount(<Provider store={store}><ConnectedExceptionSelector /></Provider>);
    });

    it("creation of selector area containing three chart", () => {
        expect(wrapper.find(".selector-container").exists()).toEqual(true);
        expect(wrapper.find(".selector-container article").length).toEqual(3);
    });
    it("proper props connected to redux state of selector area containing three chart", () => {
        expect(wrapper.find(ExceptionSelector).prop('activeClient')).toEqual(initialState.activeClient);
        expect(wrapper.find(ExceptionSelector).prop('activeStage')).toEqual(initialState.activeStage);
        expect(wrapper.find(ExceptionSelector).prop('activeSeverity')).toEqual(initialState.activeSeverity);
        expect(wrapper.find(ExceptionSelector).prop('stageCounts')).toEqual(initialState.stageCounts);
        expect(wrapper.find(ExceptionSelector).prop('severityCounts')).toEqual(initialState.severityCounts);
        expect(wrapper.find(ExceptionSelector).prop('exceptionSummaryList')).toEqual(initialState.exceptionSummaryList);
    });
});