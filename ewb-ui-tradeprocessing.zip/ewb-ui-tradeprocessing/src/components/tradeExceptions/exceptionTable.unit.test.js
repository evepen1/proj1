import React from "react";
import ReactDOM from "react-dom";
import { shallow, mount, render } from 'enzyme';
import ConnectedExceptionTable from "./exceptionTable";
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';

String.prototype.lowerCamelCase2Capitalise = function () {
    var str = "";
    for (var i = 0; i < this.length; ++i) {
        var character = this.charAt(i);
        if (i > 0) {
            if (character == character.toUpperCase()) {
                str = str + ' ';
            }
        }
        str = str + character;
    }
    return str;
}

String.prototype.anyToUpperCamelWithSpace = function () {
    let str = "";
    var Regex = '^[a-zA-Z]*$';
    for (let i = 0; i < this.length; ++i) {
        let character = this.charAt(i);
        if (i > 0) {
            let prevCharacter = this.charAt(i - 1);
            if (character == character.toUpperCase() && prevCharacter.match(Regex) != null) {
                str = str + character.toLowerCase();
            }
            else if (character == character.toLowerCase()) {
                str = str + character;
            }
            else {
                str = str + character.toUpperCase();
            }
        }
        else {
            str = str + character.toUpperCase();
        }
    }
    return str;
}

describe("Exception Table test", () => {
    let initialState = {
        exceptionTableList: {
            dataLoadState: 'loaded',
            error: 'None',
            recordsPerPage: 10,
            totalPages: 5,
            onPage: 1,
            data: []
        }
    };
    const mockStore = configureStore();
    let store, wrapper;

    it("creation of table when data loaded", () => {
        initialState.exceptionTableList.data.push({ col1: 'C1', col2: 'C2' });
        store = mockStore(initialState);
        wrapper = mount(<Provider store={store}><ConnectedExceptionTable /></Provider>);
        expect(wrapper.find(".table-container").exists()).toEqual(true);
        expect(wrapper.find(".table-container>table").exists()).toEqual(true);
    });
    it("creation of table when data is loading", () => {
        initialState.exceptionTableList.dataLoadState = 'loading';
        store = mockStore(initialState);
        wrapper = mount(<Provider store={store}><ConnectedExceptionTable /></Provider>);
        expect(wrapper.text()).toEqual('Loading');
    });
    it("creation of table when data loading led to error", () => {
        initialState.exceptionTableList.dataLoadState = 'error';
        initialState.exceptionTableList.error = 'Test error';
        store = mockStore(initialState);
        wrapper = mount(<Provider store={store}><ConnectedExceptionTable /></Provider>);
        expect(wrapper.text()).toEqual(initialState.exceptionTableList.error);
    });
});