import React from 'react';

export default class CategoryBar  extends React.Component {
    render() {
        let data = this.props.data;
        let barList = data.map((item, i) => {
            return (
                <div className="category-bar">
                    <div className="left-bar">{item.name}</div>
                    <div className="right-bar"
                        onClick={(e) => this.props.handler(item.name)}>
                    {item.count} <div className="triangle-right"></div></div>
                </div>
            )
        })

        return (
            <div className="category-container">
                {barList}
            </div>
        );
    }
}