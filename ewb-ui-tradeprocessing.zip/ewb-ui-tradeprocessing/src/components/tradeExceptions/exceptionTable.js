import React, { Component } from 'react';
import { connect } from 'react-redux';

class ExceptionTable extends Component {
    render() {
        if (this.props.exceptionTableList.dataLoadState == 'loaded' && this.props.exceptionTableList.data.length > 0) {
            let headerList = Object.keys(this.props.exceptionTableList.data[0]).filter(keyItem => keyItem != '_id').map((keyItem, index) => {
                return (
                    <th key={index}>{keyItem.lowerCamelCase2Capitalise()}</th>
                );
            });
            let rowList = this.props.exceptionTableList.data.map((rowItem, index) => {
                let colList = Object.keys(rowItem).filter(rKey => rKey != '_id').map((rKey, colIndex) => {
                    return (
                        <td key={colIndex}>{rowItem[rKey]}</td>
                    );
                });
                return (<tr key={index}>
                    {colList}
                </tr>);
            });
            return (
                <div className='row table-responsive table-container'>
                    <table className="table table-striped table-hover">
                        <thead>
                            <tr>
                                {headerList}
                            </tr>
                        </thead>
                        <tbody>
                            {rowList}
                        </tbody>
                    </table>
                </div>
            );
        }
        else if (this.props.exceptionTableList.dataLoadState == 'error') {
            return (
                <div className='row'>
                    <div className='col'>
                        {this.props.exceptionTableList.error}
                    </div>
                </div>
            );
        }
        else if (this.props.exceptionTableList.dataLoadState == 'loading') {
            return (
                <div className='row'>
                    <div className='col'>
                        Loading
                     </div>
                </div>
            );
        }
        else {
            return null;
        }
    }
}

function mapStateToProps(state) {
    return {
        exceptionTableList: state.exceptionTableList
    };
}

export default connect(
    mapStateToProps
)(ExceptionTable);



