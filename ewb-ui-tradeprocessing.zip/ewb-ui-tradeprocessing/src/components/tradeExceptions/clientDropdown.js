import React, { Component } from 'react';
import { connect } from 'react-redux';
import { clientSelect } from '../../actionCreators/actionCreator';
import ChevronDownIcon from '../icons/ChevronDownIcon';

class Dropdown extends Component {

    selectedDropdown(e) {
        console.log("DropDown Value===>", e.target.value);
        this.props.changeActiveClient(e.target.value);
    }
    render() {

        return (
            <div className='row' style={{ 'backgroundColor': '#1d2632' }}>
                <div className="dropdown">
                    <div className="dropbtn">
                        <i className="icon-guy" style={{ 'fontStyle': 'normal' }}> CLIENT<span className="chevron bottom"></span></i>
                        <select className="form-control" style={{ 'backgroundColor': '#1d2632' }} onChange={this.selectedDropdown.bind(this)}>
                            <option >All</option>
                            <option >SLI</option>
                            <option >OMGI</option>
                            <option >KAMES</option>
                            <option >FSTP</option>
                            <option >AAM</option>
                            <option >AIA</option>
                            <option >TNA</option>
                            <option >CAL</option>
                        </select>
                    </div>
                </div>
                <div className="dropdown">
                    <div className="dropbtn">
                        <i className="icon-guy" style={{ 'fontStyle': 'normal' }}> SLA <span className="chevron bottom"></span></i>
                        <select className="form-control" style={{ 'backgroundColor': '#1d2632' }}>
                            <option>All</option>
                            <option>SLA</option>
                            <option>Critical SLA</option>
                            <option>Trade Volume</option>
                            <option>Fund NAV</option>
                        </select>
                    </div>
                </div>    
            </div>
        );
    }
}
function mapStateToProps(state) {
    return {
        activeClient: state.activeClient
    };
}
function mapDispatchToProps(dispatch) {
    return {
        changeActiveClient: (text) => dispatch(clientSelect(text))
    };
}
export default connect(
    mapStateToProps, mapDispatchToProps
)(Dropdown);




