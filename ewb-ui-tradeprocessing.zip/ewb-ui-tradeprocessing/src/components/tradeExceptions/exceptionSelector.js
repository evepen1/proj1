import React, { Component } from 'react';
import { connect } from 'react-redux';
import SelectorView from './selectorView';
import { clientSelect, stageSelect, severitySelect } from '../../actionCreators/actionCreator';

export class ExceptionSelector extends Component {
    render() {
        return (
            <div className='row selector-container'>
                <div className='col-md-4'>
                    <SelectorView heading='Severity' active={this.props.activeSeverity} selectorData={this.props.severityCounts} changeSelectorValue={this.props.changeSeveritySelect} />
                </div>
                <div className='col-md-4'>
                    <SelectorView heading='Stage' active={this.props.activeStage} selectorData={this.props.stageCounts} changeSelectorValue={this.props.changeStageSelect} />
                </div>
                <div className='col-md-4'>
                    <SelectorView heading='Exception Summary' active={''} selectorData={this.props.exceptionSummaryList} changeSelectorValue={this.props.changeExceptionSummarySelect} />
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        activeClient: state.activeClient,
        activeStage: state.activeStage,
        activeSeverity: state.activeSeverity,
        stageCounts: state.stageCounts,
        severityCounts: state.severityCounts,
        exceptionSummaryList: state.exceptionSummaryList,
    };
}

function mapDispatchToProps(dispatch) {
    return {
        changeStageSelect: (text) => dispatch(stageSelect(text)),
        changeSeveritySelect: (text) => dispatch(severitySelect(text)),
        changeExceptionSummarySelect: (text) => { }
    };
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(ExceptionSelector);



