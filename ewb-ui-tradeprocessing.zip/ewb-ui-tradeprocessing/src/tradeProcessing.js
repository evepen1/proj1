import React, { Component } from 'react';
import 'rxjs';
import { Provider } from 'react-redux';
import tpStore from './store/tpStore';
import TradeProcessingView from './tradeProcessingView';


export default class TradeProcessing extends Component {
    render() {
        return (<Provider store={tpStore}>
            <TradeProcessingView />
        </Provider>
        );
    }
}