import { createStore, applyMiddleware } from 'redux';
import tcReducer from '../reducers/tcReducer';
import { createEpicMiddleware } from 'redux-observable';
import { tcEpic } from '../epics/tcEpic';

const epicMiddleware = createEpicMiddleware(tcEpic);
const tcStore = createStore(
    tcReducer,
  applyMiddleware(epicMiddleware)
 );
// const tpStore = createStore(
//   tpReducer
//   );

export default tcStore;