import { createStore, applyMiddleware } from 'redux';
import tpReducer from '../reducers/tpReducer';
import { createEpicMiddleware } from 'redux-observable';
import { tpEpic } from '../epics/tpEpic';

const epicMiddleware = createEpicMiddleware(tpEpic);
const tpStore = createStore(
  tpReducer,
  applyMiddleware(epicMiddleware)
 );
// const tpStore = createStore(
//   tpReducer
//   );

export default tpStore;