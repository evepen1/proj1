class CycleQuery {
    constructor() {
        this.gql = {
            query: "{exceptionListHolder{_id,firmCode,transactionId,allocationId,Trade Capture, Confirmation, Settlement, Acccounting, Data Delivery}}"
        }
    }
    generate(client = 'All', exceptionCategory = 'All', severityType = 'All') {
        client == 'All' ? client = '' : client = client;
        exceptionCategory == 'All' ? exceptionCategory = '' : exceptionCategory = exceptionCategory;
        severityType == 'All' ? severityType = '' : severityType = severityType;

        let elHolder = `exceptionList(client: \\"${client.toUpperCase()}\\", exceptionCategory: \\"${exceptionCategory.toUpperCase()}\\", severityType : \\"${severityType.toUpperCase()}\\")`;
        let stagecHolder = `stageCounts(client: \\"${client.toUpperCase()}\\", severityType : \\"${severityType.toUpperCase()}\\")`;
        let severitycHolder = `severityCounts(client: \\"${client.toUpperCase()}\\", exceptionCategory: \\"${exceptionCategory.toUpperCase()}\\")`;
        let esHolder = `exceptionSummaryList(client: \\"${client.toUpperCase()}\\", exceptionCategory: \\"${exceptionCategory.toUpperCase()}\\", severityType : \\"${severityType.toUpperCase()}\\")`;
        
        let str = JSON.stringify(this.gql).replace('exceptionListHolder', elHolder).replace('stageCountHolder', stagecHolder).replace('severityCountHolder', severitycHolder).replace('exceptionSummaryHolder', esHolder);
        
        console.log('Generate - \n' + str);
        return str;
    }

}

export default new CycleQuery;
