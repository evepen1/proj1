import { CLIENT_SELECT, STAGE_SELECT, NAV_SELECT, SEVERITY_SELECT, GQL_UPDATE, INITIAL_LOADING, NEW_EXCEPTION, ALERT_TOOTLTIP } from '../actions/actions';


export function initialLoad(text) {
    console.log(`Action Creator - initialLoad - ${text}`);
    return { type: INITIAL_LOADING, payload: text };
}

export function clientSelect(text) {
    console.log(`Action Creator - clientSelect - ${text}`);
    return { type: CLIENT_SELECT, payload: text };
}

export function stageSelect(text) {
    console.log(`Action Creator - stageSelect - ${text}`);
    return { type: STAGE_SELECT, payload: text };
}

export function severitySelect(text) {
    console.log(`Action Creator - severitySelect - ${text}`);
    return { type: SEVERITY_SELECT, payload: text };
}

export function navSelect(text) {
    console.log(`Action Creator - navSelect - ${text}`);
    return { type: NAV_SELECT, payload: text };
}

export function gqlUpdate(text) {
    console.log(`Action Creator - gqlUpdate - \n${JSON.stringify(text)}`);
    return { type: GQL_UPDATE, payload: text };
}

export function newException(text) {
    console.log(`Action Creator - newException - ${text}`);
    return { type: NEW_EXCEPTION, payload: text };
}

export function alertTooltip(text) {
    console.log(`Action Creator - alertTooltip - ${text}`);
    return { type: ALERT_TOOTLTIP, payload: text };
}



