import { combineEpics } from 'redux-observable';
import { combineReducers } from 'redux';
import selectorEpic from './tradeExceptionEpics/selectorEpic';

export const tpEpic = combineEpics(
  selectorEpic
);
