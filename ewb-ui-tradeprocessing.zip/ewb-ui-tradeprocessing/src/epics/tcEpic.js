import { combineEpics } from 'redux-observable';
import { combineReducers } from 'redux';
import cycleEpic from './tradeCycleEpics/cycleEpic';

export const tcEpic = combineEpics(
  cycleEpic
);
