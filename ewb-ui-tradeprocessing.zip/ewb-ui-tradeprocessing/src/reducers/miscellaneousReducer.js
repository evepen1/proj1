import { ALERT_TOOTLTIP } from '../actions/actions';

export function navigationList(state = ['Trade Processing Exception', 'Trade Life Cycle'], action) {
  return state
}

export function tooltip(state = { type: 'light', text: '' }, action) {
  switch (action.type) {
    case ALERT_TOOTLTIP:
      return action.payload;
    default:
      return state;
  }
}
