import { CLIENT_SELECT, STAGE_SELECT, SEVERITY_SELECT, NEW_EXCEPTION, GQL_UPDATE, GQL_UPDATE_ERROR } from '../../actions/actions';

const defaultStageCount = {
  dataLoadState: 'loaded',
  error: 'None',
  data: [
    { name: 'Trade Capture', count: 12 },
    { name: 'Confirmation', count: 4 }
  ]
};

export function stageCountUpdate(state = defaultStageCount, action) {
  switch (action.type) {
    case GQL_UPDATE:
      return {
        dataLoadState: 'loaded',
        error: 'None',
        data: action.payload.data.stageCounts
      };
    case GQL_UPDATE_ERROR:
      return {
        dataLoadState: 'error',
        error: action.payload
      };
    case NEW_EXCEPTION:
      if (action.payload.activeClient == 'All' || action.payload.activeClient.toUpperCase() == action.payload.data.firmCode.toUpperCase()) {
        if (action.payload.activeSeverity == 'All' || action.payload.activeSeverity.toUpperCase() == action.payload.data.severity.toUpperCase()) {
          if (action.payload.data.status.toUpperCase() != 'RESOLVED') {
            return {
              dataLoadState: 'loaded',
              data: state.data.map((item) => {
                if ((item.name.toUpperCase() == action.payload.data.exceptionCategory.toUpperCase()) || item.name.toUpperCase() == 'ALL') {
                  return ({ name: item.name, count: item.count + 1 });
                }
                else {
                  return ({ name: item.name, count: item.count });
                }
              })
            };
          }
          else {
            return {
              dataLoadState: 'loaded',
              data: state.data.map((item) => {
                if (item.name.toUpperCase() == action.payload.data.exceptionCategory.toUpperCase() || item.name.toUpperCase() == 'ALL') {
                  return ({ name: item.name, count: item.count - 1 });
                }
                else {
                  return ({ name: item.name, count: item.count });
                }
              }).filter(item => {
                item.count > 0
              })
            };
          }
        }
        else {
          return state;
        }
      }
      else {
        return state;
      }
    case CLIENT_SELECT:
      return {
        dataLoadState: 'loading',
        data: state.data
      };
    case STAGE_SELECT:
      return {
        dataLoadState: 'loading',
        data: state.data
      };
    case SEVERITY_SELECT:
      return {
        dataLoadState: 'loading',
        data: state.data
      };
    default:
      return state
  }
}