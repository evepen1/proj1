import { exceptionSummaryUpdate } from './exceptionSummaryReducer'
import * as types from '../../actions/actions'

describe('Exception summary reducer', () => {
  it('should return the initial state', () => {
    expect(exceptionSummaryUpdate(undefined, {})).toEqual(
      {
        dataLoadState: 'loaded',
        error: 'None',
        data: [
          { name: 'BUSSINESS_VALIDATION', count: 2, statusList: [{ name: 'Open', count: 2 }] },
          { name: 'Missing Mandatory Fields', count: 2, statusList: [{ name: 'Work in Progress', count: 2 }] }
        ]
      }
    )
  })

  it('should handle GQL_UPDATE', () => {
    expect(
      exceptionSummaryUpdate([], {
        type: types.GQL_UPDATE,
        payload: {
          data: {
            exceptionSummaryList: [{ name: 'BUSSINESS_VALIDATION', count: 2, statusList: [{ name: 'Open', count: 2 }] },
            { name: 'Missing Mandatory Fields', count: 2, statusList: [{ name: 'Work in Progress', count: 2 }] }]
          }
        }
      })
    ).toEqual(
      {
        dataLoadState: 'loaded',
        error: 'None',
        data: [
          { name: 'BUSSINESS_VALIDATION', count: 2, statusList: [{ name: 'Open', count: 2 }] },
          { name: 'Missing Mandatory Fields', count: 2, statusList: [{ name: 'Work in Progress', count: 2 }] }
        ]
      }
      );
  });
  it('should handle GQL_UPDATE_ERROR', () => {
    expect(
      exceptionSummaryUpdate([], {
        type: types.GQL_UPDATE_ERROR,
        payload: 'Test error'
      })
    ).toEqual(
      {
        dataLoadState: 'error',
        error: 'Test error'
      }
      );
  });
})