import { combineReducers } from 'redux';
import * as selectorReducer from './tradeExceptionReducers/selectorReducer';
import * as miscellaneousReducer from './miscellaneousReducer'
import { stageCountUpdate } from './tradeExceptionReducers/stageCountReducer';
import { severityCountUpdate } from './tradeExceptionReducers/severityCountReducer';
import { exceptionSummaryUpdate } from './tradeExceptionReducers/exceptionSummaryReducer';
import { exceptionTableUpdate } from './tradeExceptionReducers/exceptionTableReducer';

const tpReducer = combineReducers({
    navigationList: miscellaneousReducer.navigationList,
    tooltipAlert: miscellaneousReducer.tooltip,
    activeNav: selectorReducer.navSelect,
    activeClient: selectorReducer.clientSelect,
    activeStage: selectorReducer.stageSelect,
    activeSeverity: selectorReducer.severitySelect,
    stageCounts: stageCountUpdate,
    severityCounts: severityCountUpdate,
    exceptionSummaryList: exceptionSummaryUpdate,
    exceptionTableList: exceptionTableUpdate
});

export default tpReducer;