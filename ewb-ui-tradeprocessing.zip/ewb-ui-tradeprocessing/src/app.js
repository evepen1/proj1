import "../asset/css/ewb-tp.css";
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import TradeProcessing from './tradeProcessing';

ReactDOM.render(<TradeProcessing />, document.getElementById('app'))

